#include "Cmd_715.h"
int isReceivedCommand = 0;
//715����
int32_t QSENS_AckInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}

int32_t QSENS_AckFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}

int32_t QSENS_AckFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}

extern uint32_t sendDataFre;
int32_t QSENS_AckFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	ConfigTabelTypeDef* pConfig;
	pConfig = GetConfigTable();
	
	if(pBuffer[2] == 0x00)
	{
		pConfig->ulIsOnlyNavData = 1;
	}
	
	if(isReceivedCommand == 0)//���յ���ʶ��ָ��ģʽ������
		return FUNC_OK;
	
	if(pBuffer[2] == 0x00)
	{
//		if(sendDataFre > 1)
//		{
//		  navDataCouter = sendDataFre - 2;//�յ�ָ����ӳ����ķ���
//		}
//		else
//		{
//		  navDataCouter = 0;
//		}
		pConfig->ulIsOnlyNavData = 1;
		pConfig->ulIsNavDataSend = 0;
		pConfig->ulIsImuDataSend = 0;
		pConfig->ulIsMagDataSend = 0;
	}
	else if(pBuffer[2] == 0x66)
	{
		pConfig->ulIsOnlyNavData = 0;
		if(pBuffer[3] == 0x00)
		{
			pConfig->ulIsNavDataSend = 1;
			pConfig->ulIsImuDataSend = 1;
			pConfig->ulIsMagDataSend = 1;
		}
		else if(pBuffer[3] == 0x01)
		{
			pConfig->ulIsNavDataSend = 1;
			pConfig->ulIsImuDataSend = 0;
			pConfig->ulIsMagDataSend = 0;
		}
		else if(pBuffer[3] == 0x02)
		{
			pConfig->ulIsNavDataSend = 0;
			pConfig->ulIsImuDataSend = 1;
			pConfig->ulIsMagDataSend = 0;
		}
		else if(pBuffer[3] == 0x03)
		{
			pConfig->ulIsNavDataSend = 0;
			pConfig->ulIsImuDataSend = 0;
			pConfig->ulIsMagDataSend = 1;
		}
		else if(pBuffer[3] == 0x04)
		{
			pConfig->ulIsNavDataSend = 1;
			pConfig->ulIsImuDataSend = 1;
			pConfig->ulIsMagDataSend = 0;
		}
		else if(pBuffer[3] == 0x05)
		{
			pConfig->ulIsNavDataSend = 1;
			pConfig->ulIsImuDataSend = 0;
			pConfig->ulIsMagDataSend = 1;
		}
		else if(pBuffer[3] == 0x06)
		{
			pConfig->ulIsNavDataSend = 0;
			pConfig->ulIsImuDataSend = 1;
			pConfig->ulIsMagDataSend = 1;
		}
		else
		{
		}
	}
	else
	{
	}
	return FUNC_OK;
}










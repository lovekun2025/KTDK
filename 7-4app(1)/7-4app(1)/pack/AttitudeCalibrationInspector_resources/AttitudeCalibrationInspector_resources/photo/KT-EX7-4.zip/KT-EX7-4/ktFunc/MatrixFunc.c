// ��ϵ���ʹ�õľ����Ӻ���
//  20190830  ����  ver 1.00

//   int m,n,k;
//  float32 a[][],b[][],c[][]d[][];
//  ���󴫵ݵ����׵�ַ,ͨ���ı��ַ��Ӧ����ֵ���к���ֵ�ķ���.

#ifndef  OS_MASTER_FILE
#include "includes.h"
#endif

//  1. �������������
//   c(m*1)=a(m*n)*b(n*1)
//
void mat_vectn(int m, int n, float32 *c, float32 *b,float32 *a)
{
	 int i,j;
	 for(i=0; i<m; i++)
	 {
			c[i]=0.0;
			for(j=0; j<n; j++)
			{
				c[i] += a[i*n+j] * b[j];
			}
   }
	 return;	
}

/*2. �����ת�����������
 * c(n*1)=a'(m*n)*b(m*1)
 */
void matt_vectn(int m, int n, float32 *c, float32 *b,float32 *a)
{
	 int i,j;
	 for(i=0; i<n; i++)
	 {
			c[i]=0.0;
			for(j=0; j<m; j++)
			{
				c[i] += a[j*n+i] * b[j];
			}
   }
	 return;	
	
}

/*3. ������������
 * c(m*k)=a(m*n)*b(n*k)
 */
void matrix_mult(int m, int n, int k, float32 *c, float32 *b,float32 *a)
{
	int i,j,jj,kk;
	for(i=0; i<m; i++)
	{
		for(j=0; j<k; j++)
	    {
				jj=i*k+j;
				c[jj]=0.0;
				for(kk=0; kk<n; kk++)
				{
					c[jj] += a[i*n+kk]*b[kk*k+j];
				}
			}
		}
	return;	
}

/*4. ������������,�Ӹ���
 * c(m*k)=-a(m*n)*b(n*k)
 */
void neg_matrix_mult(int m, int n, int k, float32 *c, float32 *b,float32 *a)
{
	int i,j,jj,kk;
	for(i=0; i<m; i++)
	{
			for(j=0; j<k; j++)
	    {
				jj=i*k+j;
				c[jj]=0.0;
				for(kk=0; kk<n; kk++)
				{
					c[jj] -= a[i*n+kk]*b[kk*k+j];
				}
			}
		}
	return;	
}

/*5. ����a�����b��ת�����
 * c(m*k)=a(m*n)*(b(k*n))'
 */
void matrix_t_m(int m, int n, int k, float32 *c, float32 *b,float32 *a)
{
	int i,j,jj,kk;
	for(i=0; i<m; i++)
	{
	    for(j=0; j<k; j++)
	    {
                  jj=i*k+j;
                  c[jj]=0.0;
                  for(kk=0; kk<n; kk++)
                  {
                          c[jj] += a[i*n+kk]*b[j*n+kk];
                  }
	     }
	}
	return;	
}
/*6. ����a�����b��ת�����,�ټ���d
 * c(m*k)=a(m*n)*(b(k*n))'+d(m*k)
 */
void matrix_t_m_a(int m, int n, int k, float32 *d, float32 *c, float32 *b,float32 *a)
{
	int i,j,jj,kk;
	for(i=0; i<m; i++)
	{
			for(j=0; j<k; j++)
	    {
				jj=i*k+j;
				c[jj]=d[jj];
				for(kk=0; kk<n; kk++)
				{
					c[jj] += a[i*n+kk]*b[j*n+kk];
				}
			}
		}
	return;		
}

/*7. ����a����
 * c(n*n)=inv(a(n*n))
 * return: 0--fail, 1--correct
 * ����ȫѡ��ԪGauss-Jordon��Ԫ������
 */
int matrixinva(float32 *a,int n)
{
	int *is,*js,i,j,k,t,u,v;
    float32 d,p;
    
    is = malloc(n*sizeof(int));
    js = malloc(n*sizeof(int));

    if((is == NULL)||(js == NULL))
    return(0);

    for (k=0; k<=n-1; k++)
    { 
    	d=0.0;
    	
        for (i=k; i<=n-1; i++)
        {
        	for (j=k; j<=n-1; j++)
          	{ 
          		t=i*n+j; 
          		p=fabs(a[t]);
          		
            	if (p>d) 
            	{ 
            		d=p; 
            		is[k]=i; 
            		js[k]=j;
            	}
          	}
        }
        
        if (d+1.0==1.0)
          { 
          	free(is);
          	free(js); 
            return(0);
          }
        
        if (is[k]!=k)
        {
        	for (j=0; j<=n-1; j++)
            { 
            	u=k*n+j; 
            	v=is[k]*n+j;
              	p=a[u]; 
              	a[u]=a[v]; 
              	a[v]=p;
            }
        }
        
        if (js[k]!=k)
        {
        	for (i=0; i<=n-1; i++)
            { 
            	u=i*n+k; 
            	v=i*n+js[k];
              	p=a[u]; 
              	a[u]=a[v]; 
              	a[v]=p;
            }
        }
            
        t=k*n+k;
        a[t]=1.0/a[t];
        
        for (j=0; j<=n-1; j++)
        {
        	if (j!=k)
            {
            	u=k*n+j; 
            	a[u]=a[u]*a[t];
            }
        }
            
        for (i=0; i<=n-1; i++)
        {
        	if (i!=k)
            {
            	for (j=0; j<=n-1; j++)
              	{
              		if (j!=k)
                	{
                	   u=i*n+j;
                  	   a[u]=a[u]-a[i*n+k]*a[k*n+j];
                	}
                }
            }
        }
               
        for (i=0; i<=n-1; i++)
        {
            if (i!=k)
            { 
            	u=i*n+k; 
            	a[u]=-a[u]*a[t];
            }
        }
    }
      
    for (k=n-1; k>=0; k--)
    { 
    	if (js[k]!=k)
    	{
          for (j=0; j<=n-1; j++)
          { 
            u=k*n+j; 
            v=js[k]*n+j;
            p=a[u]; 
            a[u]=a[v]; 
            a[v]=p;
          }
        }
        
        if (is[k]!=k)
        {
          for (i=0; i<=n-1; i++)
          { 
            u=i*n+k; 
            v=i*n+is[k];
            p=a[u]; 
            a[u]=a[v]; 
            a[v]=p;
          }
       }
    }
      
    free(is); 
    free(js);
    
    return(1);
}

/********************************************
    8�� ��������ʸ���Ĳ�ˣ�����µ�ʸ��
    c = a x b
    | i  j  k |
    |ax  ay az|=(ay*bz-az*by)i+(az*bx-ax*bz)j+(ax*by-ay*bx)k
    |bx  by bz|
*********************************************/
void MatrixCrossMultiply(float32 a[],float32 b[],float32 c[])
{
    c[0] = a[1]*b[2]-a[2]*b[1];
    c[1] = a[2]*b[0]-a[0]*b[2];
    c[2] = a[0]*b[1]-a[1]*b[0];

    return;
}

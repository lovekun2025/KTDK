
#include  "Includes.h"
#include "ktUart.h"


//�û�����Э����ʾ��
uint8_t getRxFrame_x_x()
{
  uint16_t i = 0;
  uint16_t dataLengthTemp = 0;
  uint16_t dataPosTemp = 0;
  uint16_t rxFrameLength = 0;
  //uint16_t crcTemp;
  uint16_t startPos = 0;
  
  static uint8_t  frameSyn = 0;
  static uint16_t rxLengthSum = 0;
  static uint16_t destPos = 0;  
 
  ktUart0IdleIntDisable();
  ktUart0RxReady = 0;
  dataLengthTemp  = ktUart0RxLength;
  dataPosTemp = ktUart0RxPos;
  ktUart0IdleIntEnable();
  //����������ݳ���
  if(dataLengthTemp > RX_JF_FRAME_LENGTH_MAX)
  {
    rxLengthSum = 0;
    frameSyn = 0;
    return 1 ;
  }
    
  destPos = rxLengthSum;
  rxLengthSum = rxLengthSum + dataLengthTemp;
  if(rxLengthSum > RX_JF_FRAME_LENGTH_MAX)
  {
    destPos = 0;
    frameSyn = 0;
    rxLengthSum = dataLengthTemp;
  }
  
  copyDataFromRxBuff(ktUart0RxBuff1 + destPos,ktUart0RxBuff,dataPosTemp,dataLengthTemp,KT_UART0_RX_BUFF_LEN);
  
  if(rxLengthSum < RX_JF_FRAME_LENGTH_MIN) //������С���ݰ�
    return 2;  
  
  //��1�����ҵ�֡ͷ 55 AA
  if(frameSyn == 0)
  {
    for(i = 0; i < (rxLengthSum - 1); i++)
    {
      if((ktUart0RxBuff1[i] == 0x55) && (ktUart0RxBuff1[(i + 1)] == 0xAA))
      {
        startPos = i;
        frameSyn = 1;
        break;
      }   
    }
    
    if(frameSyn == 0)   //û�ҵ�֡ͷ���ص���ʼλ��
    {
      rxLengthSum = 0;
      return 3;
    }
    
    if((frameSyn == 1) && (startPos > 0))  //ͬ���ɹ�����֡ͷ���м�λ��
    {
      rxLengthSum = rxLengthSum - startPos;
      memcpy(ktUart0RxBuff1,ktUart0RxBuff1 + i,rxLengthSum);
    }
  }
  
  if(frameSyn == 1)
  {
    rxFrameLength = ktUart0RxBuff1[3] +  6; //ÿ֡�����ݳ���=����+6
    
    if(rxFrameLength > rxLengthSum)  //û��ȫ
      return 4;
    
    rxLengthSum = 0;
    frameSyn = 0;
    
    if(ktUart0RxBuff1[rxFrameLength - 1] != 0xF0)
      return 5;
    
    //return 0;
    //���У��
    if(ktUart0RxBuff1[rxFrameLength - 2] == CheckXor(ktUart0RxBuff1 + 2,rxFrameLength - 4))
      return 0;
    else
      return 6;
  } 
  
  rxLengthSum = 0;
  
  return 7;
  
}

//�û�����Э�鴦��ʾ��
void rxFrameDeal_x_x()
{  
  if(0 == getRxFrame_x_x())    //����������ݰ�
  {
  }
}


//�û�����Э����ʾ��
void makeJfFrame_x_x()
{
  
  ktUart0TxLength=30;
  
  ktUart0TxBuff[0] = 0x55;
  ktUart0TxBuff[1] = 0xAA;
  ktUart0TxBuff[2] = 0x32;
  ktUart0TxBuff[3] = 0x18;
  ktUart0TxBuff[4] = 0xD9;
  ktUart0TxBuff[5] = 0x0C;   
  
  make_F2I16_HL_FSCALE(InertialDataIns[0],&ktUart0TxBuff[6],JF_GYRO_SACLE,JF_GYRO_MAX);
  make_F2I16_HL_FSCALE(InertialDataIns[1],&ktUart0TxBuff[8],JF_GYRO_SACLE,JF_GYRO_MAX);
  make_F2I16_HL_FSCALE(InertialDataIns[2],&ktUart0TxBuff[10],JF_GYRO_SACLE,JF_GYRO_MAX);
  
  make_F2I16_HL_FSCALE(InertialDataIns[3],&ktUart0TxBuff[12],JF_ACCE_SACLE,JF_ACCE_MAX);
  make_F2I16_HL_FSCALE(InertialDataIns[4],&ktUart0TxBuff[14],JF_ACCE_SACLE,JF_ACCE_MAX);
  make_F2I16_HL_FSCALE(InertialDataIns[5],&ktUart0TxBuff[16],JF_ACCE_SACLE,JF_ACCE_MAX);
  
//  //
//  ..............
//  //
  
  Ins_Timer++; //�趨Ϊ16�޷�������,1���ֽڣ�255ѭ��
  if(Ins_Timer>255)
  {
    Ins_Timer = 0;
  }
}





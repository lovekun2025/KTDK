#include "nav_interface.h"
#include "nav_globalctl.h"
//#include ".\Message\Message.h"
//#include ".\Device\Device.h"
//#include "GNSS\GNSS_PARA.h"
//#include ".\Message\msg_Qsens.h"


//int32_t Backup_Na[3],Backup_Ng[3];
int Backup_Na[3],Backup_Ng[3];
float IMU_temp;

nav_QSENS_NavData1 g_stNavOutput1;
nav_QSENS_NavData1 g_stNavOutput2;

nav_QSENS_NavData1* GetNavResult()
{
	return &g_stNavOutput1;
}
nav_QSENS_NavData1* GetNavResult2()
{
	return &g_stNavOutput2;
}

#ifdef SIMULATION
char Simulink_Begin = 0;
#endif


struct _MAGRESULT_RW_FLASH
{
    float kpm[3];
    float k0m[3];
};
typedef struct _PRESSRESULT_RW_FLASH PRESSRESULT_RW_FLASH;
struct _PRESSRESULT_RW_FLASH
{
    float kph;
    float k0h;
};

union PRESSTRANSFORMATION
{
    PRESSRESULT_RW_FLASH Press_RW_Flash;
    unsigned char PressPara[16];    
};

void nav_sen_read0(ST_IN_DATA *stIn, NAVCTL *navctl)
{
	int i;
    unsigned char Sample_Err = 0;

	/*******************GPS*********************/

	navctl->gpsinput.UTC = 0;
	
	navctl->gpsinput.lamda = 116.0 / NAV_RAD;
	navctl->gpsinput.B = 40.0 / NAV_RAD;
	navctl->gpsinput.h = 0.0;
	navctl->gpsinput.sigRat = 120;
	navctl->gpsinput.status = 1;
	navctl->gpsinput.hdop = 1.0;
	navctl->gpsinput.backup_h = navctl->gpsinput.h;	    
	navctl->gpsinput.gga_status = 1;
	
	navctl->ucDoubleAntennaEnable = 1;	
	
	if (1)
	{
		navctl->gpsinput.vel = 0.0;
		navctl->gpsinput.heading = 0.0;
		navctl->gpsinput.UpdatVel = 1;
		navctl->gpsinput.heading = 0.0 / NAV_RAD;//confirmed!!!
		stIn->flgGprmcAvalable = 0;
		navctl->gpsinput.gps_vx = 0.0;
        navctl->gpsinput.gps_vy = 0.0;
        navctl->gpsinput.gps_vz = 0.0;
    }   

/***************?????******************/	
	memcpy(Backup_Ng, stIn->Ng, sizeof(stIn->Ng));
	memcpy(Backup_Na, stIn->Na, sizeof(stIn->Na));

        IMU_temp = stIn->temperature;


	// ��ǿ�Ƹ�ֵ
	if (stIn->flgMagAvalabel == 1)
	{
		for(i=0;i<3;i++) navctl->EquipAxis.oriaxis.Nmag[i] =  stIn->Nmag[i];
		navctl->cali_mag.UpdatFlg = stIn->flgMagAvalabel;
		stIn->flgMagAvalabel = 0;
	}
	
	
   
	    
    for(i=0;i<3;i++){
        if(fabs((double)Backup_Na[i])>80000)
            Sample_Err = 1;
    }
 
 
	navctl->EquipAxis.Sampe_Interval = 1;
 
	if(Sample_Err == 0)
    {
        for(i=0;i<3;i++){//lig
            navctl->EquipAxis.oriaxis.Na[i] = Backup_Na[i];// - navctl->EquipAxis.backup_oriaxis.Na[i];
            navctl->EquipAxis.oriaxis.Ng[i] = Backup_Ng[i];// - navctl->EquipAxis.backup_oriaxis.Ng[i];	
        }
    }
    
	for(i=0;i<3;i++){
		navctl->EquipAxis.backup_oriaxis.Na[i] = Backup_Na[i];
		navctl->EquipAxis.backup_oriaxis.Ng[i] = Backup_Ng[i];
	}
}


void out_res_AHR(double Tq)
{   		
	int i;

	NAVCTL *navctl;
	navctl = getnavblk();
			
	unsigned int uTNav;

//	uTNav = (unsigned int)(navctl->navGM.navparameter.INS_t * 1000000.0);
	uTNav = (unsigned int)(navctl->navGM.navparameter.INS_t * 1000.0);

	g_stNavOutput1.uTNav = uTNav;
	g_stNavOutput1.uTImu = uTNav;
	g_stNavOutput1.uTMag = uTNav;

	
	//	navctl->outputframe.naviresult.ksaig = navctl->navGM.navparameter.MagComplf.ksaig;
//	navctl->outputframe.naviresult.thita = navctl->navGM.navparameter.MagComplf.thita;
//	navctl->outputframe.naviresult.gama = navctl->navGM.navparameter.MagComplf.gama;	
	navctl->outputframe.naviresult.ksaig = navctl->navGM.navparameter.MagComplf.ksaig  - navctl->satcalibration.ks[0];
	if(navctl->outputframe.naviresult.ksaig < 0.0)
          navctl->outputframe.naviresult.ksaig += 2.*CIRCLE_PI;
	navctl->outputframe.naviresult.thita = navctl->navGM.navparameter.MagComplf.thita - navctl->satcalibration.ks[1];
	navctl->outputframe.naviresult.gama = navctl->navGM.navparameter.MagComplf.gama - navctl->satcalibration.ks[2];	
	
	g_stNavOutput1.fYaw = navctl->outputframe.naviresult.ksaig;
	g_stNavOutput1.fPitch = navctl->outputframe.naviresult.thita;
	g_stNavOutput1.fRoll = navctl->outputframe.naviresult.gama;

	g_stNavOutput1.fPYaw = sqrt(navctl->cali_mag.magkfdone.MAG_P1[0*9+0]);
	g_stNavOutput1.fPPitch = sqrt(navctl->cali_mag.magkfdone.MAG_P1[1*9+1]);
	g_stNavOutput1.fPRoll = sqrt(navctl->cali_mag.magkfdone.MAG_P1[5*9+5]);
			
	g_stNavOutput1.usFImu = 1;
	g_stNavOutput1.usFMag =  navctl->cali_mag.UpdatFlg;
	if(navctl->cali_mag.flagmag == 2)
		g_stNavOutput1.status = 2;
	else
		g_stNavOutput1.status = 1;

	for(i=0;i<3;i++) 
		 g_stNavOutput1.fAcc[i] = navctl->EquipAxis.oriaxis.Na[i]/ACC_CALIBRATION*9.8;
	for(i=0;i<3;i++) 
		 g_stNavOutput1.fGyro[i] = navctl->EquipAxis.oriaxis.Ng[i]/GYRO_CALIBRATION/NAV_RAD;
	g_stNavOutput1.fTc = IMU_temp;
	for(i=0;i<3;i++) 
		 g_stNavOutput1.fdV[i] = navctl->cali_mag.Km1[i];
	for(i=0;i<3;i++) 
		 g_stNavOutput1.fdw[i] = navctl->cali_mag.Km1[i+3];
		
 //   g_stNavOutput1.fdw[2] = navctl->cali_mag.MagDeclination*NAV_RAD;
		

	for(i=0;i<3;i++) 
		 g_stNavOutput1.fMag[i] = navctl->EquipAxis.oriaxis.Nmag[i];
	for(i=0;i<3;i++) 
		 g_stNavOutput1.fMAcc[i] = navctl->cali_mag.bm1[i];

}


void nav_main1(ST_IN_DATA *stIn)
{
		NAVCTL *navctl;
		navctl = getnavblk();

#ifdef SIMULATION		
		char err;
		if(Simulink_Begin == 0)
		{
			InitFiles();
			Simulink_Begin = 1;
		}
#endif
		
     navctl->TimeCounter++;

		
	nav_sen_read0(stIn, navctl);//qi 20190508

 	if(navctl->firstGps  == 0)
	{			
		 navctl->firstGps = 1;
	
	 }
	else  if(navctl->firstGps == 1)
	{
			navctl->Navi_Status = 0;
			navctl->Navi_Status1 = 3;
			navctl->navGM.Get_nav_init(&(navctl->navGM)); 
			navctl->firstGps = 2;
    }
	 else 
	 {
		navctl->navGM.navparameter.Sample_INS = 1.0/INS_TIMES;			
		
		navctl->navGM.navparameter.INS_t = navctl->navGM.navparameter.INS_t + navctl->EquipAxis.Sampe_Interval*navctl->navGM.navparameter.Sample_INS;
       
		if(fabs(navctl->navGM.navparameter.INS_t - navctl->INS_T0) < 1.0e-4)
		{
			navctl->update_vdr = 1;
			navctl->update_vdr1 = 1;
		}
		else
		{
			navctl->update_vdr = 0;
		}
						
		if( navctl->update_vdr == 1 )
		{   
			navctl->INS_T1 =  navctl->INS_T0;
			navctl->INS_T0 = navctl->navGM.navparameter.INS_t  + KF_TIME;
 			navctl->navGM.navparameter.f1s = 1;  

		}

		navctl->Get_Pre_nav20ms(navctl, navctl->EquipAxis.oriaxis.Na, navctl->EquipAxis.oriaxis.Ng);

	}
	 
	out_res_AHR(navctl->navGM.navparameter.Sample_INS);


}


void nav_main2()
{	
	NAVCTL *navctl;
	navctl = getnavblk();


	  if(navctl->EquipAxis.Axis_Phase>0)
	  {
		navctl->navGM.Cal_nonlinear_complf2(navctl->navGM.navparameter.Sample_INS,navctl->EquipAxis.Input_SixAxis.Acc, navctl->EquipAxis.Input_SixAxis.Gyro, navctl->EquipAxis.Input_SixAxis.Magout_Cmp);
	  }
	  if(navctl->navGM.navparameter.INS_t > T_MagCali)
	  {
	   if(navctl->EquipAxis.Axis_Phase>0)
	   {
		  if(navctl->cali_mag.UpdatFlg ==1) 
		  { 
		   navctl->cali_mag.Get_Do_CaliMag(&navctl->cali_mag,navctl->EquipAxis.Input_SixAxis.Magout);
		  }
	  }
	 }
	if(navctl->navGM.navparameter.f1s){	
	 	navctl->EquipAxis.Get_Equip_Axis(&navctl->EquipAxis, navctl->navGM.navparameter.f1s, 0.0, navctl->navGM.navparameter.Sample_INS, 4);
#ifdef SIMULATION
 printf("\n % 2d  % 2d  % 2d % 2d % 2d % 8.3f % 2d % 8.3f % 8.3f % 8.3f % 8.3f % 8.3f  % 8.3f % 8.3f % 2d % 8.3f % 8.3f  % 8.3f % 8.3f",
 navctl->EquipAxis.Axis_Phase,navctl->Navi_Status1,navctl->Navi_Status2,0,navctl->gpsinput.gga_status,navctl->navGM.navparameter.INS_t,
 navctl->ucDoubleAntennaEnable,navctl->g_Gps.Double_Antenna_Heading,navctl->com_apply.FOG_KS,navctl->com_apply.FOG_THITA,navctl->com_apply.FOG_GAMA,
 navctl->navGM.navparameter.MagComplf.ksaig*NAV_RAD,navctl->navGM.navparameter.MagComplf.thita*NAV_RAD,navctl->navGM.navparameter.MagComplf.gama*NAV_RAD,navctl->cali_mag.status,
 navctl->navGM.navparameter.MagComplf.q[0],navctl->navGM.navparameter.MagComplf.q[1],navctl->navGM.navparameter.MagComplf.q[2],navctl->navGM.navparameter.MagComplf.q[3]);
#endif	
		navctl->navGM.navparameter.f1s = 0;
	}
	 navctl->cali_mag.UpdatFlg = 0;



#ifdef SIMULATION

 //	if(navctl->EquipAxis.Axis_Phase>0)
	{
		OutputFile();
		ImuDataFile();
	}

#endif

}






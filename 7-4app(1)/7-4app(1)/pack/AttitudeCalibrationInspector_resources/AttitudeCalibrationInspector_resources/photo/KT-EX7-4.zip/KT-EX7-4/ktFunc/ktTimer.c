
#include "stm32f4xx_exti.h"
#include  "Includes.h"
#include "MGZ2067.h"
#include "MAX537.h"

#include "BMI323.h"
#include "ADXL357.h"
#include "iic.h"


/*
/////////////////////ktTimerMap///////////////////////////////
               GD32E103xB/GD32F103xB       STM32F405RG(GD32F405)     STM32F103xB   ............        
ktTimer0             TIMER2                      TIM2
ktTimer1                                         TIM3
ktTimer2
ktTimer3
ktTimer4
ktTimer5
ktTimer6
......
*/

#if defined(GD32E103V_MD) || defined(GD32F10X_MD)

void ktTimer0Init()
{
  timer_parameter_struct timer_initpara;
  
  rcu_periph_clock_enable(RCU_TIMER2);
  
  // 120M��Դ��TIMER2����APB1�ϣ�APB1��������60M��
  // ���ǳ�����һ����Ƶ����2���ֲ���:if(APB1prescale =1)x1��else x 2������TIMER2����ƵΪ120M
  /* Ƶ��= SYSCLK /((PrescalerValue+1)*(TIM_Period+1))*/
  
  timer_deinit(TIMER2);            //reset timer2
  timer_struct_para_init(&timer_initpara);    // initial paraments
  
  /* TIMER2 configuration */
  timer_initpara.prescaler         = SystemCoreClock / 1000000 - 1;      // 1MHz --  1us
  timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;
  timer_initpara.counterdirection  = TIMER_COUNTER_UP;
  timer_initpara.period            = 1000000 / ktFrequency[frameID].sampleFrequencyHz - 1;
  timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;
  timer_init(TIMER2, &timer_initpara);
  
  timer_enable (TIMER2);
  
}



void ktTimer0UpdateIntEnable()
{
    timer_interrupt_enable(TIMER2, TIMER_INT_UP);  //ʹ�ܶ�ʱ���ж� 
}


void KT_TIMER0_IRQHandler()
{
  int i;
  
  if (timer_interrupt_flag_get(TIMER2, TIMER_INT_FLAG_UP) != RESET) //��ʱ���ļ���ģʽ���������жϣ���ײ���������һ�¡�
  { 
    /* Clear TIM2 update interrupt */ 
    timer_interrupt_flag_clear(TIMER2, TIMER_INT_FLAG_UP);   // ���ϸ����ж�
    




    
    IMUOriginalData[0]  = SPI_Data[0];    
    IMUOriginalData[1]  = SPI_Data[1];     
    IMUOriginalData[2]  = -SPI_Data[2];
    
    IMUOriginalData[3]  = SPI_Data[4];    
    IMUOriginalData[4]  = -SPI_Data[3]; 
    IMUOriginalData[5]  = -SPI_Data[5];
    
    IMUOriginalData[6]  = SPI_Data[6]; 

#ifdef IIR_FILER_1_ENABLE
    if(FilterFlag == VALID)
    {
      ktIIRLowPassFilterDeal(&IMUOriginalData[0],&LowPassFilter1[0]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[1],&LowPassFilter1[1]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[2],&LowPassFilter1[2]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[3],&LowPassFilter1[3]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[4],&LowPassFilter1[4]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[5],&LowPassFilter1[5]);  
    }
#endif
    
    
    //�ۼ�
    for (i = 0; i < SENSOR_NUMBER; i++)
    {
      InertialDataInsSum[i] +=  IMUOriginalData[i];
    }
    
    count_ready++;
    count_of_sumAD++;   
    
    //��������
    if((count_of_sumAD % (ktFrequency[frameID].sampleFrequencyHz / ktFrequency[frameID].calFrequencyHz)) == 0)
    {
      for (i = 0; i < SENSOR_NUMBER; i++)
      {
        InertialDataEven[i] = InertialDataInsSum[i] / (ktFrequency[frameID].sampleFrequencyHz / ktFrequency[frameID].calFrequencyHz);
        InertialDataInsSum[i] =  0.0;
      } 
      IMUData_Ready = VALID;
    }      
  } 
}


#endif

#if defined(STM32F40XX)

void ktTimer0Init()
{
  
  uint32_t  Perod =   1000000 / ktFrequency[frameID].sampleFrequencyHz - 1;
  uint32_t  Prescaler = SystemCoreClock / 1000000 - 1; ; 
  
  TIM_TimeBaseInitTypeDef  TIMER_InitStructure;
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);  
  RCC->DCKCFGR |= (1 << 24);//GDF405��STF405�ڶԶ�ʱ��ʱ��������ʱ����һ�����𣬸�DCKCFGRλ��1��Ϊ�����߷�Ƶ�ı������ն�����HCLK = 168M
  TIMER_InitStructure.TIM_Period = Perod;
  TIMER_InitStructure.TIM_Prescaler = Prescaler;
  TIMER_InitStructure.TIM_CounterMode = TIM_CounterMode_Up; 
  TIMER_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
  TIM_TimeBaseInit(TIM2,&TIMER_InitStructure);
  
  TIM_Cmd(TIM2,ENABLE);
  
}


void ktTimer0UpdateIntEnable()
{
  TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
}
//float gyro[3],acc[3],acc_t[3],gyro_t[3];
//void KT_TIMER0_IRQHandler()
//{
//  int i;
//  
//  if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
//  {      
//    
//    TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
//    MGZ2067_Get_Data(0,&gyro[0],&gyro_t[0]);
//    MGZ2067_Get_Data(1,&gyro[1],&gyro_t[1]);    
//    MGZ2067_Get_Data(2,&gyro[2],&gyro_t[2]);  
//    MAX537_Get_Data(0,&acc[0],&acc_t[0]);
//    MAX537_Get_Data(1,&acc[1],&acc_t[1]);
//    MAX537_Get_Data(2,&acc[2],&acc_t[2]);
//     
//    IMUOriginalData[0]  = gyro[0];    
//    IMUOriginalData[1]  = gyro[1];     
//    IMUOriginalData[2]  = gyro[2];
//    
//    
//    IMUOriginalData[3]  = acc[0];
//    IMUOriginalData[4]  = acc[1]; 
//    IMUOriginalData[5]  = acc[2];
//    
//    
//    IMUOriginalData[6]  = SPI_Data[15]; 
//    
//    IMUOriginalData[7]  = SPI_Data[0];    
//    IMUOriginalData[8]  = SPI_Data[1]; 
//    IMUOriginalData[9]  = SPI_Data[2];
//    
//    IMUOriginalData[10]  = SPI_Data[3];    
//    IMUOriginalData[11]  = SPI_Data[4]; 
//    IMUOriginalData[12]  = SPI_Data[5];    
//    
//    IMUOriginalData[13]  = SPI_Data[6];    
//    IMUOriginalData[14]  = SPI_Data[7]; 
//    IMUOriginalData[15]  = SPI_Data[8];    
//    
//    
//#ifdef IIR_FILER_1_ENABLE
//    if(FilterFlag == VALID)
//    {
//      ktIIRLowPassFilterDeal(&IMUOriginalData[0],&LowPassFilter1[0]);  
//      ktIIRLowPassFilterDeal(&IMUOriginalData[1],&LowPassFilter1[1]);  
//      ktIIRLowPassFilterDeal(&IMUOriginalData[2],&LowPassFilter1[2]);  
//      ktIIRLowPassFilterDeal(&IMUOriginalData[3],&LowPassFilter1[3]);  
//      ktIIRLowPassFilterDeal(&IMUOriginalData[4],&LowPassFilter1[4]);  
//      ktIIRLowPassFilterDeal(&IMUOriginalData[5],&LowPassFilter1[5]);  
//    }
//#endif
//    
//    //�ۼ�
//    for (i = 0; i < SENSOR_NUMBER; i++)
//    {
//      InertialDataInsSum[i] +=  IMUOriginalData[i];
//    }
//    
//    count_ready++;
//    count_of_sumAD++;   
//    
//    //��������
//    if((count_of_sumAD % (ktFrequency[frameID].sampleFrequencyHz / ktFrequency[frameID].calFrequencyHz)) == 0)
//    {
//      for (i = 0; i < SENSOR_NUMBER; i++)
//      {
//        InertialDataEven[i] = InertialDataInsSum[i] / (ktFrequency[frameID].sampleFrequencyHz / ktFrequency[frameID].calFrequencyHz);
//        InertialDataInsSum[i] =  0.0;
//      } 
//      IMUData_Ready = VALID;
//    }
//  }
//}
unsigned short int iic_value[4]; 
float Gyro_Data[6];
float Gyro_Temp[2];
extern int Timer_Counter_QiYa;
void KT_TIMER0_IRQHandler()
{
  int i;
  
  if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
  {      
    TIM_ClearITPendingBit(TIM2,TIM_IT_Update);// 
    if(BMI323_GyroDrdy(0) && BMI323_GyroDrdy(1))
    {
      BMI323_Get_GyroTData(0, &Gyro_Data[0], &Gyro_Temp[0]);
      BMI323_Get_GyroTData(1, &Gyro_Data[3], &Gyro_Temp[1]);
      //��û����ִ���
      SPI_Data[0] = (Gyro_Data[3] - Gyro_Data[1])*0.5;
      SPI_Data[1] = (Gyro_Data[0] - Gyro_Data[4])*0.5;
      SPI_Data[2] = (Gyro_Data[2] - Gyro_Data[5])*0.5;
      BMI323_Data_Coversion(&SPI_Data[0], &SPI_Data[0], BMI323_GYRO_RANGE_500);//���ת��
      BMI323_Data_Coversion(&Gyro_Data[0], &Gyro_Data[0], BMI323_GYRO_RANGE_500);//���ת��
      SPI_Data[7] = (Gyro_Temp[0] + Gyro_Temp[1])*0.5;
    }
    
    ADXL357_Get_Data(0, &SPI_Data[3], &SPI_Data[6]); 
    Timer_Counter_QiYa++; 
    Get_MS5607_data();    
    
    
//    IMUOriginalData[0]  = SPI_Data[0];  //����
//    IMUOriginalData[1]  = -SPI_Data[2];     //����   
//    IMUOriginalData[2]  = SPI_Data[1];    //����
//    
//    IMUOriginalData[3]  = -SPI_Data[3];  //�ӱ�
//    IMUOriginalData[4]  = -SPI_Data[5]; //�ӱ�
//    IMUOriginalData[5]  = -SPI_Data[4];    //�ӱ� 
    
    IMUOriginalData[0]  = -SPI_Data[1];
    IMUOriginalData[1]  = -SPI_Data[0];  //����
    IMUOriginalData[2]  =  -SPI_Data[2];     //���� 
    
    IMUOriginalData[3]  = SPI_Data[4];     //�ӱ�
    IMUOriginalData[4]  = SPI_Data[3];     //�ӱ�
    IMUOriginalData[5]  = -SPI_Data[5];    //�ӱ�   
    
    
    
    IMUOriginalData[6]  = SPI_Data[6]; //�ӱ��¶�
    IMUOriginalData[7]  = SPI_Data[7]; //�����¶�   
    
    IMUOriginalData[8]  = Gyro_Data[0]; //����1X
    IMUOriginalData[9]  = Gyro_Data[1]; //����1Y
    IMUOriginalData[10]  = Gyro_Data[2]; //����1Z
    
    IMUOriginalData[11]  = SPI_Data[11]; //��ѹ
    
    IMUOriginalData[13]  = 0;//iic_value[0]; //mag��
    IMUOriginalData[14]  = 0;//iic_value[1];
    IMUOriginalData[15]  = 0;//iic_value[2];    
      
    
#ifdef IIR_FILER_1_ENABLE
    if(FilterFlag == VALID)
    {
      ktIIRLowPassFilterDeal(&IMUOriginalData[0],&LowPassFilter1[0]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[1],&LowPassFilter1[1]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[2],&LowPassFilter1[2]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[3],&LowPassFilter1[3]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[4],&LowPassFilter1[4]);  
      ktIIRLowPassFilterDeal(&IMUOriginalData[5],&LowPassFilter1[5]);  
    }
#endif
    
    //�ۼ�
    for (i = 0; i < SENSOR_NUMBER; i++)
    {
      InertialDataInsSum[i] +=  IMUOriginalData[i];
    }
    
    count_ready++;
    count_of_sumAD++;   
    
    //��������
    if((count_of_sumAD % (ktFrequency[frameID].sampleFrequencyHz / ktFrequency[frameID].calFrequencyHz)) == 0)
    {
      for (i = 0; i < SENSOR_NUMBER; i++)
      {
        InertialDataEven[i] = InertialDataInsSum[i] / (ktFrequency[frameID].sampleFrequencyHz / ktFrequency[frameID].calFrequencyHz);
        InertialDataInsSum[i] =  0.0;
      } 
      IMUData_Ready = VALID;
    }
  }
}


void ktTimer1Init()
{
  
  TIM_TimeBaseInitTypeDef  TIMER_InitStructure;
  
  uint32_t  Perod = 4000 - 1;     
  uint32_t  Prescaler = 168 - 1;  
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);  
  RCC->DCKCFGR |= (1 << 24);//GDF405��STF405�ڶԶ�ʱ��ʱ��������ʱ����һ�����𣬸�DCKCFGRλ��1��Ϊ�����߷�Ƶ�ı������ն�����HCLK = 168M
  TIMER_InitStructure.TIM_Period = Perod;
  TIMER_InitStructure.TIM_Prescaler = Prescaler;
  TIMER_InitStructure.TIM_CounterMode = TIM_CounterMode_Up; 
  TIMER_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
  TIM_TimeBaseInit(TIM3,&TIMER_InitStructure);
  
  TIM_Cmd(TIM3,ENABLE);
  
}

void ktTimer1Disable()
{
  TIM_Cmd(TIM3,DISABLE);
}

void ktTimer1ClearInt()
{
  TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  
}


void ktTimer1UpdateIntEnable()
{
  TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
}

void ktTimer1UpdateIntDisable()
{
  TIM_ITConfig(TIM3,TIM_IT_Update,DISABLE);
}


void KT_TIMER1_IRQHandler()
{
  if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
  { 
//    SendCanData00();
//    SendCanData01();
  }
  TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
}

void TIM3_Int_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  ///ʹ��TIM3ʱ��
	
        TIM_TimeBaseInitStructure.TIM_Period = arr; 	//�Զ���װ��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;  //��ʱ����Ƶ
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);//��ʼ��TIM3
	
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE); //������ʱ��3�����ж�
	TIM_Cmd(TIM3,ENABLE); //ʹ�ܶ�ʱ��3
	
}

short int Iic_Value1 = 0,Iic_Value2 = 0,Iic_Value3 = 0;
unsigned char config_re;
int time_count = 0;
int case_i = 0;
char str[200]; 
char data_updata_flag = 0;
void TIM3_IRQHandler(void)//��ʱ��3�жϷ�����
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET) //����ж�
	{   
           
           switch (case_i)
          {
          case 0:
            set_Channel_iic(0xc3);
            data_updata_flag = 0;
            case_i = 1;
            break;
          case 1: 
            if(data_updata_flag==1)
            {
              
              Iic_Value1 = get_value_iic();
              set_Channel_iic(0xd3);
             data_updata_flag = 0;
              case_i = 2;
            }
            break;
          case 2: 
            if(data_updata_flag==1)
            {
              
             Iic_Value2 = get_value_iic();
             set_Channel_iic(0xe3);
             data_updata_flag = 0;
              case_i = 3;
            } 
            break;            
          case  3:
            if(data_updata_flag==1)
            {
             
             Iic_Value3 = get_value_iic();
             set_Channel_iic(0xc3);
             data_updata_flag = 0;
            iic_value[0] = Iic_Value3;//��ʱ����������Ū��X���Ƿ����
            iic_value[1] = Iic_Value2;
            iic_value[2] = Iic_Value1;
            iic_value[3] = 1;
              case_i = 1;
            } 
            break;
          default:
            break;
         }
//          time_count++;
//          if(time_count==10)
//          {
//            time_count = 0;
//           snprintf(str, 200,"%d %d %d %d %02X\r\n",iic_value[0],iic_value[1],iic_value[2],case_i,config_re);
//           snprintf(str, 200,"%d %d %d\r\n",iic_value[0],iic_value[1],iic_value[2]);
//           snprintf(str, 50,"%d\r\n",iic_value[0]);
//           PrintUartMessage(1 ,str ,200);  
//          }
        } 
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  //����жϱ�־λ
}
int a;
int b;
void EXTI15_10_IRQHandler(void)
{

  delay_us(2);
  if(READ_rdy==0)
  {
    a++;
  b++; 
    if(a ==1)
    { 
      a=0;
      data_updata_flag = 1;
    }
  }

  EXTI_ClearITPendingBit(EXTI_Line11);
}



#endif


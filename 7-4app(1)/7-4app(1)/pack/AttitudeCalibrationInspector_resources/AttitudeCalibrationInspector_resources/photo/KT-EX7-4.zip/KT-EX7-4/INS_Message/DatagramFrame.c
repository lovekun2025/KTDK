/**
 * @file ParseFrame.c
 * @author Qiaoyy@xlnav.com
 * @version V2.0
 * @date 2018-4-4
 * @brief  通讯帧解析框架
 * Copyright (c) 2018 XiLang Co. Ltd.
 * All rights reserved.
 */

 /* Includes ------------------------------------------------------------------*/
#include "Global.h"
//#include "Config.h"
#include "DatagramFrame.h"
/* Private typedef -----------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/*
 *  CCITT      CRC16:????X16+X12+X5+1,??????0x11021
 *  IEEE 802.3 CRC32:????X32+X26+X23+X22+X16+X12+X11+X10+X8+X7+X5+X4+X2+X1+1,?????0x104C11DB7
 *	Castagnoli_POLY_CRC32C: ????x32+x28+x27+x26+x25+x23+x22+x20+x19+x18+x14+x13+x11+x10+x9+x8+x6+1,????0x1EDC6F41
 */
#define CCITT_POLY16           (0x1021)
#define IEEE8023_POLY32        (0x04C11DB7)
#define Castagnoli_POLY_CRC32C (0x1EDC6F41)


/* Private variables ---------------------------------------------------------*/

/*- CRC? */
static const uint16_t CCITT_CRC16_TABLE[256]=
{
	/*- CCITT CRC16???????0x1021 */
	0x0000,0x1021,0x2042,0x3063,0x4084,0x50a5,0x60c6,0x70e7,0x8108,0x9129,0xa14a,0xb16b,0xc18c,0xd1ad,0xe1ce,0xf1ef,
	0x1231,0x0210,0x3273,0x2252,0x52b5,0x4294,0x72f7,0x62d6,0x9339,0x8318,0xb37b,0xa35a,0xd3bd,0xc39c,0xf3ff,0xe3de,
	0x2462,0x3443,0x0420,0x1401,0x64e6,0x74c7,0x44a4,0x5485,0xa56a,0xb54b,0x8528,0x9509,0xe5ee,0xf5cf,0xc5ac,0xd58d,
	0x3653,0x2672,0x1611,0x0630,0x76d7,0x66f6,0x5695,0x46b4,0xb75b,0xa77a,0x9719,0x8738,0xf7df,0xe7fe,0xd79d,0xc7bc,
	0x48c4,0x58e5,0x6886,0x78a7,0x0840,0x1861,0x2802,0x3823,0xc9cc,0xd9ed,0xe98e,0xf9af,0x8948,0x9969,0xa90a,0xb92b,
	0x5af5,0x4ad4,0x7ab7,0x6a96,0x1a71,0x0a50,0x3a33,0x2a12,0xdbfd,0xcbdc,0xfbbf,0xeb9e,0x9b79,0x8b58,0xbb3b,0xab1a,
	0x6ca6,0x7c87,0x4ce4,0x5cc5,0x2c22,0x3c03,0x0c60,0x1c41,0xedae,0xfd8f,0xcdec,0xddcd,0xad2a,0xbd0b,0x8d68,0x9d49,
	0x7e97,0x6eb6,0x5ed5,0x4ef4,0x3e13,0x2e32,0x1e51,0x0e70,0xff9f,0xefbe,0xdfdd,0xcffc,0xbf1b,0xaf3a,0x9f59,0x8f78,
	0x9188,0x81a9,0xb1ca,0xa1eb,0xd10c,0xc12d,0xf14e,0xe16f,0x1080,0x00a1,0x30c2,0x20e3,0x5004,0x4025,0x7046,0x6067,
	0x83b9,0x9398,0xa3fb,0xb3da,0xc33d,0xd31c,0xe37f,0xf35e,0x02b1,0x1290,0x22f3,0x32d2,0x4235,0x5214,0x6277,0x7256,
	0xb5ea,0xa5cb,0x95a8,0x8589,0xf56e,0xe54f,0xd52c,0xc50d,0x34e2,0x24c3,0x14a0,0x0481,0x7466,0x6447,0x5424,0x4405,
	0xa7db,0xb7fa,0x8799,0x97b8,0xe75f,0xf77e,0xc71d,0xd73c,0x26d3,0x36f2,0x0691,0x16b0,0x6657,0x7676,0x4615,0x5634,
	0xd94c,0xc96d,0xf90e,0xe92f,0x99c8,0x89e9,0xb98a,0xa9ab,0x5844,0x4865,0x7806,0x6827,0x18c0,0x08e1,0x3882,0x28a3,
	0xcb7d,0xdb5c,0xeb3f,0xfb1e,0x8bf9,0x9bd8,0xabbb,0xbb9a,0x4a75,0x5a54,0x6a37,0x7a16,0x0af1,0x1ad0,0x2ab3,0x3a92,
	0xfd2e,0xed0f,0xdd6c,0xcd4d,0xbdaa,0xad8b,0x9de8,0x8dc9,0x7c26,0x6c07,0x5c64,0x4c45,0x3ca2,0x2c83,0x1ce0,0x0cc1,
	0xef1f,0xff3e,0xcf5d,0xdf7c,0xaf9b,0xbfba,0x8fd9,0x9ff8,0x6e17,0x7e36,0x4e55,0x5e74,0x2e93,0x3eb2,0x0ed1,0x1ef0
};
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
 * @brief  初始化帧解析框架
 * @param
 * @return
*/
void InitFrameParse(ParseParam* io_ParseParam, uint8_t* i_pcBuffer, int32_t i_nBufferSize)
{
	int32_t i;
	for (i = 0; i < io_ParseParam->TransportFrameNumber; i++)
	{
		io_ParseParam->TransportFrameDefine[i].InitFunc(i_pcBuffer, i_nBufferSize, (uint32_t)io_ParseParam);
	}
}

/**
* @brief  初始化帧解析结构体
* @param
* @return
*/
void InitParseParam(ParseParam* io_ParseParam, uint8_t* pBuffer, int32_t nBufferSize)
{
	int32_t i;
	for (i = 0; i < io_ParseParam->TransportFrameNumber; i++)
	{
		io_ParseParam->cSelect[i] = 0x00;
	}
	io_ParseParam->nTailCounter = 0;
	io_ParseParam->nStep = PARSE_INITIAL;
	io_ParseParam->nReadCounter = 0;
	io_ParseParam->nFrameNumber = 0;
	io_ParseParam->nFrameCounter = 0;
	io_ParseParam->nBufferSize = nBufferSize;
	io_ParseParam->nErrorCode = 0;
	io_ParseParam->pBuffer = pBuffer;
	io_ParseParam->nFrameLength = 0;
	for (i = 0; i < io_ParseParam->nBufferSize; i++)
	{
		io_ParseParam->pBuffer[i] = 0x00;
	}
}

/**
 * @brief  清除帧解析结构体
 * @param
 * @return
*/
void ClearParseParam(ParseParam* io_ParseParam)
{
	//assert(io_ParseParam!=NULL);
	int32_t i;
	for (i = 0; i < io_ParseParam->TransportFrameNumber; i++)
	{
		io_ParseParam->cSelect[i] = 0;
	}
	io_ParseParam->nTailCounter = 0;
	io_ParseParam->nStep = PARSE_INITIAL;
	io_ParseParam->nReadCounter = 0;
	io_ParseParam->nFrameNumber = 0;
	io_ParseParam->nFrameCounter = 0;
	io_ParseParam->nFrameLength = 0;
	io_ParseParam->flagSync = 0;
}

/**
 * @brief
 * @param
 * @return
*/
void ParseFrame(CircularBuffer* buf, ParseParam* pParseParam, unsigned int nMaxReadTimes)
{
	unsigned char byte;
	uint32_t times = 0;
	unsigned char flag = 0x00;
	while ((PopCircularBuffer(&byte, buf) > 0) && (times < nMaxReadTimes))
	{
		times++;
		flag = ParseFrameByte(byte, pParseParam);
		if (flag!=0)
		{
			break;
		}
	}
}
void ParseFrame_DMA(DMA_CircularBuffer* dmaCBuffer, ParseParam* pParseParam, unsigned int nMaxReadTimes)
{
	unsigned char byte;
	uint32_t times = 0;
	unsigned char flag = 0x00;
	while ((PopDmaCircularBuffer(&byte, dmaCBuffer) > 0&& (times < nMaxReadTimes))) 
	{
       
		times++;
		flag = ParseFrameByte(byte, pParseParam);
		if (flag!=0)
		{
		  break;
		}
	}
}

/**
 * @brief
 * @param
 * @return
 * @todo 返回值处理 
 * @todo 错误码定义
*/
int err_hi;
int32_t ParseFrameByte(uint8_t i_ucByte, ParseParam* io_pParseParam)
{
	int32_t j = 0;
	int32_t nFrameID = 0;
	int32_t nGetAll = 0;
	int8_t nFoundOne = 0;

	if (io_pParseParam->nStep == PARSE_FOUND_HEAD)
	{
		// 校验帧头部首字节后字节
		nFoundOne = 0;
		for (j = 0; j < io_pParseParam->TransportFrameNumber; j++)
		{
			// 对于帧头首字节不符的跳过
			if (io_pParseParam->cSelect[j] != 1)
			{
				continue;
			}

			if (io_pParseParam->TransportFrameDefine[j].FrameHead[io_pParseParam->nFrameCounter] == (int8_t)i_ucByte)
			{
				nFoundOne = 1;
				io_pParseParam->cSelect[j] = 1;
			}
			else
			{
				io_pParseParam->cSelect[j] = 0;
			}
		}
		if (nFoundOne == 1)
		{
			io_pParseParam->pBuffer[io_pParseParam->nFrameCounter] = i_ucByte;
			io_pParseParam->nFrameCounter++;
			for (j = 0; j < io_pParseParam->TransportFrameNumber; j++)
			{
				if (io_pParseParam->cSelect[j] == 1)
				{
					if (io_pParseParam->TransportFrameDefine[j].FrameHeadLength == io_pParseParam->nFrameCounter)
					{
						io_pParseParam->nStep = PARSE_RECIEVE_DATA;
						io_pParseParam->nFrameNumber = j;
					}
				}
			}
		}
		else
		{
			ClearParseParam(io_pParseParam);
		}
	}
	else if (io_pParseParam->nStep == PARSE_RECIEVE_DATA)
	{
		// 接收数据
		io_pParseParam->pBuffer[io_pParseParam->nFrameCounter] = i_ucByte;
		io_pParseParam->nFrameCounter++;

		// 根据帧类型采用不同方法寻找帧尾
		if (io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].nFrameType == FIXED_LENGTH_FRAME)
		{
			// 固定长度帧 FIXED_LENGTH_FRAME
			if (io_pParseParam->nFrameCounter == io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameParamLength)
			{
				nGetAll = 1;
			}
		}
		else if (io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].nFrameType == SETTING_LENGTH_FRAME)
		{
			// 变长帧 SETTING_LENGTH_FRAME
			if (io_pParseParam->nFrameCounter > io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameParamLength)
			{			
				if (io_pParseParam->nFrameLength>0 && io_pParseParam->nFrameCounter == io_pParseParam->nFrameLength)
				{
					// 首先帧长度不能为0，当接收到的字节数与帧长度相同时则获得完整帧
					nGetAll = 1;
				}
				else if (io_pParseParam->nFrameLength == 0)
				{
					io_pParseParam->nFrameLength = io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].LengthFunc(io_pParseParam->pBuffer, io_pParseParam->nFrameCounter, (uint32_t)io_pParseParam);
				}
				else
				{
					// DO_NOTHING
				}
			}
			else if (io_pParseParam->nFrameCounter == io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameParamLength)
			{
				// 当到达设定的字节数时，取得帧的长度
				io_pParseParam->nFrameLength = io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].LengthFunc(io_pParseParam->pBuffer, io_pParseParam->nFrameCounter, (uint32_t)io_pParseParam);
			}
			else
			{
				// DO_NOTHING
			}

		}
		else if (io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].nFrameType == UNFIXED_LENGTH_FRAME)
		{
			// 不固定长度帧 UNFIXED_LENGTH_FRAME
			// 检测是否收到帧尾标志首字节
			if (i_ucByte == io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameTail[0])
			{
				io_pParseParam->nStep = PARSE_FOUND_TAIL;
				io_pParseParam->nTailCounter++;
			}
		}

		if (io_pParseParam->nFrameCounter > io_pParseParam->nBufferSize)
		{
			ClearParseParam(io_pParseParam);
			io_pParseParam->nErrorCode = 1;
			return 0;
		}
	}
	else if (io_pParseParam->nStep == PARSE_FOUND_TAIL)
	{
		// 收到帧尾标志并进行校验、解码
		io_pParseParam->pBuffer[io_pParseParam->nFrameCounter] = i_ucByte;
		io_pParseParam->nFrameCounter++;
		if (i_ucByte == io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameTail[io_pParseParam->nTailCounter])
		{
			io_pParseParam->nTailCounter++;
		}
		else
		{
			if (i_ucByte == io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameTail[0])
			{
				io_pParseParam->nTailCounter = 1;
			}
			else
			{
				io_pParseParam->nTailCounter = 0;
				io_pParseParam->nStep = PARSE_RECIEVE_DATA;
			}
		}
		if (io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].FrameParamLength == io_pParseParam->nTailCounter)
		{
			nGetAll = 1;
		}
	}
	// 寻找帧首个字节
	if (io_pParseParam->nStep == PARSE_INITIAL)
	{
		nFoundOne = 0;
		for (j = 0; j < io_pParseParam->TransportFrameNumber; j++)
		{
			if (io_pParseParam->TransportFrameDefine[j].FrameHead[0] == (int8_t)i_ucByte)
			{
				// 遍历各类型帧头并标记可能
				if (io_pParseParam->TransportFrameDefine[j].FrameHeadLength > 1)
				{
					nFoundOne = 1;
					io_pParseParam->cSelect[j] = 1;
				}
				// 对于帧头只有一字节的情况则直接进入接收状态
				else if (io_pParseParam->TransportFrameDefine[j].FrameHeadLength == 1)
				{
					nFoundOne = 2;
					io_pParseParam->cSelect[j] = 1;
					io_pParseParam->nFrameNumber = j;
					break;
				}
				else
				{
					ClearParseParam(io_pParseParam);
				}				
			}
		}

		if (nFoundOne == 1)
		{
			io_pParseParam->nStep = PARSE_FOUND_HEAD;
			io_pParseParam->pBuffer[0] = i_ucByte;
			io_pParseParam->nFrameCounter = 1;
			nFoundOne = 0;
		}
		else if (nFoundOne == 2)
		{
			io_pParseParam->nStep = PARSE_RECIEVE_DATA;
			io_pParseParam->pBuffer[0] = i_ucByte;
			io_pParseParam->nFrameCounter = 1;
		}
		else
		{
			ClearParseParam(io_pParseParam);
		}
	}
	if (nGetAll == 1)
	{
		// 进行帧校验
		if (io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].CheckFunc(io_pParseParam->pBuffer, io_pParseParam->nFrameCounter, (uint32_t)io_pParseParam) == FUNC_SUCCESS)
		{
			// 实际的解析一帧数据的函数
			io_pParseParam->TransportFrameDefine[io_pParseParam->nFrameNumber].ParseFunc(io_pParseParam->pBuffer, io_pParseParam->nFrameCounter, (uint32_t)io_pParseParam);

			nFrameID = io_pParseParam->nFrameNumber + 1;
		}
		else
		{
			// 校验错误则返回负的帧号
			nFrameID = -io_pParseParam->nFrameNumber - 1;
                        err_hi++;
		}

		ClearParseParam(io_pParseParam);
		return nFrameID;
	}
	return 0;
}


/**
 * @brief 低字节低位在前 Inter格式读取
 * @param
 * @return
 * @warning 读后 pBuffer 不移动
 * @warning 有越界风险，nBeginBit小于pBuffer字节数*8， nBitNumber 小于等于（pBuffer字节数*8-nBeginBit）
*/
uint32_t GetBit(uint8_t* pBuffer, int32_t nBeginBit, int32_t nBitNumber)
{
	int32_t i;
	if (nBitNumber > 8 * sizeof(uint32_t))
	{
		return FUNC_ERROR;
	}
	int32_t nFirstByte = nBeginBit / 8; // 计算第一个字节位置
	int32_t nBitInBeginByte = nBeginBit % 8; // 计算第一个字节位置中的起始位
	int32_t nLeftBits = nBitNumber - (8 - nBitInBeginByte); // 读完第一个字节的位后还有多少位要读
	int32_t nLeftBytes = nLeftBits / 8; // 剩余位数对应的整字节数
	int32_t nLastBits = nLeftBits % 8; // 最后一个字节对应位数
	uint32_t result = (uint32_t)0x00;

	result = pBuffer[nFirstByte] >> nBitInBeginByte; // 读第一个字节中的位数
	for (i = 0; i < nLeftBytes; i++)
	{
		result = result | ((uint32_t)(pBuffer[nFirstByte + i + 1])) << (8 - nBitInBeginByte + i * 8);
	}

	if (nLeftBits > 0)
	{
		result = result | ((uint32_t)(pBuffer[nFirstByte + nLeftBytes + 1] & (0xff >> (8 - nLastBits))) << (nLeftBytes * 8 + 8 - nBitInBeginByte));
	}
	else if (nLeftBits < 0)
	{
		result = result & (0xff >> (-nLastBits + nBitInBeginByte));
	}
	else
	{

	}

	return result;
}


/**
 * @brief 高字节高位在前 Motorola格式读取
 * @param
 * @return
 * @warning 读后 pBuffer 不移动
 * @warning 有越界风险，nBeginBit小于pBuffer字节数*8， nBitNumber 小于等于（pBuffer字节数*8-nBeginBit）
*/
uint32_t GetBitMsb(uint8_t* pBuffer, int32_t nBeginBit, int32_t nBitNumber)
{
	int32_t i;
	if (nBitNumber > 8 * sizeof(uint32_t))
	{
		return FUNC_ERROR;
	}
	int32_t nFirstByte = nBeginBit / 8; // 计算第一个字节位置
	int32_t nBitInBeginByte = nBeginBit % 8 + 1; // 计算第一个字节位置中的起始位
	int32_t nLeftBits = nBitNumber - nBitInBeginByte; // 读完第一个字节的位后还有多少位要读
	int32_t nLeftBytes = 0; // 剩余位数对应的整字节数
	int32_t nLastBits = 0; // 最后一个字节对应位数
	uint32_t result = (uint32_t)0x00;

	result = pBuffer[nFirstByte] & (0xff >> (8 - nBitInBeginByte)); // 读第一个字节中的位数
	
	if (nLeftBits > 0)
	{
		nLeftBytes = nLeftBits / 8;
		nLastBits = nLeftBits % 8;
		for (i = 1; i <= nLeftBytes; i++)
		{
			result = result<<((i) * 8) | (uint32_t)(pBuffer[nFirstByte + i]);
		}
		result = result<<nLastBits | ((uint32_t)(pBuffer[nFirstByte + nLeftBytes + 1] >> (8 - nLastBits))); // 此处有越界风险
	}
	else if (nLeftBits < 0)
	{
		result = result >> (-nLeftBits);
	}
	else
	{

	}

	return result;
}


/**
 * @brief
 * @param
 * @return
*/
uint16_t GetUShort(uint8_t* pBuffer)
{
	uint16_t retval;
	memcpy(&retval, pBuffer, sizeof(uint16_t));
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
int16_t GetShort(uint8_t* pBuffer)
{
	int16_t retval;
	memcpy(&retval, pBuffer, sizeof(int16_t));
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
uint32_t GetULong(uint8_t* pBuffer)
{
	uint32_t retval;
	memcpy(&retval, pBuffer, sizeof(uint32_t));
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
int32_t GetLong(uint8_t* pBuffer)
{
	int32_t retval;
	memcpy(&retval, pBuffer, sizeof(int32_t));
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
double GetDouble(uint8_t* pBuffer)
{
	double retval;
	memcpy(&retval, pBuffer, sizeof(double));
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
float GetFloat(uint8_t* pBuffer)
{
	float retval;
	memcpy(&retval, pBuffer, sizeof(float));
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
uint16_t GetUShortContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	uint16_t retval;
	memcpy(&retval, pBuffer, sizeof(uint16_t));
	*nCounter = *nCounter + sizeof(uint16_t);
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
int16_t GetShortContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	int16_t retval;
	memcpy(&retval, pBuffer, sizeof(int16_t));
	*nCounter = *nCounter + sizeof(int16_t);
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
uint32_t GetULongContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	uint32_t retval;
	memcpy(&retval, pBuffer, sizeof(uint32_t));
	*nCounter = *nCounter + sizeof(uint32_t);
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
int32_t GetLongContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	int32_t retval;
	memcpy(&retval, pBuffer, sizeof(int32_t));
	*nCounter = *nCounter + sizeof(int32_t);
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
double GetDoubleContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	double retval;
	memcpy(&retval, pBuffer, sizeof(double));
	*nCounter = *nCounter + sizeof(double);
	return retval;
	//return *((double*)pBuffer);
}

/**
 * @brief
 * @param
 * @return
*/
float GetFloatContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	float retval;
	memcpy(&retval, pBuffer, sizeof(float));
	*nCounter = *nCounter + sizeof(float);
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
uint16_t GetUShortBigEndContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	uint16_t retval;
	int32_t size = sizeof(uint16_t);
	uint8_t tempBuffer[sizeof(uint16_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	*nCounter = *nCounter + size;
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
int16_t GetShortBigEndContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	int16_t retval;
	int32_t size = sizeof(int16_t);
	uint8_t tempBuffer[sizeof(int16_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	*nCounter = *nCounter + size;
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
uint32_t GetULongBigEndContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	uint32_t retval;
	int32_t size = sizeof(uint32_t);
	uint8_t tempBuffer[sizeof(uint32_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	*nCounter = *nCounter + size;
	return retval;
}

/**
 * @brief
 * @param
 * @return
*/
int32_t GetLongBigEndContinue(uint8_t* pBuffer, int32_t* nCounter)
{
	int32_t retval;
	int32_t size = sizeof(int32_t);
	uint8_t tempBuffer[sizeof(int32_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	*nCounter = *nCounter + size;
	return retval;
}


/**
* @brief
* @param
* @return
*/
uint16_t GetUShortBigEnd(uint8_t* pBuffer)
{
	uint16_t retval;
	int32_t size = sizeof(uint16_t);
	uint8_t tempBuffer[sizeof(uint16_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	return retval;
}

/**
* @brief
* @param
* @return
*/
int16_t GetShortBigEnd(uint8_t* pBuffer)
{
	int16_t retval;
	int32_t size = sizeof(int16_t);
	uint8_t tempBuffer[sizeof(int16_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	return retval;
}

/**
* @brief
* @param
* @return
*/
uint32_t GetULongBigEnd(uint8_t* pBuffer)
{
	uint32_t retval;
	int32_t size = sizeof(uint32_t);
	uint8_t tempBuffer[sizeof(uint32_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	return retval;
}

/**
* @brief
* @param
* @return
*/
int32_t GetLongBigEnd(uint8_t* pBuffer)
{
	int32_t retval;
	int32_t size = sizeof(int32_t);
	uint8_t tempBuffer[sizeof(int32_t)];
	int32_t i;
	for (i = 0; i < size; i++)
	{
		tempBuffer[i] = pBuffer[size - i - 1];
	}
	memcpy(&retval, tempBuffer, size);
	return retval;
}




/**
 * @brief  cb_crc16_ccitt CCITT CRC16??????
 * @param  data ????
 * @param  size ????
 * @return ????CRC16?
 */
uint16_t cb_crc16_ccitt(const uint8_t * pdata, uint32_t size)
{
	/*- ????? */
    uint32_t  i           = 0u;
    uint16_t  crc         = 0x0000u; /*-< CRC????? */
	uint16_t  index       = 0u; /*-< ???? */
	const uint8_t *data   = pdata;
	const uint16_t *table = CCITT_CRC16_TABLE; /*-< ??CCITT???? */

	/*- ??data??????? */
	if (NULL != data)
	{
		for (i=0u; i<size; i++)
		{
			index  = ( crc >> 8u ) ^ *data;
			data++;
		    crc = ( crc << 8u ) ^ table[index];
		}
	}
	else
	{
        /*- ????? */
	    crc= 0xFFFFu;
	}

	/*- ??????CRC16? */
	return (crc);
}


unsigned char CalculateCheckSum(unsigned char* pBuffer, int start, int end)
{
    unsigned char crc = 0x00;
    int i;
    for(i=start; i<end; i++)
    {
        crc += pBuffer[i];
    }
    return crc;
}

unsigned short CheckSum16CRC(unsigned char* pBuffer, int nLength)
{
	unsigned short retval = 0x0000;
	int i;
	for(i=0;i<nLength;i++)
	{
		retval += (unsigned short)(pBuffer[i]);
	}
	return retval;
}

unsigned char CheckSum8(unsigned char* pBuffer, int nLength)
{
	unsigned char retval = 0x00;
	int i;
	for(i=0;i<nLength;i++)
	{
		retval += pBuffer[i];
	}
	return retval;
}

unsigned char CalculateCheckMAHRSum(unsigned char* pBuffer, int start, int end)
{
    unsigned char crc = 0x00;
    int i;
    for(i=start; i<end; i++)
    {
        crc += pBuffer[i];
    }
	if(crc == 0xaa)
	  	crc = 0x0b;
	else if(crc == 0x55)
	  	crc = 0x56;
	else
	{}
    return crc;
}

void CalculateDeltaCounterUint16(FrameCounterUint16* counter)
{
	if (counter->first == 1)
	{
		counter->delta = ((long)counter->current - (long)counter->last);
		if (counter->delta <= -65485)
		{
			counter->delta += 65536;
		}

		counter->last = counter->current;
	}
	else
	{
		counter->first = 1;
		counter->last = counter->current;
		counter->delta = 0;
	}
}

void CalculateDeltaCounterUint8(FrameCounterUint8* counter)
{
	if (counter->first == 1)
	{
		counter->delta = ((short)counter->current - (short)counter->last);
		if (counter->delta <= -220)
		{
			counter->delta += 256;
		}

		counter->last = counter->current;
	}
	else
	{
		counter->first = 1;
		counter->last = counter->current;
		counter->delta = 0;
	}
}

void FrameBegin(DoubleBuffer* buf, FrameConstructor* frm)
{
	ClearFrameConstructor(frm);
}

void FrameEnd(DoubleBuffer* buf, FrameConstructor* frm)
{
	ClearFrameConstructor(frm);
}

void CheckSectionBegin(DoubleBuffer* buf, FrameConstructor* frm)
{
	frm->nCheckBegin = GetDoubleBufferLength(buf);
}

void CheckSectionEnd(DoubleBuffer* buf, FrameConstructor* frm)
{
	frm->check = CalculateCheckSum(GetDoubleBuffer(buf), frm->nCheckBegin ,GetDoubleBufferLength(buf));
	PushDoubleBuffer(frm->check, (buf));
}

void CheckSectionCrcEnd(DoubleBuffer* buf, FrameConstructor* frm)
{
	frm->check16 = cb_crc16_ccitt(GetDoubleBuffer(buf)+frm->nCheckBegin, GetDoubleBufferLength(buf)-frm->nCheckBegin);
	PUSH_VAR_DOUBLEBUFFER(frm->check16, (buf));
}

void CheckSectionMAHREnd(DoubleBuffer* buf, FrameConstructor* frm)
{
	frm->check = CalculateCheckMAHRSum(GetDoubleBuffer(buf), frm->nCheckBegin ,GetDoubleBufferLength(buf));
	PushDoubleBuffer(frm->check, (buf));
}

void LengthSectionBegin(DoubleBuffer* buf, FrameConstructor* frm)
{
	frm->nFrameLengthBegin = GetDoubleBufferLength(buf);
}

void LengthSectionEnd(DoubleBuffer* buf, FrameConstructor* frm)
{
	unsigned short Length;
	Length = GetDoubleBufferLength(buf)- frm->nFrameLengthBegin;
	memcpy(&(GetDoubleBuffer(buf)[frm->nFrameLengthPos]), &Length, frm->nFrameLengthSize);
}

void MarkLengthPosition(DoubleBuffer* buf, FrameConstructor* frm, int nLength)
{
	int i;
	frm->nFrameLengthPos = GetDoubleBufferLength(buf);
	frm->nFrameLengthSize = nLength;
	for (i=0; i<nLength; i++)
	{
		PushDoubleBuffer(0x00, buf);
	}
}

void ClearFrameConstructor(FrameConstructor* frm)
{
	frm->check = 0x00;
	frm->nFrameLengthBegin = 0x0000;
	frm->nFrameLengthPos = 0x0000;
	frm->nFrameLengthSize = 0x0000;
	frm->nCheckBegin = 0x0000;
	frm->nStep = 0x0000;
}

void InitOutputManage(uint32_t* table, OutputManagerTypeDef* manager)
{
	unsigned int i;
	unsigned int j;
	
	for (i = 0; i<manager->messageNumber; i++)
	{
		for (j = 0; j<manager->bufferNumber; j++)
		{
			manager->pPeriodTable[i*manager->bufferNumber + j] = table[i * manager->bufferNumber + j];
		}
	}

}

int CheckOutputManageTabel(OutputManagerTypeDef* manager, int MessageId, int BufferId, DoubleBuffer** buffer)
{
	int retval = 0;
	int position = 0;

	position = MessageId*manager->bufferNumber + BufferId;
	if (manager->pPeriodTable[position] != 0)
	{
		manager->pCounterTable[position]++;
		if (manager->pCounterTable[position] >= manager->pPeriodTable[position])
		{
			manager->pCounterTable[position] = 0;
			*buffer = manager->pChannelList[BufferId].pOutputBuffer;
			retval = 1;
		}
	}
	
	return retval;
}

/************************ (C) COPYRIGHT XiLang CO. Ltd. ****** END OF FILE ****/

#ifndef _NAV_GLOBALCTL_H_
#define _NAV_GLOBALCTL_H_

#include "nav_commonapply.h"
#include "nav_EquipAxis.h"
#include "nav_GeneralModule.h"
#include "nav_matrix.h"
#include "nav_CaliMag.h"
#include "nav_PressMeter.h"

#define EX_NAV_OK          0

#define NAV_RAD 57.29577951
//  ************  ������������  ********************************************
#define navGMg0      9.80128586//9.80665;  // (m/s*s)  ��ƽ���������ٶ�                     
#define magStreng	 54652.2 //(nT) �شų�ǿ��(����)
  
// **************������������***********************************************

#define _SIMULATION
#define _SIMUPRT
#define _SIMULATION00

 




#define EX7_4IMU//715



#define MAGHEADING



#define  MagP1 0.005
#define  MagP2 0.005
#define  MagP3 0.003
#define  MagR  0.01
#define  MagQ  1.0e-5
#define  T_MagCali 30.0
#define  MagLim    0.001
#define KF_TIME 1.0


#define STATIC_TIME 2//5
//#define STATIC_TIME 487
//#define STATIC_TIME 607


#define INS_TIMES 100
#define Mag_Filter_Num  4000
#define nTq 5//100Hz 


#define NT_GYRO 100
#define NT_ACC 10//50

#define K_KXZ 0.0
#define K_KYZ 0.0
#define K_KXY 0.0
#define K_KYX 0.0
#define K_KZX 0.0
#define K_KZY 0.0


#define H_SGM 0.5//1.2
#define H_KL1 1.0
#define H_KL2 20.0//2.0
//#define ACC_LIM_BL 1.5e-3
#define T_H 20.0
#define H_TAO 0.025
#define H_WZ  20.0//200.0

#define ACC_LIM_AB 3.0e-3//1.0e-3//2.0e-3//1.0e-3//2.0e-3//2.5e-3
#define T_LIM_AB   1//5//10//50
#define ACC_LIM_BL 2.0e-3//2.5e-3//3.0e-3//1.5e-3
#define T_LIM_BL   20//10//40//20//100
#define ACC_LIM_AB2 2.0e-5//2.0e-4//1.0e-3

//#define ACC_LIM_AB 3.0e-3//1.0e-3//2.0e-3//2.5e-3
//#define T_LIM_AB   5//10//50
//#define ACC_LIM_BL 2.5e-3//3.0e-3//1.5e-3
//#define T_LIM_BL   10//20//40//20//100
//#define ACC_LIM_AB2 1.0e-3

#define SGM_LIM  0.0035
#define K_KB00   1.0//0.01
#define K_KB0  3.0

#define K_KB  0.01//0.02//0.5
//#define K_KB1 4.0e-5////0.001


#define T_KB11  60.0
#define T_KB12  120.0
#define T_KB13	1200.0


//#define DF_KB11  0.003
//#define DF_KB12  0.03
//#define DF_KB13  0.01
//#define DF_KB14	 0.003

#define T_WZ  60.0
#define W_WZ  0.5

//#define T_KL  600.0
#define T_KL  6.0
#define K_KL1 360.0
#define K_KL2 180.0
//#define K_KL3 360.0
//#define K_KL4 180.0
#define K_KL3 1.0
#define K_KL4 54.0
#define K_KL5 1.0
#define K_KL6 54.0

#define T_KL2  6.0


//#define T_KL  60.0
//#define K_KL1 180.0
//#define K_KL2 180.0
//#define K_KL3 6.0
//#define K_KL4 18.0
#define DF_KB11  1.2e-4//ex6-17 500Hz
#define DF_KB12  1.2e-3
#define DF_KB13  4.0e-4
#define DF_KB14  1.2e-4


//#define K_KL5 1.0

#define ACC_CALIBRATION 2048.0
//#define GYRO_CALIBRATION 65.5
#define GYRO_CALIBRATION 131.0















//���ݱ������ӡ���ƫ����װƫ�����
typedef struct _GYROCALIBRATION GYROCALIBRATION;
struct _GYROCALIBRATION
{
    float Kg[3];
    float Kgn[3];
    float DF[3];
	float E[9];
	float En[9];
	float Temp_DF[3];    
	float T0;
	float Temperature;
	float DriftVsTmprature[3];
};
//�ӱ��������ӡ���ƫ����װƫ�����
typedef struct _ACCCALIBRATION ACCCALIBRATION;
struct _ACCCALIBRATION
{
    float Kap[3];
    float k0[3];
    float k[9];
	float ks[3];
};
typedef struct _SATCALIBRATION SATCALIBRATION;
struct _SATCALIBRATION
{
 	float ks[3];
};
//�����Ʊ������ӡ���ƫ����װƫ�����
typedef struct _MAGCALIBRATION MAGCALIBRATION;
struct _MAGCALIBRATION
{
    float Kap[3];
    float k0[3];
    float k[9];
	float lamda;
	float B;
	float h;
	float Date;
	float MagDec;
	float MagInc;
	float MagStr;
};

typedef struct _UTCT UTCT;
struct _UTCT
{
		unsigned char Year;
		unsigned char Month;
		unsigned char Day;
		unsigned char Hour;
		unsigned char Min;
		float Sec;
};

//GPS�����������
typedef struct _GPSINPUT GPSINPUT;
struct _GPSINPUT
{
		float UTC;
		float vel;
		float heading;
		double lamda;
		double B;
		float hdop;
		unsigned int sigRat;
		double h;
		double h_geo;
		double backup_h;
		float gps_vx;
		float gps_vy;
		float gps_vz;
		int SNRCnt;
		unsigned char status;
		unsigned char UpdatVel;
		unsigned char gga_status;	
		unsigned char Year;
		unsigned char Month;
		unsigned char Day;
		unsigned char Hour;
		unsigned char Min;
		float Sec;
	unsigned char ucGPGGA_UpdateFlag; // GPS Interface
	unsigned char ucGPRMC_UpdateFlag; // GPS Interface 
	unsigned char ucPSAT_UpdateFlag; // GPS Interface 
	unsigned char uc1PPS_UpdateFlag; // GPS Interface 
		float ins_t;
		float ins_t1;
		float ins_t2;
		float ins_t3;
		float ins_t4;
		float dB;
		float dlamda;
		float dh;
		float dB1;
		float dlamda1;
		float dh1;
		float dvx;
		float dvy;
		float dvz;
		float dvx1;
		float dvy1;
		float dvz1;
		unsigned char gga_counter;	
		float dX;
		float dY;
		float dR;
		float dV;
};

struct GPSFRAME
{
	
	unsigned short int   counter;
	union{
		unsigned char ucUTC[4];
		int           gpsUTC;
	}GPS_UTC;		
	unsigned char ucNS;
	unsigned char ucEW;
	double dLatitude;
	double dLongitude;
	double dHight;
	double dRate;
	double dCourse;
	double Double_Antenna_Heading;
	unsigned char ucStatus;
	unsigned int unSNR;
	unsigned int ucCRC;	
	int SUM_SAMPLE_BEGIN_FLAG;
	int SAMPLE_GPS_FLAG;
	float Mag_Offset_Angle;
	char Mag_Offset_EW;	
};

struct IMUFRAME
{
	unsigned short int   counter;
	int unGyroX;
	int unGyroY;
	int unGyroZ;
	int unAccX;
	int unAccY;
	int unAccZ;
	int unMagX;
	int unMagY;
	int unMagZ;
	unsigned int unPressure;
	unsigned int unTemperature;
	int   Right_v;
	int   Front_v;
	unsigned char ucCRC;
};

typedef struct _NAVIRESULT NAVIRESULT;
struct _NAVIRESULT
{
	double lamd;//8
	double B;//8
	float h;//4
	float ksaig;//4
	float thita;//4
	float gama;//4
	float vel[3];//12  	
	float fDelatV[3];
	float fAcc[3];
	float fOmiga[3];
	unsigned short uStatus;
};

union _OUTPUTFRAME
{
	NAVIRESULT naviresult;
	char frame[64];
};

typedef struct _NAVCTL NAVCTL;
struct _NAVCTL
{
	float   ClkErr;
	float   CalRang;
    float   ObsRang;
	float   ClkDot;
	float   GNSS_VEL[3];
	float   KF_GNSS_POS[3];
	int      PhaseCtlCounter;
	int      PhaseCtlCounter2;
	char     UPDATE_CLKERR_FLAG;
	float   BackupClkErr[2];
	float   FreShiftMean;
    unsigned short int  Navi_Status;//GI380
	unsigned short int  Navi_Status1;//PPOI
	unsigned short int  Navi_Status2;//PPOI
	char                Alert_Status;
    char                firstGps;
	char                startNav;
	char                BD_Begin;
	double              INS_T0;
	double              INS_T1;
	float              Vel_Ksaig;
	float              BodyAcc[3];	
    unsigned int        TimeCounter;
	int 				update_vdr;
	int 				update_vdr1;
	int                 LaidAlertCounter;
	char                StaticTestFlag;
	NAVMODULE           navGM;	
	struct GPSFRAME     g_Gps;
	struct IMUFRAME     g_Imu;
	union _OUTPUTFRAME  outputframe;
	GYROCALIBRATION     gyrocalibration;
	ACCCALIBRATION      acccalibration;
	MAGCALIBRATION      magcalibration;
	MAGCALIBRATION      magcalibration1;
	SATCALIBRATION		satcalibration;
	UTCT                 INS_utc;
	UTCT                 GPS_utc;
	UTCT                 last_GPS_utc;
	GPSINPUT            gpsinput;
	COMMONAPPLY         com_apply;
	EQUIPAXIS           EquipAxis;
	CALIBRATEMAG        cali_mag;
	PRESSMETER          pressmeter;
	unsigned char ucDoubleAntennaEnable;
	unsigned int CalibrationFlag;
	int (*Get_Pre_nav20ms)(NAVCTL *navctl, int Na[3], int Ng[3]);
};
NAVCTL* getnavblk(void); 
int nav_ctlGloCreate(NAVCTL *navctl);
void nav_ctlGloDelete(NAVCTL *navctl);

int nav_init0();//����ģ����������


#endif

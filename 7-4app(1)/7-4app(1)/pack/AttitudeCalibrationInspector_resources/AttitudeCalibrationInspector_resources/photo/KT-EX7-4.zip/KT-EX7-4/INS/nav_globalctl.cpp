/*
 * nav_globalcth.c
 *
 *  Created on: April 17, 2017
 *      Author: nav
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "nav_globalctl.h"
#include "nav_interface.h"


NAVCTL g_stNavCtl;


static int  Pre_nav20ms(NAVCTL *navctl, int Na[3], int Ng[3])
{		
	int i;
	float mag[3]={0.0};
	static long int nn=0;
	
	navctl->EquipAxis.Init_Axis_OK = 1; 
	navctl->EquipAxis.Ori = 3;

//		for(i=0;i<3;i++){
//			Nap1[i]=Na[i];
//			Ngp1[i]=Ng[i];
//		}
	 
	nn++;

//	for(i=0;i<3;i++) mag[i] = navctl->EquipAxis.oriaxis.Nmag[i]/2000.0;//epson 20190731 C616
//	for(i=0;i<3;i++) navctl->EquipAxis.Input_SixAxis.Magout[i] = mag[i];
	for(i=0;i<3;i++) mag[i] =(float)navctl->EquipAxis.oriaxis.Nmag[i];//715
	navctl->navGM.Get_accerrcmp(&navctl->navGM, navctl->navGM.navparameter.Sample_INS, navctl->EquipAxis.Input_SixAxis.Acc, Na);
	navctl->navGM.Get_gyerrcmp(&navctl->navGM, navctl->navGM.navparameter.Sample_INS, navctl->EquipAxis.Input_SixAxis.Gyro, Ng);
	
	navctl->navGM.Get_magerrcmp(&navctl->navGM, navctl->EquipAxis.Input_SixAxis.Magout, mag);//715

	navctl->EquipAxis.Get_Up_Trans(&navctl->EquipAxis, navctl->EquipAxis.Z_Ori);


	if(1)//(0)//
	{
#ifdef MAGHEADING

	  if( navctl->cali_mag.UpdatFlg == 1)
		navctl->navGM.Get_magerrcmp1(&navctl->navGM, navctl->EquipAxis.Input_SixAxis.Magout_Cmp, navctl->EquipAxis.Input_SixAxis.Magout);
#endif
	  if(navctl->EquipAxis.Axis_Phase>0)
	  {
		navctl->navGM.Cal_nonlinear_complf(navctl->navGM.navparameter.Sample_INS,navctl->EquipAxis.Input_SixAxis.Acc, navctl->EquipAxis.Input_SixAxis.Gyro, navctl->EquipAxis.Input_SixAxis.Magout_Cmp);
	  }
	}

//printf("\n nav1s T = %5.2f ",navctl->navGM.navparameter.INS_t);
	
	return 0;
}


int nav_ctlGloCreate(NAVCTL *ctl)
{
	int ret;
	
	memset(ctl, 0, sizeof(NAVCTL));

	ret = EquipAxisCreate(&ctl->EquipAxis);
	if(ret < 0)
	{
		goto err3;
	}	
	ret = nav_GeneralModuleCreate(&ctl->navGM);
	if(ret < 0)
	{
		goto err6;
	}	
	ret = nav_CaliMagCreate(&ctl->cali_mag);//
	if(ret < 0)
	{
		goto err7;
	}

	ctl->Get_Pre_nav20ms = Pre_nav20ms;
//	ctl->Get_nav20ms = nav20ms;
//	ctl->Get_nav1s = nav1s;
	return ret;

err7:
	nav_CaliMagDelete(&ctl->cali_mag);
err6:
	nav_GeneralModuleDelete(&ctl->navGM);
err3:
	EquipAxisDelete(&ctl->EquipAxis);

//err1:
	//navCommAppDelete(&ctl->com_apply);	
//err0:
//	AlignmentDelete(&ctl->alignment);
	return ret;
}

void nav_ctlGloDelete(NAVCTL *ctl)
{
	memset(ctl, 0, sizeof(NAVCTL));

//	navCommAppDelete(&ctl->com_apply);
//	AlignmentDelete(&ctl->alignment);
	EquipAxisDelete(&ctl->EquipAxis);
	nav_GeneralModuleDelete(&ctl->navGM);
	nav_CaliMagDelete(&ctl->cali_mag);
}



NAVCTL* getnavblk(void)
{
	return &g_stNavCtl;
}



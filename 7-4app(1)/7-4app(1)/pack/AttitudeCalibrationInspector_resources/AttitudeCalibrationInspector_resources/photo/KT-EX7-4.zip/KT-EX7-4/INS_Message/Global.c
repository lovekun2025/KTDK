/**
  ******************************************************************************
  * @file Global.c
  * @author  qiaoyy@xlnav.com
  * @version V1.0
  * @date 2018-06-01
  * @brief   ȫ�ֺꡢ���������ͺͺ���
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "Global.h"
/* Private typedef -----------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/
void ClearCircularBuffer(CircularBuffer* pBuf)
{
    int j;
	pBuf->m_ulPushTimes = 0;
	pBuf->m_ulPopTimes = 0;
	pBuf->m_nBufferHeadPosition = 0;
	pBuf->m_nBufferTailPosition = 0;
	pBuf->m_nBufferLength = 0;
	pBuf->m_ucLock = 0;
	pBuf->m_ucErrorCode = BUFFER_NO_ERROR;
	for (j=0; j<pBuf->m_nBufferSize; j++)
	{
		pBuf->m_ucDataBuffer[j] = 0x00;
	}
}

int PushCircularBuffer(uint8_t ucByte, CircularBuffer* pBuf)
{
	if (pBuf->m_ulPushTimes >= pBuf->m_ulPopTimes)
	{
		pBuf->m_nBufferLength = pBuf->m_ulPushTimes - pBuf->m_ulPopTimes;
	}
	else
	{
		pBuf->m_ucErrorCode = BUFFER_ERROR_POP_MORE_THAN_PUSH;
		return 0;
	}
    if (pBuf->m_nBufferLength<pBuf->m_nBufferSize)
    {
        pBuf->m_ucDataBuffer[pBuf->m_nBufferTailPosition] = ucByte;
        pBuf->m_nBufferTailPosition++;
		pBuf->m_ulPushTimes++;

        if (pBuf->m_nBufferTailPosition >= pBuf->m_nBufferSize)
        {
            pBuf->m_nBufferTailPosition = 0;
			
			// ����һ���Լ��
			if (pBuf->m_nBufferTailPosition > pBuf->m_nBufferHeadPosition)
			{
				if ((pBuf->m_ulPushTimes - pBuf->m_ulPopTimes) != (pBuf->m_nBufferTailPosition - pBuf->m_nBufferHeadPosition))
				{
					pBuf->m_ucErrorCode = BUFFER_ERROR_PARAM_NO_MATCH;
				}
			}
			else if (pBuf->m_nBufferTailPosition < pBuf->m_nBufferHeadPosition)
			{
				if ((pBuf->m_ulPushTimes - pBuf->m_ulPopTimes) != (pBuf->m_nBufferSize + pBuf->m_nBufferTailPosition - pBuf->m_nBufferHeadPosition))
				{
					pBuf->m_ucErrorCode = BUFFER_ERROR_PARAM_NO_MATCH;
				}
			}
			else
			{
				
			}
			if (pBuf->m_ucLock!=0x01)
			{
				// ������Ԥ������
				while ((pBuf->m_ulPushTimes> pBuf->m_nBufferSize) && (pBuf->m_ulPopTimes > pBuf->m_nBufferSize))
				{
					pBuf->m_ulPushTimes -= pBuf->m_nBufferSize;
					pBuf->m_ulPopTimes -= pBuf->m_nBufferSize;
				}
			}
        }
    }
	else
	{
		pBuf->m_ucErrorCode = BUFFER_ERROR_OVERLAB;
		return 0;
	}
	return 1;
}

int PopCircularBuffer(uint8_t *ucByte, CircularBuffer* pBuf)
{
	
	if (pBuf->m_ulPushTimes >= pBuf->m_ulPopTimes)
	{
		pBuf->m_nBufferLength = pBuf->m_ulPushTimes - pBuf->m_ulPopTimes;
	}
	else
	{
		pBuf->m_ucErrorCode = BUFFER_ERROR_POP_MORE_THAN_PUSH;
		return 0;
	}
    if (pBuf->m_nBufferLength > 0)
    {
        *ucByte = pBuf->m_ucDataBuffer[pBuf->m_nBufferHeadPosition];
        pBuf->m_nBufferHeadPosition++;
		pBuf->m_ucLock = 0x01;
		pBuf->m_ulPopTimes++;
		pBuf->m_ucLock = 0x00;

        if (pBuf->m_nBufferHeadPosition >= pBuf->m_nBufferSize)
        {
            pBuf->m_nBufferHeadPosition = 0;
        }
        return 1;       
    }
    return 0;
}

/**
 * @brief
 * @param
 * @return
*/
#define ULONG_MAX 0xffffffffUL
int err1[20];
int PopDmaCircularBuffer(uint8_t *value, DMA_CircularBuffer* buffer)
{
	volatile unsigned int writeCircle;
	volatile unsigned int head;
	// ��ֹд���ֽ��������������������
	writeCircle = buffer->writeCircle;
      err1[4]++;

	head = buffer->husart->NDTR;  //��ȡdma NDTR�Ĵ�����ֵ
        err1[5] =  DMA1->LISR;
	if (writeCircle == buffer->lastWriteCircle
		&& (head < 1 || head > buffer->maxSize - 1))
	{
		return 0;
                
	}
	if (head > 1 && head < buffer->maxSize - 1)
	{
		buffer->lastWriteCircle = writeCircle;
	}


	if ((ULONG_MAX / buffer->maxSize) < (writeCircle + 10))
	{
		if (buffer->readCounter < writeCircle * buffer->maxSize)
		{
			buffer->writeCircle -= buffer->readCounter / buffer->maxSize;
			buffer->readCounter = buffer->readCounter % buffer->maxSize;
		}
		else
		{
			buffer->writeCircle -= writeCircle;
			buffer->readCounter -= writeCircle * buffer->maxSize;
		}
	}
	// ����ͷ��λ�ú���д���ֽ���
	buffer->head = buffer->maxSize - head;
	buffer->writeCounter = writeCircle * buffer->maxSize + buffer->head;

	// ���㻺������δ�������ֽ���
	buffer->length = buffer->writeCounter - buffer->readCounter;

	if (buffer->writeCounter < buffer->readCounter)
	{
          err1[1]++;
		//		printf("Error %d %d %d %d %d %d %d %d %d\n", buffer->maxLength, buffer->head, buffer->tail, buffer->writeCounter, buffer->readCounter, head, buffer->lastWriteCircle, buffer->writeCircle, writeCircle);
	}

	// ����Ƿ�������ض�λ��βλ��
	if (buffer->length > buffer->maxSize)
	{
          err1[2]++;
		buffer->overLapFlag = 1;
		buffer->length = buffer->maxSize;
		buffer->readCounter = buffer->writeCounter - buffer->length;
		if (buffer->head == buffer->maxSize - 1)
		{
			buffer->tail = 0;
		}
		else
		{
			buffer->tail = buffer->head + 1;
		}
		//		printf("Overlap %d %d %d %d %d %d\n", buffer->maxLength, buffer->head, buffer->tail, buffer->writeCounter, buffer->readCounter, head);

	}

	// ִ�����Ͷ���
	if (buffer->length > 0)
	{
		if (buffer->length >= buffer->maxLength)
		{

			buffer->maxLength = buffer->length;
			//			printf("Max: %d %d %d %d %d %d\n", buffer->maxLength, buffer->head, buffer->tail, buffer->writeCounter, buffer->readCounter, head);
		}
		*value = buffer->buffer[buffer->tail];
		buffer->readCounter++;
		buffer->tail++;
		buffer->length--;
		if (buffer->tail >= buffer->maxSize)
		{
			buffer->tail = 0;
			buffer->readCircle++;
		}
		return 1;
	}
	else
	{
          err1[3]++;
		*value = 0x00;
		return 0;
	}
}
int PushDoubleBuffer(uint8_t ucByte, DoubleBuffer* pBuf)
{
	if (pBuf->m_nBufferLength[pBuf->m_nBufferNumber] < pBuf->m_nBufferSize)
	{
		pBuf->m_ucDataBuffer[pBuf->m_nBufferNumber][pBuf->m_nBufferLength[pBuf->m_nBufferNumber]] = ucByte;
		pBuf->m_nBufferLength[pBuf->m_nBufferNumber]++;
		return 1;
	}
	else
	{
		pBuf->m_ucErrorCode = BUFFER_ERROR_OVERLAB;
	}
	return 0;
}

void PushWordDoubleBuffer(uint16_t word, DoubleBuffer* pBuf)
{
	PushDoubleBuffer((uint8_t)(word&0xff), pBuf);
	PushDoubleBuffer((uint8_t)(word>>8), pBuf);
}

void PushBytesDoubleBuffer(uint8_t *pBytes, uint16_t nLength, DoubleBuffer* pBuf)
{
	int i;
	for (i=0; i<nLength; i++)
	{
		PushDoubleBuffer(pBytes[i], pBuf);
	}
}

uint16_t GetDoubleBufferLength(DoubleBuffer* pBuf)
{
	return pBuf->m_nBufferLength[pBuf->m_nBufferNumber];
}

uint8_t* GetDoubleBuffer(DoubleBuffer* pBuf)
{
	return pBuf->m_ucDataBuffer[pBuf->m_nBufferNumber];
}

void ClearDoubleBuffer(DoubleBuffer* pBuf)
{
	pBuf->m_nBufferLength[0] = 0;
	pBuf->m_nBufferLength[1] = 0;
	pBuf->m_nBufferNumber = 0;
	pBuf->m_ucErrorCode = BUFFER_NO_ERROR;
}

char* strcat_safe(char * tag, const char* src, unsigned int max_length)
{
	unsigned int tag_length = strlen(tag);
	unsigned int src_length = strlen(src);
	if ((tag_length + src_length + 1) <= max_length)
	{
		strcat(tag, src);
	}
	else
	{
		return NULL;
	}
	return tag;
}
void DmaCircularBufferIrqHandle(DMA_CircularBuffer* buffer)
{
	buffer->protact = 1;
	buffer->writeCircle++;
	buffer->protact = 0;
}
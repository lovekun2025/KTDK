#include "Config.h"
#include "ktUart.h"
extern void g_USART1_Buffer;
extern void g_USART2_Buffer;
extern void g_USART3_Buffer;
/*
/////////////////////ktUartMap///////////////////////////////
          GD32E103xB/GD32F103xB      STM32F405RG(GD32F405RG)   STM32F103xB   ............        
ktUart0   USART0/PA9/PA10/DMA          USART1/PA9/PA10/DMA    
ktUart1                                            
ktUart2
ktUart3
ktUart4
ktUart5
ktUart6
......
*/

//ȫ�ֱ���  

/////////////////////////////////////////////////////////////////////////////////////////////

//ktUart1         
/////////////////////////////////////////////////////////////////////////////////////////////


//ȫ�ֱ���
uartConfig_s ktUart0Config[3] = 
{
  {BD_UART_BAUD_RATE,BD_UART_WORD_LENGTH,BD_UART_STOP_BITS,BD_UART_PARITY_BITS},  
  {YZ_UART_BAUD_RATE,YZ_UART_WORD_LENGTH,YZ_UART_STOP_BITS,YZ_UART_PARITY_BITS},  
  {JF_UART_BAUD_RATE,JF_UART_WORD_LENGTH,JF_UART_STOP_BITS,JF_UART_PARITY_BITS},  
};

//uartConfig_s ktUart1Config = {921600,KT_UART_WL_8BIT,KT_UART_STB_1BIT,KT_UART_PM_NONE};  

void copyDataFromRxBuff(uint8_t  *dest,uint8_t *src,uint16_t pos,uint16_t length,uint16_t buffLenth)
{
  uint16_t  i = 0;
  
  for(i = 0; i < length; i++)
  {
    *(dest+i) = *(src+((pos + i) % buffLenth));
  }
}


#if defined(GD32E103V_MD) || defined(GD32F10X_MD)


void ktUart0RxIntEnable()
{
  usart_interrupt_enable(USART0, USART_INT_RBNE);    
}

void ktUart0IdleIntEnable()
{
  usart_interrupt_enable(USART0, USART_INT_IDLE);    
}

void ktUart0RxIntDisable()
{
  usart_interrupt_disable(USART0, USART_INT_RBNE);    
}

void ktUart0IdleIntDisable()
{
  usart_interrupt_disable(USART0, USART_INT_IDLE);     
}

void ktUart0ClearInt()
{
  usart_data_receive(USART0);  //��idle
  usart_interrupt_flag_clear(USART0,USART_INT_FLAG_RBNE);
}



void ktUart0GpioInit()
{
  rcu_periph_clock_enable(RCU_GPIOA);

  rcu_periph_clock_enable(RCU_AF);
  
  gpio_init (GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);
  gpio_init (GPIOA, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_10);

}


void ktUart0Init()
{
   
  rcu_periph_clock_enable(RCU_USART0);
     
  usart_deinit(USART0); 
 
  usart_baudrate_set(USART0,ktUart0Config[frameID].bitRate);  
  usart_word_length_set(USART0,ktUart0Config[frameID].wordLength);//8λ����λ
  usart_stop_bit_set(USART0,ktUart0Config[frameID].stopBits);//һλֹͣλ
  usart_parity_config(USART0,ktUart0Config[frameID].parity); //��У��λ
  usart_receive_config(USART0,USART_RECEIVE_ENABLE);//ʹ��USART0����
  usart_transmit_config(USART0,USART_TRANSMIT_ENABLE);//ʹ��USART0����
  
  usart_enable(USART0);

}

void ktUart0TxDMAConfig()
{
    dma_parameter_struct dma_init_struct;
    
     /* enable DMA clock */
    rcu_periph_clock_enable(RCU_DMA0);
    
    /* initialize DMA channel 3 */
    dma_deinit(DMA0, DMA_CH3);
    dma_struct_para_init(&dma_init_struct);
    
    dma_init_struct.direction = DMA_MEMORY_TO_PERIPHERAL;
    dma_init_struct.memory_addr = (uint32_t)ktUart0TxBuff;
    dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE;
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_8BIT;
    dma_init_struct.number = 80;
    dma_init_struct.periph_addr =(uint32_t ) &USART_DATA(USART0);
    dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE;
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dma_init_struct.priority = DMA_PRIORITY_ULTRA_HIGH;
    dma_init(DMA0, DMA_CH3, &dma_init_struct);
    
    /* configure DMA mode */
    dma_circulation_disable(DMA0, DMA_CH3);
    dma_memory_to_memory_disable(DMA0, DMA_CH3);
    
    /* USART DMA enable for transmission */
    usart_dma_transmit_config(USART0, USART_DENT_ENABLE);

    return;
}


void ktUart0DMAWaitIdleWithTimeout(uint32_t timeOut)
{
  uint32_t ticksStart = 0;
  uint32_t timeOutTemp = timeOut;
  
  ticksStart = getTicks(); 
  
  while(RESET == dma_flag_get(DMA0, DMA_CH3, DMA_INTF_FTFIF))
  {
    if((getTicks() - ticksStart) > timeOutTemp)
      break;
  }
  
}

void ktUart0DMASend(uint16_t sendLength)
{
  
  if(sendLength == 0)
    return;
  
  dma_flag_clear(DMA0, DMA_CH3, DMA_INTF_FTFIF);   
  dma_channel_disable(DMA0, DMA_CH3);   
  dma_transfer_number_config(DMA0, DMA_CH3, sendLength);
  dma_channel_enable(DMA0, DMA_CH3);
  
}

/**ʹ�û��ζ��еķ�ʽ����������*/
void KT_UART0_IRQHandler(void)
{
  static uint16_t rxStart = 0;
  static uint16_t rxEnd   = 0;  
  uint16_t dataLengthLast = 0;
  
  if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_RBNE) != RESET)
  {
    ktUart0RxBuff[rxEnd++] = usart_data_receive(USART0);
    if(rxEnd == KT_UART0_RX_BUFF_LEN)
      rxEnd = 0;
  }  
  
  if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_IDLE) != RESET)
  {
    /* clear IDLE flag */
    usart_data_receive(USART0);
   
    dataLengthLast = ktUart0RxLength;
    
    if(rxEnd >= rxStart)
      ktUart0RxLength = rxEnd - rxStart;
    else
      ktUart0RxLength = rxEnd + KT_UART0_RX_BUFF_LEN - rxStart;
    
    
    if(ktUart0RxReady == 1)
    {
      ktUart0RxLength = ktUart0RxLength + dataLengthLast;      
    }
    else
    {
      ktUart0RxPos = rxStart;
      ktUart0RxReady = 1;
    }
    
    rxStart = rxEnd;      
  }
}

#endif

#ifdef STM32F40XX

void ktUart0RxIntEnable()
{
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 

  
}

void ktUart0IdleIntEnable()
{
  USART_ITConfig(USART1, USART_IT_IDLE, ENABLE); 
}

void ktUart0RxIntDisable()
{
  USART_ITConfig(USART1, USART_IT_RXNE, DISABLE); 
}

void ktUart0IdleIntDisable()
{
  USART_ITConfig(USART1, USART_IT_IDLE, DISABLE); 
}



void ktUart0GpioInit()
{

  GPIO_InitTypeDef GPIO_InitStructure; 

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
  
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource9, GPIO_AF_USART1);
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource10,GPIO_AF_USART1);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  USART_OverSampling8Cmd(USART1, ENABLE);
 
}


void ktUart0Init(char state)
{
  	ConfigTabelTypeDef* config;
	config = GetConfigTable();
  
  USART_InitTypeDef USART_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);  
    
  USART_OverSampling8Cmd(USART1, ENABLE);
  if(state==0)
  {
    USART_InitStructure.USART_BaudRate = ktUart0Config[frameID].bitRate;
    USART_InitStructure.USART_WordLength = ktUart0Config[frameID].wordLength;
    USART_InitStructure.USART_StopBits = ktUart0Config[frameID].stopBits;
    USART_InitStructure.USART_Parity = ktUart0Config[frameID].parity;  
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;  
    USART_Init(USART1, &USART_InitStructure);
    USART_Cmd(USART1, ENABLE);
  }
  else if(state==1)
  {
    USART_InitStructure.USART_BaudRate = config->ulUart1Baudrate;
    USART_InitStructure.USART_WordLength = 8;
    USART_InitStructure.USART_StopBits = 1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;  
    USART_Init(USART1, &USART_InitStructure);
    USART_Cmd(USART1, ENABLE);
  }
  
  
}
extern uint8_t tx_buff[200];
void ktUart0TxDMAConfig(char state)
{
  DMA_InitTypeDef DMA_InitStructure;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2,ENABLE);
  
  DMA_DeInit(DMA2_Stream7);  
  
  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_PeripheralBaseAddr = 0x40011004; 
  if(state == 0)
  {
    DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)ktUart0TxBuff;
    DMA_InitStructure.DMA_BufferSize = 80;//TxBufferSize;
  }
  if(state == 1)
  {
     DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)tx_buff;
     DMA_InitStructure.DMA_BufferSize = 200;//TxBufferSize;
  }
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
  
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(DMA2_Stream7, &DMA_InitStructure);
  USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE);
}

void ktUart0DMAWaitIdleWithTimeout(uint32_t timeOut)
{
  uint32_t ticksStart = 0; 
  uint32_t timeOutTemp = timeOut;
  
  ticksStart = getTicks(); 
  
  while(RESET == DMA_GetFlagStatus(DMA2_Stream7,DMA_FLAG_TCIF7))
  {
    if((getTicks() - ticksStart) > timeOutTemp)
      break;
  }
}

void ktUart0DMASend(uint16_t sendLength)
{
  
  if(sendLength == 0)
    return;
  
  DMA_ClearFlag(DMA2_Stream7,DMA_FLAG_TCIF7);      //��DMA������ɱ�     
  
  DMA_Cmd(DMA2_Stream7, DISABLE);   //ֹͣDMA
  
  while (DMA_GetCmdStatus(DMA2_Stream7) != DISABLE);
  
  DMA_SetCurrDataCounter(DMA2_Stream7,sendLength);//���贫�䳤��
  
  DMA_Cmd(DMA2_Stream7, ENABLE);        //��ʼDMA����   
  
}
void KT_UART0_IRQ_IMU(void)  //imu�궨����
{
  static uint16_t rxStart = 0;
  static uint16_t rxEnd   = 0;  
  uint16_t dataLengthLast = 0;
  
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
    ktUart0RxBuff[rxEnd++] = USART_ReceiveData(USART1);
    if(rxEnd == KT_UART0_RX_BUFF_LEN)
      rxEnd = 0;
  }  
  
  if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET)
  {
    /* clear IDLE flag */
    USART_ReceiveData(USART1);
    
    dataLengthLast = ktUart0RxLength;
    
    if(rxEnd >= rxStart)
      ktUart0RxLength = rxEnd - rxStart;
    else
      ktUart0RxLength = rxEnd + KT_UART0_RX_BUFF_LEN - rxStart;
    
    
    if(ktUart0RxReady == 1)
    {
      ktUart0RxLength = ktUart0RxLength + dataLengthLast;      
    }
    else
    {
      ktUart0RxPos = rxStart;
      ktUart0RxReady = 1;
    }
    
    rxStart = rxEnd;      
  }
}
/*
  usart1 422�ڴ��ڽ����ж�
  ins��������ʹ��
  imu�궨��ʹ��
*/
void USART1_IRQHandler(void)
{ 
  uint8_t DataByte;
  
  if(frameID < 2)
  {
    KT_UART0_IRQ_IMU(); //�궨ʱ�����б궨���ݴ�������
  }
  else if(frameID == 2) //������Ӧ�ͻ����ݴ���
  {
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        DataByte = USART_ReceiveData(USART1);
        PushCircularBuffer(DataByte, &g_USART1_Buffer);
    }
  }
}

//USART_422_1 DMA����
void USART_422_DMA_Send(uint16_t send_length)
{
  
  while(1)
  {
   if(DMA_GetFlagStatus(DMA2_Stream7,DMA_FLAG_TCIF7)!=RESET);
   {   
     DMA_ClearFlag(DMA2_Stream7,DMA_FLAG_TCIF7);      //��DMA������ɱ�      
     break;   
   }
  }
   
   DMA_Cmd(DMA2_Stream7, DISABLE);   //ֹͣDMA
   while (DMA_GetCmdStatus(DMA2_Stream7) != DISABLE);
   DMA_SetCurrDataCounter(DMA2_Stream7,send_length);//���贫�䳤��
   DMA_Cmd(DMA2_Stream7, ENABLE);//��ʼDMA����
}






void UART_485_GPIO_Init() 
{

	GPIO_InitTypeDef GPIO_InitStructure; 
	/* Enable GPIO clock */
	RCC_AHB1PeriphClockCmd(USART_485_GPIO_CLK, ENABLE);// 
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = USART_RE;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(USART_RE_GPIO, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = USART_DE;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(USART_DE_GPIO, &GPIO_InitStructure); 
}





///*485������������ú���*/
void UART_485_Init() 
{
	//ConfigTabelTypeDef* config;
	//config = GetConfigTable();

	USART_InitTypeDef USART_InitStructure;
        GPIO_InitTypeDef GPIO_InitStructure; 

	/* Enable USART_422 Clock */  
	RCC_APB1PeriphClockCmd(USART_485_CLK, ENABLE);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);

	GPIO_InitStructure.GPIO_Pin = USART_485_TxPin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(USART_485_GPIO, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = USART_485_RxPin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(USART_485_GPIO, &GPIO_InitStructure);

	USART_OverSampling8Cmd(USART_485, ENABLE);  
	
	USART_InitStructure.USART_BaudRate = 460800;//config->ulUart1Baudrate;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;  
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;  
	USART_Init(USART_485, &USART_InitStructure);

//	USART_Cmd(USART_485, ENABLE);
//	USART_ITConfig(USART_485, USART_IT_RXNE, ENABLE); 
}

void USART_485_DMA_Config()
{
	DMA_InitTypeDef DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);

	DMA_DeInit(DMA1_Stream6);  

	DMA_InitStructure.DMA_Channel = DMA_Channel_4;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(USART_485->DR); //USART_485_DR_Base;//
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)tx_buff;
	DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	DMA_InitStructure.DMA_BufferSize = 200;//TxBufferSize;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
	DMA_Init(DMA1_Stream6, &DMA_InitStructure);
	USART_DMACmd(USART_485, USART_DMAReq_Tx, ENABLE);

//	DMA_Cmd(DMA1_Stream6, ENABLE);//�������ݵ�ʱ��ʹ��
}

//USART_485 DMA�������� 
void USART_485_DMA_Send(uint16_t send_length)
{
	USART_485_Mode_Tx();
	while(1)
	{
		if(DMA_GetFlagStatus(DMA1_Stream6,DMA_FLAG_TCIF6)!=RESET);//SET������ɣ� RESET����δ���
		{
			DMA_ClearFlag(DMA1_Stream6,DMA_FLAG_TCIF6);      //��DMA������ɱ�      
			break;
		}
	}
	DMA_Cmd(DMA1_Stream6, DISABLE);   //ֹͣDMA
	while (DMA_GetCmdStatus(DMA1_Stream6) != DISABLE);
	DMA_SetCurrDataCounter(DMA1_Stream6,send_length);//���贫�䳤��
	DMA_Cmd(DMA1_Stream6, ENABLE);//��ʼDMA����
}


//485���ڽ�������
void USART2_IRQHandler(void)
{  
	uint8_t DataByte;
	if(USART_GetITStatus(USART_485, USART_IT_RXNE) != RESET)
	{
		/* Read one byte from the receive data register */
		DataByte = USART_ReceiveData(USART_485);
		PushCircularBuffer(DataByte, &g_USART2_Buffer);
	}/*���������ж�*/
}

void UART3_Init() 
{
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure; 
  /* Enable GPIO clock */
  RCC_AHB1PeriphClockCmd(USART3_422_GPIO_CLK,ENABLE);
  /* Enable USART Clock */
  RCC_APB1PeriphClockCmd(USART3_422_CLK, ENABLE);  
  
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource11,GPIO_AF_USART3);
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource10,GPIO_AF_USART3);
  
  GPIO_InitStructure.GPIO_Pin = USART3_422_TxPin;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(USART3_422_GPIO, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = USART3_422_RxPin;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(USART3_422_GPIO, &GPIO_InitStructure);
  
  USART_OverSampling8Cmd(USART3_422, ENABLE);
    
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;  
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;  
  USART_Init(USART3_422, &USART_InitStructure);

}
/*
USART3 �����ͨ�Ŵ���
115200
*/
void USART3_ShenHaiLan_DMA_Config(DMA_CircularBuffer* buffer)   
{
  DMA_InitTypeDef DMA_InitStructure;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);
  
  DMA_DeInit(DMA1_Stream1);//�ο��ֲᣬ205ҳ  

  DMA_InitStructure.DMA_Channel = DMA_Channel_4;
  DMA_InitStructure.DMA_PeripheralBaseAddr = USART3_422_DR_Base; 
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)buffer->buffer;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//����->�ڴ�
  DMA_InitStructure.DMA_BufferSize = buffer->maxSize;//DMA��������
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;  //8λ
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte; //8λ
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//����ģʽ
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(DMA1_Stream1, &DMA_InitStructure);
  DMA_ITConfig(DMA1_Stream1,DMA_IT_TC,ENABLE);//���ݴ������ж�
  DMA_ClearFlag(DMA1_Stream1,DMA_IT_TCIF1);//�����������־
  
//  USART_DMACmd(USART3_422, USART_DMAReq_Rx, ENABLE);
// DMA_Cmd(DMA1_Stream1, ENABLE);
 //DMA_GetCurrDataCounter(DMA1_Stream1);
                        
}

/*
  USART3 �����ͨ�Ŵ���
  115200
  dma�����ж�
*/
void DMA1_Stream1_IRQHandler(void)
{
   if(DMA_GetITStatus(DMA1_Stream1,DMA_IT_TCIF1))
   {
      DmaCircularBufferIrqHandle(&g_USART3_Buffer);
      //DMA_ClearFlag(DMA1_Stream1,DMA_IT_TCIF1);//�����������־
      DMA_ClearITPendingBit(DMA1_Stream1,DMA_IT_TCIF1);
   }
   if(DMA_GetITStatus(DMA1_Stream1,DMA_IT_HTIF1))
   {
   DMA_ClearITPendingBit(DMA1_Stream1,DMA_IT_HTIF1);
   }
}



#endif

#include "nav_globalctl.h"
#include "nav_EquipAxis.h"
#include "nav_matrix.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>



static void Up_Trans0(EQUIPAXIS *EquipAxis, int flag)
{	
	if(EquipAxis->Z_Ori>0)
	{
		if(flag == 1)
		{
			EquipAxis->Output_SixAxis.Acc[0] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Gyro[0] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Magout[0] = EquipAxis->Input_SixAxis.Magout[1];
			EquipAxis->Output_SixAxis.Magout[1] = EquipAxis->Input_SixAxis.Magout[2];
			EquipAxis->Output_SixAxis.Magout[2] = EquipAxis->Input_SixAxis.Magout[0];
			
			}
		else if(flag == 2)
		{
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Acc[2] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Gyro[2] = -EquipAxis->Input_SixAxis.Gyro[0];
            
            EquipAxis->Output_SixAxis.Magout[0] = -EquipAxis->Input_SixAxis.Magout[1];
			EquipAxis->Output_SixAxis.Magout[1] = EquipAxis->Input_SixAxis.Magout[2];
			EquipAxis->Output_SixAxis.Magout[2] = -EquipAxis->Input_SixAxis.Magout[0];
		}
		else if(flag == 3)
		{
			EquipAxis->Output_SixAxis.Acc[0] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Gyro[0] = EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Magout[0] = EquipAxis->Input_SixAxis.Magout[2];
			EquipAxis->Output_SixAxis.Magout[1] = EquipAxis->Input_SixAxis.Magout[0];
			EquipAxis->Output_SixAxis.Magout[2] = EquipAxis->Input_SixAxis.Magout[1];
		}
		else if(flag == 4)
		{
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[2] = -EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[2] = -EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Magout[0] = -EquipAxis->Input_SixAxis.Magout[2];
			EquipAxis->Output_SixAxis.Magout[1] = EquipAxis->Input_SixAxis.Magout[0];
			EquipAxis->Output_SixAxis.Magout[2] = -EquipAxis->Input_SixAxis.Magout[1];
		}
		else if(flag == 5)
		{
			EquipAxis->Output_SixAxis.Acc[0] = EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Magout[0] = EquipAxis->Input_SixAxis.Magout[0];
			EquipAxis->Output_SixAxis.Magout[1] = EquipAxis->Input_SixAxis.Magout[1];
			EquipAxis->Output_SixAxis.Magout[2] = EquipAxis->Input_SixAxis.Magout[2];


		}
		else if(flag == 6)
		{
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[2] = -EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[2] = -EquipAxis->Input_SixAxis.Gyro[2];
		}
		else if(flag == 7)
		{
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[0];
		}
		else if(flag == 8)
		{
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[1] = -EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[1] = -EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[2];
		}
		else if(flag == 9)
		{
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[1] = -EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[1] = -EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[2];
		}
		else if(flag == 11)
	  {
			EquipAxis->Output_SixAxis.Acc[0] = -EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[1] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[2] = -EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = -EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[1] = -EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[2] = -EquipAxis->Input_SixAxis.Gyro[2];
     }
		else if(flag == 12)
	  {
			EquipAxis->Output_SixAxis.Acc[0] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[1] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[2] = EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[1] = -EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[2] = EquipAxis->Input_SixAxis.Gyro[2];
     }
		else if(flag == 13)
	  {
			EquipAxis->Output_SixAxis.Acc[0] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[1] = EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Acc[2] = -EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Gyro[0] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[1] = EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Gyro[2] = -EquipAxis->Input_SixAxis.Gyro[2];

			EquipAxis->Output_SixAxis.Magout[0] = EquipAxis->Input_SixAxis.Magout[1];
			EquipAxis->Output_SixAxis.Magout[1] = EquipAxis->Input_SixAxis.Magout[0];
			EquipAxis->Output_SixAxis.Magout[2] = -EquipAxis->Input_SixAxis.Magout[2];
		}
			else if(flag == 14)
	  {
			EquipAxis->Output_SixAxis.Acc[0] = EquipAxis->Input_SixAxis.Acc[1];
			EquipAxis->Output_SixAxis.Acc[1] = -EquipAxis->Input_SixAxis.Acc[2];
			EquipAxis->Output_SixAxis.Acc[2] = -EquipAxis->Input_SixAxis.Acc[0];
			EquipAxis->Output_SixAxis.Gyro[0] = EquipAxis->Input_SixAxis.Gyro[1];
			EquipAxis->Output_SixAxis.Gyro[1] = -EquipAxis->Input_SixAxis.Gyro[2];
			EquipAxis->Output_SixAxis.Gyro[2] = -EquipAxis->Input_SixAxis.Gyro[0];
			EquipAxis->Output_SixAxis.Magout[0] = EquipAxis->Input_SixAxis.Magout[1];
			EquipAxis->Output_SixAxis.Magout[1] = -EquipAxis->Input_SixAxis.Magout[2];
			EquipAxis->Output_SixAxis.Magout[2] = -EquipAxis->Input_SixAxis.Magout[0];
		}
		else
		{
			EquipAxis->Axis_Phase = -4;
			memset(EquipAxis, 0, sizeof(EQUIPAXIS));		
		}
	}
	if(EquipAxis->Init_Axis_OK == 1)
	{
		if(EquipAxis->Ori == 1)
		{
			EquipAxis->Input_SixAxis.Acc[0] = -EquipAxis->Output_SixAxis.Acc[1];
			EquipAxis->Input_SixAxis.Acc[1] = EquipAxis->Output_SixAxis.Acc[0];
			EquipAxis->Input_SixAxis.Acc[2] = EquipAxis->Output_SixAxis.Acc[2];
			EquipAxis->Input_SixAxis.Gyro[0] = -EquipAxis->Output_SixAxis.Gyro[1];
			EquipAxis->Input_SixAxis.Gyro[1] = EquipAxis->Output_SixAxis.Gyro[0];
			EquipAxis->Input_SixAxis.Gyro[2] = EquipAxis->Output_SixAxis.Gyro[2];
            
            EquipAxis->Input_SixAxis.Magout[0] = -EquipAxis->Output_SixAxis.Magout[1];
			EquipAxis->Input_SixAxis.Magout[1] = EquipAxis->Output_SixAxis.Magout[0];
			EquipAxis->Input_SixAxis.Magout[2] = EquipAxis->Output_SixAxis.Magout[2];
		}
		else if(EquipAxis->Ori == 2)
		{
			EquipAxis->Input_SixAxis.Acc[0] = EquipAxis->Output_SixAxis.Acc[1];
			EquipAxis->Input_SixAxis.Acc[1] = -EquipAxis->Output_SixAxis.Acc[0];
			EquipAxis->Input_SixAxis.Acc[2] = EquipAxis->Output_SixAxis.Acc[2];
			EquipAxis->Input_SixAxis.Gyro[0] = EquipAxis->Output_SixAxis.Gyro[1];
			EquipAxis->Input_SixAxis.Gyro[1] = -EquipAxis->Output_SixAxis.Gyro[0];
			EquipAxis->Input_SixAxis.Gyro[2] = EquipAxis->Output_SixAxis.Gyro[2];
			EquipAxis->Input_SixAxis.Magout[0] = EquipAxis->Output_SixAxis.Magout[1];
			EquipAxis->Input_SixAxis.Magout[1] = -EquipAxis->Output_SixAxis.Magout[0];
			EquipAxis->Input_SixAxis.Magout[2] = EquipAxis->Output_SixAxis.Magout[2];
		}
		else if(EquipAxis->Ori == 3)
		{
			EquipAxis->Input_SixAxis.Acc[0] = EquipAxis->Output_SixAxis.Acc[0];
			EquipAxis->Input_SixAxis.Acc[1] = EquipAxis->Output_SixAxis.Acc[1];
			EquipAxis->Input_SixAxis.Acc[2] = EquipAxis->Output_SixAxis.Acc[2];
			EquipAxis->Input_SixAxis.Gyro[0] = EquipAxis->Output_SixAxis.Gyro[0];
			EquipAxis->Input_SixAxis.Gyro[1] = EquipAxis->Output_SixAxis.Gyro[1];
			EquipAxis->Input_SixAxis.Gyro[2] = EquipAxis->Output_SixAxis.Gyro[2];
			EquipAxis->Input_SixAxis.Magout[0] = EquipAxis->Output_SixAxis.Magout[0];
			EquipAxis->Input_SixAxis.Magout[1] = EquipAxis->Output_SixAxis.Magout[1];
			EquipAxis->Input_SixAxis.Magout[2] = EquipAxis->Output_SixAxis.Magout[2];
		}
		else if(EquipAxis->Ori == 4)
		{
			EquipAxis->Input_SixAxis.Acc[0] = -EquipAxis->Output_SixAxis.Acc[0];
			EquipAxis->Input_SixAxis.Acc[1] = -EquipAxis->Output_SixAxis.Acc[1];
			EquipAxis->Input_SixAxis.Acc[2] = EquipAxis->Output_SixAxis.Acc[2];
			EquipAxis->Input_SixAxis.Gyro[0] = -EquipAxis->Output_SixAxis.Gyro[0];
			EquipAxis->Input_SixAxis.Gyro[1] = -EquipAxis->Output_SixAxis.Gyro[1];
			EquipAxis->Input_SixAxis.Gyro[2] = EquipAxis->Output_SixAxis.Gyro[2];
			EquipAxis->Input_SixAxis.Magout[0] = -EquipAxis->Output_SixAxis.Magout[0];
			EquipAxis->Input_SixAxis.Magout[1] = -EquipAxis->Output_SixAxis.Magout[1];
			EquipAxis->Input_SixAxis.Magout[2] = EquipAxis->Output_SixAxis.Magout[2];
		}
		else
		{			
			EquipAxis->Axis_Phase = -4;
		}
	}
}

static int Equip_Axis(EQUIPAXIS *EquipAxis, char Flag_1s, float dr_v, double Sample_INS, char Gear_Flag)
{
	NAVCTL *navctl;
	navctl = getnavblk();

	if(Flag_1s == 1)
	{

		EquipAxis->Phase_Counter++;

		switch(EquipAxis->Axis_Phase){
		case -5:
	//	EquipAxis->Axis_Phase = -1;

		  if(EquipAxis->Phase_Counter >= STATIC_TIME){
			EquipAxis->Phase_Counter = 0;
			EquipAxis->Axis_Phase = 0;
		  }

 		 break;			
			case 0:
			  if(EquipAxis->Phase_Counter >= 1)
			  {
						EquipAxis->Phase_Counter = 0;
						EquipAxis->Axis_Phase = 1;
						
						navctl->Navi_Status = 1;
						navctl->Navi_Status1 = 4;
						navctl->Navi_Status2 = 0;
				
						
				//		navctl->navGM.navparameter.INS_t = 0.0;
				//		navctl->INS_T0 = navctl->navGM.navparameter.INS_t + KF_TIME;
                  
						
						navctl->TimeCounter = 0;
						EquipAxis->nav_g0 = 9.801265;
						navctl->Alert_Status = 0;
						navctl->gyrocalibration.T0 = navctl->gyrocalibration.Temperature;
					
                            }

			break;

		default:
			break;
		}
	}
	return 0;
}



int EquipAxisCreate(EQUIPAXIS *EquipAxis)
{
	memset(EquipAxis, 0, sizeof(EQUIPAXIS));
	EquipAxis->Get_Up_Trans = Up_Trans0;
	EquipAxis->Get_Equip_Axis = Equip_Axis;
	return EX_NAV_OK;
}
void EquipAxisDelete(EQUIPAXIS *EquipAxis)
{
	memset(EquipAxis, 0, sizeof(EQUIPAXIS));
}

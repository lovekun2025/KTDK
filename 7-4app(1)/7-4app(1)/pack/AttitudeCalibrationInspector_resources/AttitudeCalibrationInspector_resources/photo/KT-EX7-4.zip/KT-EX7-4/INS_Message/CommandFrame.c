/*--------------------------------------------------------------------------
* File Name: CommandFrame.cpp
* Module: 
* Abstact: 	
* Author: Qiao Yuyang
* DATA: 2017-5-13  21:44
--------------------------------------------------------------------------*/

/*--------------------------- Debug Switch    ----------------------------*/



/*--------------------------- Include File    ----------------------------*/
#include "CommandFrame.h"
/*--------------------------- Macro Define    ----------------------------*/


/*--------------------------- Struct Define    ----------------------------*/


/*--------------------------- Local Variable  ----------------------------*/
/*--------------------------- Local Prototype ----------------------------*/

int Tokenpp(char** pBuffer, char* cWord,const char strSep);

int DisableCommand(char* cmd, CommandMap* cmdMap, int cmdMapSize)
{
	int i;
	for (i=0; i<cmdMapSize; i++)
    {
		// ����ؼ��ֱȽϣ����Դ�Сд
		if (STRNCASECMP(cmd, cmdMap[i].CommandKey, CMD_KEY_MAX_LEN) == 0)
        {		
            cmdMap[i].EnableFlag = FUNC_DISABLE;
			break;
        }
    }
	return FUNC_OK;
}

int EnableCommand(char* cmd, CommandMap* cmdMap, int cmdMapSize)
{
	int i;
	for (i=0; i<cmdMapSize; i++)
    {
		// ����ؼ��ֱȽϣ����Դ�Сд
		if (STRNCASECMP(cmd, cmdMap[i].CommandKey, CMD_KEY_MAX_LEN) == 0)
        {		
            cmdMap[i].EnableFlag = FUNC_ENABLE;
			break;
        }
    }
	return FUNC_OK;
}

int DisableAllCommand(CommandMap* cmdMap, int cmdMapSize)
{
	int i;
	for (i=0; i<cmdMapSize; i++)
    {	
		cmdMap[i].EnableFlag = FUNC_DISABLE;
    }
	return FUNC_OK;
}

int EnableAllCommand(CommandMap* cmdMap, int cmdMapSize)
{
	int i;
	for (i=0; i<cmdMapSize; i++)
    {		
		if (cmdMap[i].VersionDefine != FUNC_DISABLE)
		{
			cmdMap[i].EnableFlag = FUNC_ENABLE;
		}	
    }
	return FUNC_OK;
}

int CmdProcss(char* cmdWord, CommandMap* cmdMap, int cmdMapSize, char* strMessage, uint32_t nSource)
{
    int i;
    int length = 0;
    int arg_n = 0;
    char arg_c[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN]; // ���16������ ÿ���������16���ַ� �ر�ע�����һ����β\0
    char* pointer = cmdWord;
	char word[32];
	
	// �������ַ������ո�򶺺�Ϊ�绮��Ϊ��������
	do{
		length = Tokenpp(&pointer, word, ' ');
		if (length > 0 && length <= CMD_KEY_MAX_LEN) //ÿ���������16���ַ�
		{
			strncpy(arg_c[arg_n], word, CMD_KEY_MAX_LEN);
			arg_n++;
			if (arg_n>(CMD_KEY_MAX_LEN-1)) // ���16������
			{
				break;
			}
		}
	} while (length > 0);

	// ���������б������ж�Ӧ�������д�������
    for (i=0; i<cmdMapSize; i++)
    {
		// ����ؼ��ֱȽϣ����Դ�Сд
		if (STRNCASECMP(arg_c[0], cmdMap[i].CommandKey, CMD_KEY_MAX_LEN) == 0 && cmdMap[i].EnableFlag != FUNC_DISABLE)
        {		
            if ( cmdMap[i].CallBackFunc(arg_n, arg_c, nSource) == 1)
            {
            } 
            else
            {
            }
			strMessage[0] = '\0';
			break;
        }
    }
	
	// ���û�ж�Ӧ������ش�����Ϣ
	if(i==cmdMapSize)
	{
		strncpy(strMessage, arg_c[0], CMD_KEY_MAX_LEN);
		strcat_safe(strMessage, " Unknown Command!\r\n", 512);
	}
	
    return 0;
}

int Tokenpp(char** pBuffer, char* cWord, const char strSep)
{
    int i = 0;
    int length = 0;
    while(((*pBuffer))[i] != '\0')
    {
		if ((*pBuffer)[i] == strSep)
		{
			if(length != 0)
			{
				break;
			}
		}
        cWord[length] = (*pBuffer)[i];
		if(cWord[length] != ' ')
		{
			length++;
		}
        i++;
    }
    (*pBuffer) += i;
    cWord[length] = '\0';
    return length;
}

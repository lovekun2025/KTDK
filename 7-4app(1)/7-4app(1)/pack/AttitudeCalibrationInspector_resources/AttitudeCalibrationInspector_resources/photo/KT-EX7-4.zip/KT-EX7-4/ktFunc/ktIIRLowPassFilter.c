#include "ktIIRLowPassFilter.h"

#ifdef IIR_FILER_1_ENABLE

FILTER_LOWPASS LowPassFilter1[KT_IIR_LOW_PASS_FILER_1_N];

/***
* �����ݡ��ӱ�����ǵ�iir�˲����ֿ���ĳЩ��Ʒ��iir�˲���������һ�� 
*
*/
void ktIIRLowPassFilter1Init()
{
  unsigned char i = 0;
  //3����
  for(i = 0; i < 3; i++)
  {
    LowPassFilter1[i].u0 = 0;
    LowPassFilter1[i].u1 = 0;
    LowPassFilter1[i].u2 = 0;
    LowPassFilter1[i].y0 = 0;
    LowPassFilter1[i].y1 = 0;
    LowPassFilter1[i].y2 = 0;
    LowPassFilter1[i].Gain = IIR_LOW_PASS_FILER_1_GYRO_GAIN;
    LowPassFilter1[i].a = 2;
    LowPassFilter1[i].b = IIR_LOW_PASS_FILER_1_GYRO_B;
    LowPassFilter1[i].c = IIR_LOW_PASS_FILER_1_GYRO_C;  
  }
  //6���Ʒ�����Ӽӱ��ĵ�ͨ�˲�������ʼ��
  if(KT_IIR_LOW_PASS_FILER_1_N>=6)
  {
    //3�ӱ�
    for(i = 3; i < 6; i++)
    {
      LowPassFilter1[i].u0 = 0;
      LowPassFilter1[i].u1 = 0;
      LowPassFilter1[i].u2 = 0;
      LowPassFilter1[i].y0 = 0;
      LowPassFilter1[i].y1 = 0;
      LowPassFilter1[i].y2 = 0;
      LowPassFilter1[i].Gain = IIR_LOW_PASS_FILER_1_ACCE_GAIN;
      LowPassFilter1[i].a = 2;
      LowPassFilter1[i].b = IIR_LOW_PASS_FILER_1_ACCE_B;
      LowPassFilter1[i].c = IIR_LOW_PASS_FILER_1_ACCE_C;  
    }
  }
  //9���Ʒ��������ǵȵĵ�ͨ�˲�������ʼ��
  if(KT_IIR_LOW_PASS_FILER_1_N>=9)
  {
    //3���
    for(i = 6; i < 9; i++)
    {
      LowPassFilter1[i].u0 = 0;
      LowPassFilter1[i].u1 = 0;
      LowPassFilter1[i].u2 = 0;
      LowPassFilter1[i].y0 = 0;
      LowPassFilter1[i].y1 = 0;
      LowPassFilter1[i].y2 = 0;
      LowPassFilter1[i].Gain = IIR_LOW_PASS_FILER_1_TITL_GAIN;
      LowPassFilter1[i].a = 2;
      LowPassFilter1[i].b = IIR_LOW_PASS_FILER_1_TITL_B;
      LowPassFilter1[i].c = IIR_LOW_PASS_FILER_1_TITL_C;  
    }
  }
}

#endif

/***
* ���������˲���ʽ
*
*/
#ifdef IIR_FILER_2_ENABLE

FILTER_LOWPASS LowPassFilter2[KT_IIR_LOW_PASS_FILER_2_N];

void ktIIRLowPassFilter2Init()
{
  unsigned char i = 0;
  for(i = 0; i < KT_IIR_LOW_PASS_FILER_1_N; i++)
  {
    LowPassFilter2[i].u0 = 0;
    LowPassFilter2[i].u1 = 0;
    LowPassFilter2[i].u2 = 0;
    LowPassFilter2[i].y0 = 0;
    LowPassFilter2[i].y1 = 0;
    LowPassFilter2[i].y2 = 0;
    LowPassFilter2[i].Gain = IIR_LOW_PASS_FILER_2_GAIN;
    LowPassFilter2[i].a = 2;
    LowPassFilter2[i].b = IIR_LOW_PASS_FILER_2_B;
    LowPassFilter2[i].c = IIR_LOW_PASS_FILER_2_C;  
  }
}
#endif


void ktIIRLowPassFilterDeal(float *ins_data,FILTER_LOWPASS *filter)
{
  filter->u0 = *ins_data;
  filter->y0 = filter->Gain*(filter->u0 + filter->a*filter->u1 + filter->u2) - filter->b*filter->y1 - filter->c*filter->y2;
  filter->y2 = filter->y1;
  filter->y1 = filter->y0;
  filter->u2 = filter->u1;
  filter->u1 = filter->u0;
  *ins_data = filter->y0;
}

#ifndef __ShenHaiLan_H
#define __ShenHaiLan_H
#include "Global.h"


//RS422 ʹ��USART3�����ںʹ�����ͨѶ
#define USART3_422                   USART3
#define USART3_422_GPIO              GPIOB
#define USART3_422_CLK               RCC_APB1Periph_USART3
#define USART3_422_GPIO_CLK          RCC_AHB1Periph_GPIOB
#define USART3_422_RxPin             GPIO_Pin_11
#define USART3_422_TxPin             GPIO_Pin_10
#define USART3_422_IRQn              USART3_IRQn
#define USART3_422_IRQHandler        USART3_IRQHandler
#define USART3_422_DR_Base           0x40004804


void shenhailan_cmd_send(void);

int32_t ShenHaiLan_MagInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t ShenHaiLan_MagFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t ShenHaiLan_MagFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t ShenHaiLan_MagFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);














#endif


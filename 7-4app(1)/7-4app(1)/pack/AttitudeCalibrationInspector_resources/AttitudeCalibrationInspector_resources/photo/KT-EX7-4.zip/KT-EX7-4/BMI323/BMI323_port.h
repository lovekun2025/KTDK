#ifndef __BMI323_PORT_H
#define __BMI323_PORT_H

#include "includes.h" 

#define BMI323_GD_F405_SPI

#ifdef BMI323_GD_F405_SPI

#include "stm32f4xx.h"

#define BMI323_WRITE_READ_PORT       SPI1

#define BMI323_CS1_PORT              GPIOB 
#define BMI323_CS1_PIN               GPIO_Pin_1

#define BMI323_CS2_PORT              GPIOA 
#define BMI323_CS2_PIN               GPIO_Pin_4

#endif

void BMI323_CS_Set(uint8_t csNum, uint8_t ioStatus);
uint16_t BMI323_Write_Read(uint16_t wrData1, uint16_t wrData2);
void BMI323_Multi_Write_Read(uint16_t wrData1, uint16_t wrData2, uint16_t rdData[2]);
#endif
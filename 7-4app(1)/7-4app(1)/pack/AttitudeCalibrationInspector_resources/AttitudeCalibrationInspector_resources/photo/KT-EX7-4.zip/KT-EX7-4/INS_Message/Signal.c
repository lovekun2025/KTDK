/**
 * @file 
 * @author Qiaoyy@xlnav.com
 * @version 
 * @date 
 * @brief  
 * Copyright (c) 2018 XiLang Co. Ltd.
 * All rights reserved.
 */
 
/* Includes ------------------------------------------------------------------*/
#include "Global.h"
#include "Signal.h"
/* Private typedef -----------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
SignalStatusTypeDef g_GlobalStatus = {FUNC_DISABLE,FUNC_DISABLE,FUNC_DISABLE,FUNC_DISABLE};
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
 * @brief  
 * @param
 * @return 
*/
void GenerateSignal(unsigned int signals)
{
	switch(signals)
	{
		case SIGNAL_GPS_PPS_SYNCHRONIZATION:
			g_GlobalStatus.flag_gps_pps = FUNC_ENABLE;
			break;
		default:
			break;
	}
}

/**
 * @brief  
 * @param
 * @return 
*/
unsigned int CheckSignalKey(unsigned int *key)
{
	if (*key == FUNC_ENABLE)
	{
		*key = FUNC_DISABLE;
		return FUNC_ENABLE; 
	}
	else
	{
		return FUNC_DISABLE;
	}
}

/**
 * @brief  
 * @param
 * @return 
*/
unsigned int SignalKeyIsEnable(unsigned int key)
{
	if (key == FUNC_ENABLE)
	{
		return FUNC_ENABLE; 
	}
	else
	{
		return FUNC_DISABLE;
	}
}

/**
 * @brief  
 * @param
 * @return 
*/
void EnableSignalKey(unsigned int *key)
{
	*key = FUNC_ENABLE;
}

/**
 * @brief  
 * @param
 * @return 
*/
void DisableSignalKey(unsigned int *key)
{
	*key = FUNC_DISABLE;
}

/**
 * @brief  
 * @param
 * @return 
*/
SignalStatusTypeDef* GetGlobalSignalStatus()
{
	return &g_GlobalStatus;
}

/**
 * @brief  
 * @param
 * @return 
*/
void SetGlobalSignalStatus(SignalStatusTypeDef* signalStatus)
{
	memcpy(&g_GlobalStatus, signalStatus, sizeof(SignalStatusTypeDef));
}
/************************ (C) COPYRIGHT XiLang CO. Ltd. ****** END OF FILE ****/


#ifndef SYSTICK_H
#define SYSTICK_H


#define TICKS_PER_SECOND  1000   //HZ


void systick_config();
void systickIntEnable();
uint32_t getTicks();
void delay_1ms(uint32_t delay);
void delay_1us(uint32_t delay);



#endif /* SYSTICK_H */

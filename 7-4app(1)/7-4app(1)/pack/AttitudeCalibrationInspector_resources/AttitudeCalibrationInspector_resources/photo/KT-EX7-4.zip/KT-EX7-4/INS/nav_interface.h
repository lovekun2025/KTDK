#ifndef _NAV_INTERFACE_H
#define _NAV_INTERFACE_H
//#include "..\Global.h"
#include "nav_globalctl.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define NAV_SAM_CNT_MIN 20

typedef struct input_data
{
	int Ng[3];
	int Na[3];
	int Nmag[3];
    float temperature;

	unsigned short usDeltaCounter;
	unsigned char flgMagAvalabel;
	unsigned char flgPressureAvalabel;
	unsigned char flgGprmcAvalable;

}ST_IN_DATA;

typedef struct LOG_data
{	
////////////////////////  IMU misalignment ///////////////////////////////////////
	float IMU_ksx;				
	float IMU_ksy;				
	float IMU_ksz;		
///////////////////////////////////////////////////////////////////////////////
/////////////////////// Mag bias & misalgnment  //////////////////////////////
	float Mag_k0[3];
	float Mag_k[3];
///////////////////////////////////////////////////////////////////////////////
/////////////////////// Calibration Flag //////////////////////////////	
	char Done_Flag;
}LOGOUT_CALIBRATION;


typedef struct{
        float fOmiga[3];
	unsigned int uTNav;
	float fYaw;
	float fPitch;
	float fRoll;
	float fPYaw;
	float fPPitch;
	float fPRoll;
	unsigned int status;

	unsigned int uTImu;
        unsigned short int usFImu;
	float fAcc[3];
	float fGyro[3];	
	float fTc;
	float fdV[3];
	float fdw[3];	

	unsigned int uTMag;
        unsigned short int usFMag;
	float fMag[3];
	float fMAcc[3];	
}nav_QSENS_NavData1;

int nav_gps_wait(ST_IN_DATA *stIn, NAVCTL *navctl);
void nav_sen_read(ST_IN_DATA *stIn, NAVCTL *navctl);
void nav_main1(ST_IN_DATA *stIn);
void nav_main2();

void InitFiles();
void OutputFile();
nav_QSENS_NavData1* GetNavResult(void);
nav_QSENS_NavData1* GetNavResult2(void);
void ImuDataFile();
#endif /* _COMMON_H */







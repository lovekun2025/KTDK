#ifndef PARSEFRAME_H_20175201932
#define PARSEFRAME_H_20175201932
/**
 * @file DatagamFrame.h
 * @author Qiaoyy@xlnav.com
 * @date 2018-4-4
 * @brief  ͨѶ֡�������
 * Copyright (c) 2018 XiLang Co. Ltd.
 * All rights reserved.
   
                      ##### ���ʹ��ͨѶ֡������� #####
  ==============================================================================
  
 */
 
/* Includes ------------------------------------------------------------------*/
#include "Global.h"
/* Exported macro ------------------------------------------------------------*/
#define MAX_FRAME_TYPE 8
#define MAX_FRAME_HEAD_LENGTH 8
#define MAX_FRAME_TAIL_LENGTH 8
#define MAX_PARSE_BUFFER_SIZE 1024
#define TRANSPORT_LAYER_DEFINE_BEGIN(table) FrameTemplet table[] = {
#define TRANSPORT_LAYER_DEFINE_END {FIXED_LENGTH_FRAME, "", "", 0,0,0,0}};
#define TRANSPORT_NUMBER(table) ((sizeof(table)/sizeof(FrameTemplet))-1)                             

#define CONSTRUCT_PARSE_PARAM_MEMORY_POOL(buf, size, tab, id) unsigned char buf##_memory[size];\
                                                  ParseParam buf = {0,PARSE_INITIAL,0,0,0,(size),0,0,{0},buf##_memory,(tab),TRANSPORT_NUMBER(tab),0, (id)};
												  
#define DEFINE_MESSAGE_LIST_BEGIN(msglist) MessageInfoTypeDef msglist[] = {
#define DEFINE_MESSAGE_LIST_END };
	
#define DEFINE_CHANNLE_LIST_BEGIN(chnlist) ChannelInofTypeDef chnlist[] = {
#define DEFINE_CHANNLE_LIST_END };

#define CONSTRUCT_OUTPUT_MANAGER(msglist, chnlist, manager) uint32_t g_##manager##PeriodTable[(sizeof(msglist) / sizeof(MessageInfoTypeDef)) * sizeof(chnlist) / sizeof(ChannelInofTypeDef)] = { 0 };\
								 uint32_t g_##manager##CounterTable[(sizeof(msglist) / sizeof(MessageInfoTypeDef))*(sizeof(chnlist) / sizeof(ChannelInofTypeDef))] = { 0 };\
								 OutputManagerTypeDef manager = { sizeof(msglist) / sizeof(MessageInfoTypeDef),sizeof(chnlist) / sizeof(ChannelInofTypeDef),msglist,chnlist, g_##manager##PeriodTable, g_##manager##CounterTable };

// ���ݼ��
// ��ƣ�
#define MESSAGE_STATUS_INIT			0x00 
#define MESSAGE_STATUS_REVIEVED 	0x01
#define MESSAGE_STATUS_UPDATED	 	0x02
#define MESSAGE_STATUS_AVALABEL	 	0x03

#define MESSAGE_ERROR_CHECK 	0x00
#define MESSAGE_ERROR_AVALABEL 	0x01								

#define TRANVERSE16(X) (X) = ((((uint16_t)(X) & 0xff00) >> 8) |(((uint16_t)(X) & 0x00ff) << 8))
#define TRANVERSE32(X) (X) = ((((uint32_t)(X) & 0xff000000) >> 24) | (((uint32_t)(X) & 0x00ff0000) >> 8) | \
                       (((uint32_t)(X) & 0x0000ff00) << 8) | (((uint32_t)(X) & 0x000000ff) << 24))								 
/* Exported types ------------------------------------------------------------*/
typedef int32_t (*FrameParseCallBack)(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
typedef void(*OutputFunc)(void* message, DoubleBuffer* buf);

enum ParseStep
{
	PARSE_INITIAL = 0,
	PARSE_FOUND_HEAD,
	PARSE_RECIEVE_DATA,
	PARSE_FOUND_TAIL
};

enum FrameType{FIXED_LENGTH_FRAME=0, UNFIXED_LENGTH_FRAME,  SETTING_LENGTH_FRAME};


/**
 *  ֡ģ��  FrameTemplet
 **/
typedef struct 
{
	enum FrameType nFrameType;				//!<
    int8_t FrameHead[MAX_FRAME_HEAD_LENGTH]; 	//!<
    int8_t FrameTail[MAX_FRAME_TAIL_LENGTH]; 	//!<
	uint16_t FrameHeadLength;			//!<
	uint16_t FrameParamLength; 		//!<
    FrameParseCallBack InitFunc;			//!<
	FrameParseCallBack LengthFunc;			//!<
    FrameParseCallBack CheckFunc;			//!<
	FrameParseCallBack ParseFunc;			//!<
}FrameTemplet;

/**
 *  ֡�����ṹ��  ParseParam
 **/
typedef struct  
{
    uint16_t nReadCounter; 
    enum ParseStep nStep;
    uint16_t nFrameCounter;
    uint16_t nTailCounter;
    uint16_t nFrameNumber;
	uint16_t nBufferSize;
	uint16_t nErrorCode;
	uint16_t nFrameLength;
    int8_t cSelect[MAX_FRAME_TYPE];
    uint8_t* pBuffer;
	FrameTemplet* TransportFrameDefine;
	uint16_t TransportFrameNumber;
	uint8_t flagSync;
	uint32_t PortId;
} ParseParam;

/**
 * ���ղ����ṹ��
 **/
typedef struct
{
	unsigned long nUpdateTimes;			//!< ���ݸ��´���
	unsigned long nReadTimes;			//!< ���ݶ�ȡ����
	unsigned short usCheckErrorTimes;	//!< У��ʹ���
	unsigned short usAvalabelErrorTimes;//!< У��ʹ���
	unsigned char Status;				//!< ����֡��ȡ��־λ
	unsigned char ucErrorCode;			//!< ������
}RecieveParam;

/**
 *  8λ֡����
 **/
typedef struct
{
	unsigned char last;
	short delta;
	unsigned char first;
	unsigned char current;
}FrameCounterUint8;

/**
 *  16λ֡����
 **/
typedef struct
{
	unsigned short current;
	unsigned short last;
    long delta;
	unsigned short first;
}FrameCounterUint16;

/**
 *  ֡����ṹ��
 **/
typedef struct
{
	uint16_t nFrameLengthBegin;
	uint16_t nFrameLengthPos;
	uint16_t nFrameLengthSize;
	uint16_t nCheckBegin;
	uint16_t nStep;
	uint8_t check;
	uint16_t check16;
}FrameConstructor;

typedef struct
{
	char MessageName[32];
	uint8_t Group;
} MessageInfoTypeDef;

typedef struct
{
	char ChannelName[32];
	DoubleBuffer* pOutputBuffer;
} ChannelInofTypeDef;

typedef struct
{
	uint32_t messageNumber;
	uint32_t bufferNumber;
	MessageInfoTypeDef* pMessageList;
	ChannelInofTypeDef* pChannelList;
	uint32_t* pPeriodTable;
	uint32_t* pCounterTable;
}OutputManagerTypeDef;

/* Exported constants --------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
void ClearParseParam(ParseParam* io_ParseParam);
int32_t ParseFrameByte(uint8_t i_ucByte, ParseParam* io_pParseParam);
void InitFrameParse(ParseParam* io_ParseParam, uint8_t* i_pcBuffer, int32_t i_nBufferSize);
void ParseFrame(CircularBuffer* buf, ParseParam* pParseParam, unsigned int nMaxReadTimes);
void ParseFrame_DMA(DMA_CircularBuffer* dmaCBuffer, ParseParam* pParseParam, unsigned int nMaxReadTimes);
uint32_t GetBitMsb(uint8_t* pBuffer, int32_t nBeginBit, int32_t nBitNumber);
uint32_t GetBit(uint8_t* pBuffer, int32_t nBeginBit, int32_t nBitNumber);
int16_t GetShort(uint8_t* pBuffer);
uint32_t GetULong(uint8_t* pBuffer);
int32_t GetLong(uint8_t* pBuffer);
uint16_t GetUShort(uint8_t* pBuffer);
int16_t GetShortBigEnd(uint8_t* pBuffer);
uint16_t GetUShortBigEnd(uint8_t* pBuffer);
int32_t GetLongBigEnd(uint8_t* pBuffer);
uint32_t GetULongBigEnd(uint8_t* pBuffer);
float GetFloat(uint8_t* pBuffer);
double GetDouble(uint8_t* pBuffer);

uint32_t GetULongContinue(uint8_t* pBuffer, int32_t* nCounter);
int16_t GetShortContinue(uint8_t* pBuffer, int32_t* nCounter);
int32_t GetLongContinue(uint8_t* pBuffer, int32_t* nCounter);
uint16_t GetUShortContinue(uint8_t* pBuffer, int32_t* nCounter);
int16_t GetShortBigEndContinue(uint8_t* pBuffer, int32_t* nCounter);
uint16_t GetUShortBigEndContinue(uint8_t* pBuffer, int32_t* nCounter);
int32_t GetLongBigEndContinue(uint8_t* pBuffer, int32_t* nCounter);
uint32_t GetULongBigEndContinue(uint8_t* pBuffer, int32_t* nCounter);
float GetFloatContinue(uint8_t* pBuffer, int32_t* nCounter);
double GetDoubleContinue(uint8_t* pBuffer, int32_t* nCounter);

unsigned char CalculateCheckSum(unsigned char* pBuffer, int start, int end);
unsigned short CheckSum16CRC(unsigned char* pBuffer, int nLength);
unsigned char CheckSum8(unsigned char* pBuffer, int nLength);

void CalculateDeltaCounterUint16(FrameCounterUint16* counter);
void CalculateDeltaCounterUint8(FrameCounterUint8* counter);

void FrameBegin(DoubleBuffer* buf, FrameConstructor* frm);
void FrameEnd(DoubleBuffer* buf, FrameConstructor* frm);
void CheckSectionBegin(DoubleBuffer* buf, FrameConstructor* frm);
void CheckSectionEnd(DoubleBuffer* buf, FrameConstructor* frm);
void CheckSectionCrcEnd(DoubleBuffer* buf, FrameConstructor* frm);
void CheckSectionMAHREnd(DoubleBuffer* buf, FrameConstructor* frm);
void LengthSectionBegin(DoubleBuffer* buf, FrameConstructor* frm);
void LengthSectionEnd(DoubleBuffer* buf, FrameConstructor* frm);
void MarkLengthPosition(DoubleBuffer* buf, FrameConstructor* frm, int nLength);
void ClearFrameConstructor(FrameConstructor* frm);

void InitOutputManage(uint32_t* table, OutputManagerTypeDef* manager);
int CheckOutputManageTabel(OutputManagerTypeDef* manager, int MessageId, int BufferId, DoubleBuffer** buffer);
void ParseFrameUsart1(void);
void ParseFrameUsart2(void);
void ParseFrameUsart3(void);

#endif
/************************ (C) COPYRIGHT XiLang CO. Ltd. *******END OF FILE*****/

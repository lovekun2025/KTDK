#ifndef _NAV_CALIMAG_H
#define _NAV_CALIMAG_H

#define MAGSLIDNUM 5

#define MAG_M0 9//4
typedef struct _MAGKFDONE MAGKFDONE;
struct _MAGKFDONE
{
	float MAG_X1[MAG_M0];
	float MAG_z1[1];
	float MAG_H1[MAG_M0];
	float MAG_R1[1];
	float MAG_P1[MAG_M0*MAG_M0];	
	float MAG_Q[MAG_M0*MAG_M0];	
};

typedef struct _CALIBRATEMAG CALIBRATEMAG;
struct _CALIBRATEMAG
{
	MAGKFDONE   magkfdone;
	float      Km1[12];
	float      bm1[3];
	float      Km2[12];
	float      bm2[3];
	float      Mag_out[3];
	float      q_Mag[4];
	float      qa_Mag[4];
	float      Cbn_Mag[3][3];
	float      Cbn_Mag1[3][3];
	float      Mag_DF[3];
	float 		werrb[3];
	float 		werrb1[3];
	float 		werr[3];
	float 		werr1[3];
	float      ksaig2,thita2,gama2;
	float 		Max[3];
	float 		Min[3];
	float      VectVar;
	float       Slid[3][MAGSLIDNUM];
	float      Wbi[3];
	float      SlidAve[3];
	float      Std[3];
	float      SlidAve1[3];
	float      Std1[3];
	float     SlidAve2[3];
	float      Std2[3];
	int         SlidCounter;
	int         BiasCounter;
	char        status;
	char        flagmag;
	char        start;
	char        UpdatFlg;
	int         Combine_Counter;
	int         Mag_Counter;
	float      Cal_Mag_Heading;
	float      Cal_Mag_thita;
	float      Cal_Mag_gama;
	double      Latitude;
	double      Longitude;
	float      MagDeclination;
	float      MagInclination;
	float      MagMisalign;
	float      MagStrength;
	float 		MagStrNorth;
	float 	MagStrDown;
	
	int         (*Get_kf_calimag)(CALIBRATEMAG *cali_mag, int m);
	int         (*Get_Cali_Mag)(CALIBRATEMAG *cali_mag, float mag[3], int m);
	int         (*Get_calimag_9d)(CALIBRATEMAG *cali_mag, float mag[3],int m);
	int         (*Get_calimag_6d)(CALIBRATEMAG *cali_mag, float mag[3],int m);
	int         (*Get_calimag_5d)(CALIBRATEMAG *cali_mag, float mag[3],int m);
	int         (*Get_calimag_4d)(CALIBRATEMAG *cali_mag, float mag[3],int m);
	int         (*Get_Do_CaliMag)(CALIBRATEMAG *cali_mag, float Nmag[3]);
};

int nav_CaliMagCreate(CALIBRATEMAG *cali_mag);
void nav_CaliMagDelete(CALIBRATEMAG *cali_mag);
#endif

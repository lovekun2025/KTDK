#include "includes.h"
#include "MGZ2067.h"


//��������д��������һ�δ���ʱ��Ƭѡ���ߣ�������дʱ��ַ���Ӿ�û����
void MGZ2067_Write(uint8_t addr, uint8_t data)
{
  uint16_t wrData = 0;
  uint16_t rdData = 0;
  
  wrData = (0x4000 | (addr << 8)) | data;
  
  MGZ2067_Write_Read(wrData,&rdData);
}

void MGZ2067_Read(uint8_t addr,uint16_t *rdData)
{
  uint16_t wrData;
  uint16_t *rdDataPt = rdData;
  
  wrData = (0xC000 | (addr << 8));
 
  MGZ2067_Write_Read(wrData,rdDataPt); 

}

void MGZ2067_Set_Page0(uint8_t DeviceNum)
{
    MGZ2067_CS_Set(DeviceNum, 0);
    MGZ2067_Write(MGZ2067_PAGE_SEL_ADDR, 0x00);
    MGZ2067_CS_Set(DeviceNum, 1);
}

void MGZ2067_Set_Page1(uint8_t DeviceNum)
{
    MGZ2067_CS_Set(DeviceNum, 0);
    MGZ2067_Write(MGZ2067_PAGE_SEL_ADDR, 0x01);
    MGZ2067_CS_Set(DeviceNum, 1);
}

/******* Ӧ������0x39�����ֲ��11ҳ������ͨ�� ***********************************/
uint8_t MGZ2067_Get_DEVID_ID1(uint8_t DeviceNum)
{
  uint16_t rdData[MGZ2067_NUM];
  uint8_t returnTemp = 0;
  
  MGZ2067_CS_Set(DeviceNum, 0);
  
  MGZ2067_Read(MGZ2067_CHIP_ID1_ADDR,rdData); 
  
  MGZ2067_CS_Set(DeviceNum, 1);
  
  return returnTemp;
}

/******* Ӧ������0x01�����ֲ��11ҳ������ͨ�� ***********************************/
uint8_t MGZ2067_Get_DEVID_ID2(uint8_t DeviceNum)
{
  uint16_t rdData[MGZ2067_NUM];
  uint8_t returnTemp = 0;

  MGZ2067_CS_Set(DeviceNum, 0);
  MGZ2067_Read(MGZ2067_CHIP_ID2_ADDR,rdData); 
  MGZ2067_CS_Set(DeviceNum, 1);
  
  return returnTemp;
}



uint8_t MGZ2067_Get_ready_Stauts(uint8_t DeviceNum)
{
  uint16_t rdData = 0;
    
  MGZ2067_CS_Set(DeviceNum, 0);
  
  MGZ2067_Read(MGZ2067_READY_STATUS_ADDR,&rdData); 
 
  MGZ2067_CS_Set(DeviceNum, 1);
  
  return rdData;
  
}

void MGZ2067_Get_Gyro_T(uint8_t DeviceNum,int32_t *gyroData,int16_t *temperatrueData)
{

  uint16_t rxDataTemp[5];
  uint16_t *rxDataPt = rxDataTemp;
  uint8_t i = 0;
  
  int16_t temperatureDataTemp = 0;
  int32_t gyroDataTemp = 0;
  
  MGZ2067_CS_Set(DeviceNum, 0);

  MGZ2067_Read(MGZ2067_TEMP_DATA_ADDR,rxDataPt++);
  
  for(i = 0; i < 4; i++)
  {
    MGZ2067_Read(0x00,rxDataPt ++);
  }
  
  MGZ2067_CS_Set(DeviceNum, 1);

  temperatureDataTemp = (rxDataTemp[0] & 0x00FF) | (rxDataTemp[1] & 0xFF00);
  
  gyroDataTemp = (rxDataTemp[1] & 0x00FF) | (rxDataTemp[2] & 0xFF00) | ((rxDataTemp[2] & 0x00FF) << 16);
  
  gyroDataTemp = (gyroDataTemp << 8) >> 8;  
  
  *gyroData = gyroDataTemp;
  *temperatrueData = temperatureDataTemp;
  
}

uint8_t MGZ2067_Get_Status(uint8_t DeviceNum)
{
  uint16_t rdData = 0;
    
  MGZ2067_Set_Page1(DeviceNum);
  
  delay_1us(MGZ2067_TWO_SPI_DELAY_US);
  
  MGZ2067_CS_Set(DeviceNum, 0);
  
  MGZ2067_Read(MGZ2067_STATUS_ADDR,&rdData); 
 
  MGZ2067_CS_Set(DeviceNum, 1);
  
  delay_1us(MGZ2067_TWO_SPI_DELAY_US);
  
  MGZ2067_Set_Page0(DeviceNum);
  
  return rdData;
}


/*******************************************************************************
* ���� [IN] DeviceNum       : ���ݱ��
* ���� [OUT] gyroData       : �������
* ���� [OUT] temperatrueData: ����¶�
* ���� [OUT] gyroStatus     : ���״̬
*******************************************************************************/
void MGZ2067_Get_Data(uint8_t DeviceNum,float *gyroData,float *temperatrueData)
{
  uint8_t readyTemp = 0;
  int16_t temperatureTemp = 0;
  int32_t gyroTemp = 0;
  
  
  readyTemp = MGZ2067_Get_ready_Stauts(DeviceNum); 
  
  delay_1us(MGZ2067_TWO_SPI_DELAY_US);
  
  if((readyTemp & MGZ2067_DATA_READY_BIT) == 0)
  {
    return;
  }
  else
  {
    MGZ2067_Get_Gyro_T(DeviceNum,&gyroTemp,&temperatureTemp);
    
  }
  
  *temperatrueData = MGZ2067_TEMPERATURE_K * temperatureTemp +  MGZ2067_TEMPERATURE_B;
  *gyroData = gyroTemp * 1.0;
}




void MGZ2067_Get_Data_withStatus(uint8_t DeviceNum,float *gyroData,float *temperatrueData,uint8_t *gyroStatus)
{
  uint8_t readyTemp = 0;
  uint8_t gyroErroStatus = 0;
  static uint32_t readyErroCnt = 0;
  static uint32_t statusErroCnt = 0;
  static uint32_t scaleErroCnt = 0;
  int16_t temperatureTemp = 0;
  int32_t gyroTemp = 0;
  uint8_t statusTemp = 0;
  
  
  readyTemp = MGZ2067_Get_ready_Stauts(DeviceNum); 
  
  delay_1us(MGZ2067_TWO_SPI_DELAY_US);
  
  if((readyTemp & MGZ2067_DATA_READY_BIT) == 0)
  {
    readyErroCnt ++;
    if(readyErroCnt > MGZ2067_ERRO_CNT_MAX)
      gyroErroStatus = gyroErroStatus | 0x01;
  }
  else
  {
    readyErroCnt = 0;
    MGZ2067_Get_Gyro_T(DeviceNum,&gyroTemp,&temperatureTemp);
    
    //�����ݴ���501��/s����С��0��ʱ�򣬳���200�����ϣ����ж������쳣
    if((abs(gyroTemp) > 8210000) || (gyroTemp == 0))
    {
      scaleErroCnt ++;
      if(scaleErroCnt > MGZ2067_ERRO_CNT_MAX)
      {
        gyroErroStatus = gyroErroStatus | 0x02;
      }
    }
    else
    {
      scaleErroCnt = 0;
    }  
  }
  
  statusTemp = MGZ2067_Get_Status(DeviceNum);
 
  if(((statusTemp & 0x08) == 0) || ((statusTemp & 0x80) == 0))
  {
    statusErroCnt++;
    if(statusErroCnt > MGZ2067_ERRO_CNT_MAX)
      gyroErroStatus = gyroErroStatus | 0x04;
  }
  else
  {
    statusErroCnt = 0;
  }
  
  *gyroStatus = gyroErroStatus;
  *temperatrueData = MGZ2067_TEMPERATURE_K * temperatureTemp +  MGZ2067_TEMPERATURE_B;
  *gyroData = gyroTemp * 1.0;
}



void MGZ2067_Erro_Deal(uint8_t gyroErroStatus)
{
  static uint8_t gyroResetStatus = 0;
  static uint32_t gyroErroTick = 0;
  
  uint8_t erroStatusTemp = gyroErroStatus;
  
  //��λ����
  if((gyroResetStatus == 0) && (erroStatusTemp > 0))
  {
    gyroResetStatus = 1;
    MGZ2067_Reset();    
  }
  
  //���ָ��������ӳ�
  if((gyroResetStatus == 1) && (erroStatusTemp == 0))
  {
    gyroResetStatus = 2;
    gyroErroTick = getTicks();
  }
  
  //��ʱ200ms  ����
  if(gyroResetStatus == 2)
  {
    if((getTicks() - gyroErroTick) > 200)
    {
      gyroResetStatus = 0;
    }         
  }
}

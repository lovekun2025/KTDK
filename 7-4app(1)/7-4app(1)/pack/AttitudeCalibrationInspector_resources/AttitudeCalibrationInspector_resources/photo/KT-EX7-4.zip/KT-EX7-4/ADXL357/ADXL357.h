#ifndef __ADXL357_H
#define __ADXL357_H

#include "ADXL357_port.h"


#define ADXL357_DEVID_AD         0X00 //ֻ����ģ���豸ID����λֵΪ0XAD
#define ADXL357_DEVID_MST        0X01//ֻ����ģ���豸MEMS ID,��λֵΪ0X1D
#define ADXL357_PARTID           0X02//ֻ�����豸ID����λֵ0XED
#define ADXL357_REVID            0X03//ֻ������Ʒ�汾ID
#define ADXL357_STATUS           0X04//ֻ������Ʒ״̬
#define ADXL357_FIFO_ENTRIES     0X05//ֻ����FIFO�������е���Ч����������0-96
/*ֻ�����¶ȼ����ٶ����ݼĴ���*/
#define ADXL357_TEMP2            0X06
#define ADXL357_TEMP1            0X07
#define ADXL357_XDATA3           0X08
#define ADXL357_XDATA2           0X09
#define ADXL357_XDATA1           0X0A
#define ADXL357_YDATA3           0X0B
#define ADXL357_YDATA2           0X0C
#define ADXL357_YDATA1           0X0D
#define ADXL357_ZDATA3           0X0E
#define ADXL357_ZDATA2           0X0F
#define ADXL357_ZDATA1           0X10
/*��ȡ�üĴ����Է���FIFO�е�����*/
#define ADXL357_FIFO_DATA        0X11
/**/
#define ADXL357_OFFSET_X_H       0X1E
#define ADXL357_OFFSET_X_L       0X1F
#define ADXL357_OFFSET_Y_H       0X20
#define ADXL357_OFFSET_Y_L       0X21
#define ADXL357_OFFSET_Z_H       0X22
#define ADXL357_OFFSET_Z_L       0X23

#define ADXL357_ACT_EN           0X24
#define ADXL357_ACT_THRESH_H     0X25
#define ADXL357_ACT_THRESH_L     0X26
#define ADXL357_ACT_COUNT        0X27

#define ADXL357_FILTER           0X28//ָ���˲�������
#define ADXL357_FIFO_SAMPLES     0X29//FIFO����
#define ADXL357_INT_MAP          0X2A//�ж��¼�����
#define ADXL357_SYNC             0X2B//�����ⲿ��ʱ����
#define ADXL357_RANGE            0X2C//���Ʋ�����Χ
#define ADXL357_POWER_CTL        0X2D//���Ƶ�Դ״̬
#define ADXL357_SELF_TEST        0X2E//���Ҽ�⹦�����üĴ���
#define ADXL357_RESET            0X2F//��λ�Ĵ���

#define ADXL357_Dummy            0X00
typedef enum
{
  ADXL357_ODR4000_OSR1000  = 0X00,
  ADXL357_ODR2000_OSR500   = 0X01,
  ADXL357_ODR1000_OSR250   = 0X02,
  ADXL357_ODR500_OSR125    = 0X03,
  ADXL357_ODR250_OSR562    = 0X04,
  ADXL357_ODR125_OSR31     = 0X05,
  ADXL357_ODR62_OSR15      = 0X06,
  ADXL357_ODR31_OSR7       = 0X07,
  ADXL357_ODR15_OSR3       = 0X08,
  ADXL357_ODR7_OSR1        = 0X09,
  ADXL357_ODR3_OSR0        = 0X0A
}ADXL357_ODR_LPF_TypeDef;


typedef enum
{
  ADXL357_RANGE_10 = 0,
  ADXL357_RANGE_20 ,
  ADXL357_RANGE_40, 
  ADXL355_RANGE_2,
  ADXL355_RANGE_4 ,
  ADXL355_RANGE_8   
}ADXL357_RANGE_TypeDef;

#define ADXL357Range10_Scale   1.95e-5 
#define ADXL357Range20_Scale   3.90e-5 
#define ADXL357Range40_Scale   7.80e-5

#define ADXL355Range2_Scale    3.90e-6 
#define ADXL355Range4_Scale    7.81e-6 
#define ADXL355Range8_Scale    1.56e-5 

#define ADXL357Temp_Scale      -0.1104972375690 //1/-9.05

typedef enum
{
  ADXL357_PWR_STD = 0,          //����ģʽ
  ADXL357_PWR_MEA   //����ģʽ
}ADXL357_PWR_TypeDef;

typedef struct
{
  ADXL357_ODR_LPF_TypeDef ODR_LPF;
  ADXL357_RANGE_TypeDef RANGE_357;

}ADXL357_InitTypeDef;


void ADXL357_Write(uint8_t addr, uint8_t data);
uint16_t ADXL357_Read(uint8_t addr);
void ADXL357_PowerOn_Reset(uint8_t DeviceNum);
void ADXL357_Init(uint8_t DeviceNum, ADXL357_InitTypeDef *ADXL357_InitStruct);
uint8_t ADXL357_Get_DEVID_ID(uint8_t DeviceNum);
uint8_t ADXL357_Get_DEVID_MST(uint8_t DeviceNum);
uint8_t ADXL357_Get_PARTID(uint8_t DeviceNum);
uint8_t ADXL357_Get_REVID(uint8_t DeviceNum);
uint8_t ADXL357_Get_STATUS(uint8_t DeviceNum);
uint8_t ADXL357_Get_FIFO_ENTRIES(uint8_t DeviceNum);
float ADXL357_Get_TEMP(uint8_t DeviceNum);
float ADXL357_Get_XData(uint8_t DeviceNum);
float ADXL357_Get_YData(uint8_t DeviceNum);
float ADXL357_Get_ZData(uint8_t DeviceNum);
void ADXL357_Get_Data(uint8_t DeviceNum, float Data[3], float *Temp_Data);
void ADXL357_Set_ODR_LPF(uint8_t DeviceNum, ADXL357_ODR_LPF_TypeDef ODR_LPF);
void ADXL357_Set_Range(uint8_t DeviceNum, ADXL357_RANGE_TypeDef RANGE357);
uint8_t ADXL357_Get_RANGE(uint8_t DeviceNum);
uint8_t ADXL357_Get_ODR_LPF(uint8_t DeviceNum);
void ADXL357_PWR_CRL(uint8_t DeviceNum, ADXL357_PWR_TypeDef PWR_STA);
float ADXL357_Self_Test(uint8_t DeviceNum, uint8_t ST2);
void ADXL357_Exit_Self_Test(uint8_t DeviceNum);
uint8_t ADXL357_Self_TestJudg(void);
void ADXL357_Reset(uint8_t DeviceNum);
void ADXL357_Data_Coversion(float Raw_Data[3], float New_Data[3], ADXL357_RANGE_TypeDef Value);
void ADXL357_Config_init();
#endif

#ifndef __MAX537_PORT_H
#define __MAX537_PORT_H


/****************************************************************************** 
*��������  2067   320
* SPIʱ���Ƽ�����Mode3ʱ�����͡���CPOL=1��CPHA=1
* ���⣬��Ҫ��ʼ��EN�ܽţ�����ʼ�������
******************************************************************************/


/******  1 ѡ��Ӳ��ƽ̨���ӿ� ************************************************/
//#define MAX537_GD_F103_SPI
//#define MAX537_ST_F103_SPI
#define MAX537_GD_F405_SPI


/******  2 ȷ����������  ****************************************************/
#define MAX537_NUM    3

/******  3 �������϶��壬�޸��·���Ӧ��Ӳ�����ú궨�� ***********************/



/******************************************************************************
*  STM32F103��Ƭѡ�Ǻ궨��
******************************************************************************/
#ifdef MAX537_ST_F103_SPI


#define MAX537_ENABLE_PORT           GPIOA
#define MAX537_ENABLE_PIN            GPIO_PIN_12    

#define MAX537_CS1_PORT              GPIOA 
#define MAX537_CS1_PIN               GPIO_PIN_11

#define MAX537_CS2_PORT              GPIOA 
#define MAX537_CS2_PIN               GPIO_PIN_2

#define MAX537_CS3_PORT              GPIOA 
#define MAX537_CS3_PIN               GPIO_PIN_3

#define MAX537_SPI                   SPI0

typedef struct
{
    uint32_t csPort;
    uint32_t csPin;
}MGXXXXcsMap_s;

#endif


/******************************************************************************
*  GD32F103��Ƭѡ�Ǻ궨��
******************************************************************************/
#ifdef MAX537_GD_F103_SPI


#define MAX537_ENABLE_PORT           GPIOB
#define MAX537_ENABLE_PIN            GPIO_PIN_1  

#define MAX537_CS1_PORT              GPIOA 
#define MAX537_CS1_PIN               GPIO_PIN_0

#define MAX537_CS2_PORT              GPIOA 
#define MAX537_CS2_PIN               GPIO_PIN_1

#define MAX537_CS3_PORT              GPIOA 
#define MAX537_CS3_PIN               GPIO_PIN_3

#define MAX537_SPI                   SPI0

typedef struct
{
    uint32_t csPort;
    uint32_t csPin;
}MGXXXXcsMap_s;

#endif


/******************************************************************************
*  GD32F405��Ƭѡ�Ǻ궨��
******************************************************************************/
#ifdef MAX537_GD_F405_SPI


#define MAX537_ENABLE_PORT           GPIOB
#define MAX537_ENABLE_PIN            GPIO_Pin_15  

#define MAX537_CS1_PORT              GPIOC 
#define MAX537_CS1_PIN               GPIO_Pin_4

#define MAX537_CS2_PORT              GPIOB 
#define MAX537_CS2_PIN               GPIO_Pin_0

#define MAX537_CS3_PORT              GPIOB
#define MAX537_CS3_PIN               GPIO_Pin_1

#define MAX537_SPI                   SPI1


typedef struct
{
  GPIO_TypeDef *csPort;
  uint16_t csPin;  
}MAX537csMap_s;

#endif


void MAX537_CS_Set(uint8_t csNum, uint8_t ioStatus);
void MAX537_Write_Read(uint16_t wrData,uint16_t *rdData);

#endif


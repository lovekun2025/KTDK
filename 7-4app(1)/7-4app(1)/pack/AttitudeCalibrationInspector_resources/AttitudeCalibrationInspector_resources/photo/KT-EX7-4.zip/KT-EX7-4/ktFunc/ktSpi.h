#ifndef __KT_SPI_H
#define __KT_SPI_H


void ktSpi0Init();
void ktSpi0GpioInit();


#endif
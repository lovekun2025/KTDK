#include "includes.h"
#include "MGZ2067_port.h" 


const MGZ2067csMap_s MGZ2067csMap[MGZ2067_NUM] = 
{

  {MGZ2067_CS1_PORT,MGZ2067_CS1_PIN}, 

#if MGZ2067_NUM > 1
  {MGZ2067_CS2_PORT,MGZ2067_CS2_PIN},
#endif
  
#if MGZ2067_NUM > 2  
  {MGZ2067_CS3_PORT,MGZ2067_CS3_PIN}, 
#endif
  
#if MGZ2067_NUM > 3  
  {MGZ2067_CS4_PORT,MGZ2067_CS4_PIN}, 
#endif
  
#if MGZ2067_NUM > 4  
  {MGZ2067_CS5_PORT,MGZ2067_CS5_PIN}, 
#endif
  
};


#ifdef MGZ2067_ST_F103_SPI

void MGZ2067_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(statusTemp == 0)  
    gpio_bit_reset(MGZ2067csMap[csNum].csPort,MGZ2067csMap[csNum].csPin);
  else
    gpio_bit_set(MGZ2067csMap[csNum].csPort,MGZ2067csMap[csNum].csPin);

}


void MGZ2067_Write_Read(uint16_t wrData,uint16_t *rdData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdDataTemp = 0;
  uint16_t *rdDataPt = rdData;
  

  wrDataTemp = wrData;
  
  while(RESET == spi_i2s_flag_get(MGZ2067_SPI, SPI_FLAG_TBE));
  spi_i2s_data_transmit(MGZ2067_SPI, wrDataTemp);
  while(RESET == spi_i2s_flag_get(MGZ2067_SPI, SPI_FLAG_RBNE));
  rdDataTemp = spi_i2s_data_receive(MGZ2067_SPI);
  
  *rdDataPt =  rdDataTemp;

}

/*******************************************************************************
* ˵�����ֲ���û�У�ʵ����Ҫ700ms���ܳ�����
*******************************************************************************/
void MGZ2067_Reset()
{
  gpio_bit_reset (MGZ2067_ENABLE_PORT, MGZ2067_ENABLE_PIN);   
  delay_1ms(1);
  gpio_bit_set (MGZ2067_ENABLE_PORT, MGZ2067_ENABLE_PIN);   
  
}

#endif


#ifdef MGZ2067_GD_F103_SPI

void MGZ2067_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(statusTemp == 0)  
    gpio_bit_reset(MGZ2067csMap[csNum].csPort,MGZ2067csMap[csNum].csPin);
  else
    gpio_bit_set(MGZ2067csMap[csNum].csPort,MGZ2067csMap[csNum].csPin);

}


void MGZ2067_Write_Read(uint16_t wrData,uint16_t *rdData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdDataTemp = 0;
  uint16_t *rdDataPt = rdData;
  

  wrDataTemp = wrData;
  
  while(RESET == spi_i2s_flag_get(MGZ2067_SPI, SPI_FLAG_TBE));
  spi_i2s_data_transmit(MGZ2067_SPI, wrDataTemp);
  while(RESET == spi_i2s_flag_get(MGZ2067_SPI, SPI_FLAG_RBNE));
  rdDataTemp = spi_i2s_data_receive(MGZ2067_SPI);
  
  *rdDataPt =  rdDataTemp;

}

/*******************************************************************************
* ˵�����ֲ���û�У�ʵ����Ҫ700ms���ܳ�����
*******************************************************************************/
void MGZ2067_Reset()
{
  gpio_bit_reset (MGZ2067_ENABLE_PORT, MGZ2067_ENABLE_PIN);   
  delay_1ms(1);
  gpio_bit_set (MGZ2067_ENABLE_PORT, MGZ2067_ENABLE_PIN);   
  
}

#endif



#ifdef MGZ2067_GD_F405_SPI

void MGZ2067_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(statusTemp == 0)  
    GPIO_ResetBits(MGZ2067csMap[csNum].csPort,MGZ2067csMap[csNum].csPin);
  else
    GPIO_SetBits(MGZ2067csMap[csNum].csPort,MGZ2067csMap[csNum].csPin);

}

void MGZ2067_Write_Read(uint16_t wrData,uint16_t *rdData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdDataTemp = 0;
  uint16_t *rdDataPt = rdData;
  
  wrDataTemp = wrData;
  
  while (SPI_I2S_GetFlagStatus(MGZ2067_SPI, SPI_I2S_FLAG_TXE) == RESET);
  SPI_I2S_SendData(MGZ2067_SPI, wrDataTemp);
  while (SPI_I2S_GetFlagStatus(MGZ2067_SPI, SPI_I2S_FLAG_RXNE) == RESET);
  rdDataTemp = SPI_I2S_ReceiveData(MGZ2067_SPI);
  
  *rdDataPt =  rdDataTemp;
}

/*******************************************************************************
* ˵�����ֲ���û�У�ʵ����Ҫ700ms���ܳ�����
*******************************************************************************/
void MGZ2067_Reset()
{
  GPIO_ResetBits (MGZ2067_ENABLE_PORT, MGZ2067_ENABLE_PIN);   
  delay_1ms(1);
  GPIO_SetBits (MGZ2067_ENABLE_PORT, MGZ2067_ENABLE_PIN);   
  
}

#endif

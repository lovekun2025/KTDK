/**
  ******************************************************************************
  * File Name          : ConstantDefine.h
  * Description        : 
  * ����һЩ���õĳ����������߼���BOOL�����������Ե��������ȡ� 
  *
  ******************************************************************************
  * @attention
  *

  */
/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __CONSTANTDEFINE_H
#define __CONSTANTDEFINE_H
#ifdef __cplusplus
 extern "C" {
#endif
   
//��1����1����
#define setbit(x,y) x |= (1<<y)    //��x�ĵ�yλ��1
#define clrbit(x,y) x &= ~(1<<y)    //��x�ĵ�yλ��1

/*************************************************************
    �߼���BOOL������
**************************************************************/
#define FALSE       0        /* Something is false. */
#define TRUE        1        /* Something is true. */

#define FAILURE       0        /* Something is FAILURE. */
#define SUCCESS       1        /* Something is SUCCESS. */

#define INVALID     0        /* Something is invalid. */
#define VALID       1        /* Something is valid. */

#define NO          0        /* The answer is no. */
#define YES         1        /* The answer is yes. */

#define FOUND       1   
#define OK          1

#define BAD         0          /* Something is bad. */
#define GOOD        1        /* Something is good. */

#define NONSINGULAR 0          /* Indicates a non-singular matrix. */
#define SINGULAR    1              /* Indicates a singular matrix. */

/*************************************************************
     ���Ե�������
*************************************************************/
#define OS_DX	       ( 0.0)        //����ϵƫ����
#define OS_DY	       ( 0.0)
#define OS_DZ	       ( 0.0)
#define Ra               ((float)6378137.0)                       /*WGS-84 earth's semi major axis*/
#define Rb               ((float)6356752.31)                      /*WGS-84 earth's semi minor axis*/
#define Rf               ((float)0.00335281317790)                /*1.0/298.257*/          /*�������*/
#define e1sqr            ((Ra * Ra - Rb * Rb) / (Ra * Ra))    /*first  numerical eccentricity*/
#define e2sqr            ((Ra * Ra - Rb * Rb) / (Rb * Rb))      /*second numerical eccentricity*/

/* WGS-84 Earth Model Parameters */
#define SPEED_OF_LIGHT       ((float)(2.99792458E+8))  
#define EARTH_SEMI_MAJOR     ((float)6378137.0)                      /*WGS-84 earth's semi major axis*/
#define OBLATENESS           ((float)0.00335281317790)          /*1.0/298.257*/          /*�������*/
#define GRAVCONSTANT         ((float)(3.986005E+14))            /*GM��������������*/ 

#define  GE                  ((float)9.8015)                      /* �������ٶ�*/
#define INV_GE               ((float)0.10202)

#define WGS84OE              ((float)(7.2921151467E-5))         /*angular rate of earth   */
#define W_IEE                ((float)(7.2921151467E-5))             /*the angular velocity of the earth.*/

#ifndef  M_PI
#define  M_PI                ((float)3.1415926535898)
#endif  

#define R2D                  ((float)57.2957795131)             /*radian to degree */
#define D2R                  ((float)0.01745329251994)          /*degree to radian*/

#define LDBL_EPSILON   1.19209287E-07L      /* SMALLEST X WHERE 1+X != 1      float  32bits!!   */
#define EPSILON        1.1920929E-07        /* SMALLEST X WHERE 1+X != 1         */


#ifdef __cplusplus
}
#endif
#endif /* __CONSTANTDEFINE_H  */

/**
  * @}
  */

/************************ (C) COPYRIGHT Beijing Kaituo    *****END OF FILE****/
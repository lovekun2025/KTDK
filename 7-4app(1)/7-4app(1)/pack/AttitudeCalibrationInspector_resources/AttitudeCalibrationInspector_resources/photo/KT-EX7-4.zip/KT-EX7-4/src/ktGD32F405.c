
#include "Includes.h"


void GPIO_config()
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOC,ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
  
  GPIO_SetBits(GPIOA,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_4);//1

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);  
  
  GPIO_SetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1);//acceƬѡ
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
  
  GPIO_SetBits(GPIOC,GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5);//1  
  
}

//��adxl357 ��bmi330 cs�ܽŽ�������
void GPIO_config_1()
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB,ENABLE);
  //GPIOA ����ģʽ ADXL357_CS PA3 
  GPIO_InitStructure.GPIO_Pin = ADXL357_CS_PIN ;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
  GPIO_SetBits(GPIOA, ADXL357_CS_PIN);
 
  //GPIOB ����ģʽ GYRO2_CS A4 
  GPIO_InitStructure.GPIO_Pin = BMI323_CS2_PIN ;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
  
  GPIO_SetBits(GPIOA, BMI323_CS2_PIN);
  
  //GPIOC ����ģʽ GYRO1_CS PB1 
  GPIO_InitStructure.GPIO_Pin = BMI323_CS1_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
  
  GPIO_SetBits(GPIOB, BMI323_CS1_PIN);
  //��ѹCS  PA2
   GPIO_InitStructure.GPIO_Pin = MS5607_CS_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
  
  GPIO_SetBits(GPIOA, MS5607_CS_PIN); 
  
  
  
}

void NVIC_config()
{  
  NVIC_InitTypeDef NVIC_InitStructure; 
  
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x20000);
  
  /* Configure the NVIC Preemption Priority Bits */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
  //NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; 
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  
//  NVIC_InitStructure.NVIC_IRQChannel = KT_TIMER0_IRQn; 
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
//  NVIC_Init(&NVIC_InitStructure); 

  
  /*����1 422*/
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_Init(&NVIC_InitStructure); 


  
  //IMU ���ݶ�ȡ�ж� TIM2  
  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn; 
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;   
  NVIC_Init(&NVIC_InitStructure); 
  
//  //usart3 
//  NVIC_InitStructure.NVIC_IRQChannel = USART3_422_IRQn; 
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
//  NVIC_Init(&NVIC_InitStructure); 


  
//  /*����2 485*/
//  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
//  NVIC_Init(&NVIC_InitStructure); 
//  
//   /*TIM3,IIC��ͨ���ж϶�ȡ*/
  NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_Init(&NVIC_InitStructure);  
//  
//  /*GPIO PB11�½����ж�*/
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
  NVIC_Init(&NVIC_InitStructure);  
//   /*����3 �����ͨ�� ����DMA*/
//  NVIC_InitStructure.NVIC_IRQChannel = DMA1_Stream1_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
//  NVIC_Init(&NVIC_InitStructure);   
  
  
  
  
}

void write_Rec_Data01_to_flash()
{
  FLASH_Unlock();
  FLASH_ClearFlag(FLASH_FLAG_EOP|FLASH_FLAG_OPERR|FLASH_FLAG_WRPERR|FLASH_FLAG_PGAERR|FLASH_FLAG_PGPERR|FLASH_FLAG_PGSERR);
  FLASH_EraseSector(FLASH_Sector_4,VoltageRange_3);
  FLASH_ProgramByte(UserParmentAddress, Rec_Data01);
  FLASH_Lock(); 
}


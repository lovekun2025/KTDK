#include "ShenHaiLan.h"


void shenhailan_cmd_send(void)
{
    while(USART_GetFlagStatus(USART3_422,USART_FLAG_TC)==RESET);
    USART_SendData(USART3_422,0X00);
    while(USART_GetFlagStatus(USART3_422,USART_FLAG_TC)==RESET);
     USART_SendData(USART3_422,0X04);
    while(USART_GetFlagStatus(USART3_422,USART_FLAG_TC)==RESET);
      USART_SendData(USART3_422,0X02);
    while(USART_GetFlagStatus(USART3_422,USART_FLAG_TC)==RESET);
      USART_SendData(USART3_422,0X06);
    while(USART_GetFlagStatus(USART3_422,USART_FLAG_TC)==RESET);
}
//�����ͨ��
int32_t ShenHaiLan_MagInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}

int32_t ShenHaiLan_MagFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}


int32_t ShenHaiLan_MagFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
    unsigned char checkSum = 0x00;
    int i;
    for (i=0;i<12;i++)
    {
            checkSum += pBuffer[i];
    }
    if (checkSum == pBuffer[12])
    {
            return FUNC_SUCCESS;
    }
    else
    {

            return FUNC_FAIL;
    }
   // return FUNC_OK;
}

int32_t ShenHaiLan_MagBuff[4];// X Y Z ������
extern unsigned short int iic_value[4]; 

int32_t ShenHaiLan_MagFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
     ShenHaiLan_MagBuff[0] = pBuffer[3]<<16 | pBuffer[4]<<8 | pBuffer[5];
     ShenHaiLan_MagBuff[1] = pBuffer[6]<<16 | pBuffer[7]<<8 | pBuffer[8]; 
     ShenHaiLan_MagBuff[2] =  pBuffer[9]<<16 | pBuffer[10]<<8 | pBuffer[11]; 

     if( ShenHaiLan_MagBuff[0]&0x800000){ShenHaiLan_MagBuff[0] = ShenHaiLan_MagBuff[0] - 0xffffff - 1;}
     if( ShenHaiLan_MagBuff[1]&0x800000){ShenHaiLan_MagBuff[1] = ShenHaiLan_MagBuff[1] - 0xffffff - 1;}
     if( ShenHaiLan_MagBuff[2]&0x800000){ShenHaiLan_MagBuff[2] = ShenHaiLan_MagBuff[2] - 0xffffff - 1;}
     ShenHaiLan_MagBuff[3] = 1;
      return 1;
}









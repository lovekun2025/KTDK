#ifndef __Gd32_Hardware_To_Ins_H
#define __Gd32_Hardware_To_Ins_H


void init_FrameParse(void);
void PrintUartMessage(unsigned int portId, char* string, int limit);
void Send_Data();

#endif





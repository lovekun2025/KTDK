/**
 * @file Config.c
 * @author Qiaoyy@xlnav.com
 * @version V1.0
 * @date 2018-06-28
 * @brief  ??????
 * Copyright (c) 2018 XiLang Co. Ltd.
 * All rights reserved.
 */
 
/* Includes ------------------------------------------------------------------*/
#include "Config.h"
#include "Signal.h"
#include "nav_interface.h"
/* Private typedef -----------------------------------------------------------*/
#define CONFIG_TABEL_FLASH_ADDRESS 0x080E0000   //����11

#define FLASH_MEMORY_LOWER_BOUNDARY 0x080E0000
#define FLASH_MEMORY_UPPER_BOUNDARY 0x080FFFFF
/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
ConfigTabelTypeDef g_ConfigTable;
extern uint32_t sendDataFre;
/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

/**
 * @brief  ��ȡȫ������
 * @param
 * @return
*/
ConfigTabelTypeDef* GetConfigTable(void)
{
	return &g_ConfigTable;
}

/**
 * @brief  ����ȫ������
 * @param
 * @return
*/
int LoadConfig(void)
{
	int result = FUNC_OK;
	
	result &= ReadConfigTable(&g_ConfigTable);
	result &= CheckConfigTable(&g_ConfigTable);
	
	if (result!=FUNC_OK)
	{
		InitConfigTable(&g_ConfigTable);
		SaveConfig();
		//printf("Can't read config, please reset!\n");
		// �˴�Ӧ�й��ϴ���
		return FUNC_ERROR;
	}	
	EnableSignalKey(&(GetGlobalSignalStatus()->flag_Config_loaded));
	return result;
}

/**
 * @brief  ��������
 * @param
 * @return
*/
int SaveConfig(void)
{
	int result;
	
	CalculateConfigTableCheckSum(&g_ConfigTable);
	
	result = CheckConfigTable(&g_ConfigTable);
	
	if(result==FUNC_OK)
	{
		result = WriteConfigTable(&g_ConfigTable);
	}

	return result;
}

void CalculateConfigTableCheckSum(ConfigTabelTypeDef* pConfig)
{
	int i;
	uint32_t check = 0x00000000;
	uint8_t* pointer = (uint8_t*)pConfig;
	for (i=0;i<sizeof(ConfigTabelTypeDef)-4;i++)
	{
		check += pointer[i];
	}
	pConfig->ulCrcCheck = check;
}

/**
 * @brief  ��ʼ�����ñ�
 * @param
 * @return 
*/
void InitConfigTable(ConfigTabelTypeDef* pConfig)
{
	uint8_t i;
	
//	memset(pConfig, 0x00, sizeof(ConfigTabelTypeDef));
	pConfig->ulMarker = CONFIG_TABLE_MARKER_CV24;
	
	for(i = 0;i < 3;i++)
	{
		pConfig->Gyro_Kg[i] = 0.0f;
		pConfig->Gyro_Kgn[i] = 0.0f;
		pConfig->Gyro_DF[i] = 0.0f;

		pConfig->Acc_Kap[i] = 0.0f;
		pConfig->Acc_k0[i] = 0.0f;

//		pConfig->Mag_Kap[i] = 100000.0f;
//		pConfig->Mag_k0[i] = 0.0f;
		pConfig->Mag_Kap_1[i] = 0.45;
		pConfig->Mag_k0_1[i] = 0.0;

		pConfig->Sat_ks[i] = 0.0f;
	}
		
	for(i = 0;i < 9;i++)
	{
		pConfig->Acc_k[i] = 0.0;
		pConfig->Gyro_E[i] = 0.0;
		pConfig->Gyro_En[i] = 0.0;
//		pConfig->Mag_k[i] = 0.0;
		pConfig->Mag_k_1[i] = 0.0;
	}
	
	pConfig->Mag_Kap[0] = 0.95134e5;
	pConfig->Mag_Kap[1] = 0.95214e5;
	pConfig->Mag_Kap[2] = 0.96161e5;
	pConfig->Mag_k[0] = 0.999301;
	pConfig->Mag_k[1] = -0.039845;
	pConfig->Mag_k[2] = -0.000777;
	pConfig->Mag_k[3] = 0.037431;
	pConfig->Mag_k[4] = 0.9992147;
	pConfig->Mag_k[5] = 0.0017329;
	pConfig->Mag_k[6] = 0.0012076;
	pConfig->Mag_k[7] = 0.0025205;
	pConfig->Mag_k[8] = 1.0;
	pConfig->Mag_k0[0] = -1323.10;
	pConfig->Mag_k0[1] = 769.5325;
	pConfig->Mag_k0[2] = 1877.730;
	
	pConfig->Mag_lamda = 116.0f;
	pConfig->Mag_B = 40.0f;
	pConfig->Mag_h = 100.0f;
	pConfig->Mag_Date = 2021.0f;
	pConfig->Mag_Dec = 0.0;
	pConfig->Mag_Inc = 0.0;
	pConfig->Mag_Str = 0.0;
	
    pConfig->MagDecl = 0.0f;
    pConfig->MagIncl = 0.0f;
	pConfig->ulFre = 10;
	pConfig->ulIsNavDataSend = 1;
	pConfig->ulIsImuDataSend = 1;
	pConfig->ulIsMagDataSend = 1;
	pConfig->ulIsOnlyNavData = 0;
	pConfig->ulUart1Baudrate = 115200;
	pConfig->ulFreNav = 10;
	pConfig->ulFreImu = 10;
	pConfig->ulFreMag = 10;
	pConfig->ulMagCalibStatus = 0;
	CalculateConfigTableCheckSum(pConfig);
}

void SetNavParameter()
{
	ConfigTabelTypeDef* pConfig;
	pConfig = GetConfigTable();
	NAVCTL* pNavCtl;	
	pNavCtl = getnavblk();

	int i;
	for(i=0;i<3;i++)
	{
		pNavCtl->gyrocalibration.Kg[i] = pConfig->Gyro_Kg[i];
		pNavCtl->gyrocalibration.Kgn[i] = pConfig->Gyro_Kgn[i];
		pNavCtl->gyrocalibration.DF[i] = pConfig->Gyro_DF[i];

		pNavCtl->acccalibration.Kap[i] = pConfig->Acc_Kap[i];
		pNavCtl->acccalibration.k0[i] = pConfig->Acc_k0[i];

		pNavCtl->magcalibration.Kap[i] = pConfig->Mag_Kap[i];
		pNavCtl->magcalibration.k0[i] = pConfig->Mag_k0[i];

		pNavCtl->magcalibration1.Kap[i] = pConfig->Mag_Kap_1[i];
		pNavCtl->magcalibration1.k0[i] = pConfig->Mag_k0_1[i];

		pNavCtl->satcalibration.ks[i] = pConfig->Sat_ks[i];
	}
		
	for(i=0;i<9;i++)
	{
		pNavCtl->acccalibration.k[i] =  pConfig->Acc_k[i];
		pNavCtl->gyrocalibration.E[i] = pConfig->Gyro_E[i];;
		pNavCtl->gyrocalibration.En[i] = pConfig->Gyro_En[i];
		pNavCtl->magcalibration.k[i] =  pConfig->Mag_k[i];
		pNavCtl->magcalibration1.k[i] =  pConfig->Mag_k_1[i];
	}

	pNavCtl->magcalibration.lamda = pConfig->Mag_lamda;
	pNavCtl->magcalibration.B = pConfig->Mag_B;
	pNavCtl->magcalibration.h = pConfig->Mag_h;
	pNavCtl->magcalibration.Date = pConfig->Mag_Date;
	if (pConfig->CalibrationFlag == 0xFFFFFFFF)
	{
		pNavCtl->CalibrationFlag = 1;
//        pNavCtl->cali_mag.flagmag = 2;
	}
	else
	{
		pNavCtl->CalibrationFlag = 0;
		EnableSignalKey(&(GetGlobalSignalStatus()->flag_CalibrationMode));
	}
        
	pNavCtl->cali_mag.MagDeclination = pConfig->MagDecl / NAV_RAD;
        pNavCtl->cali_mag.MagInclination = pConfig->MagIncl / NAV_RAD;
	sendDataFre = (uint32_t)(100 / pConfig->ulFre);
	if(pConfig->ulFreNav == 0 || pConfig->ulFreNav > 100)
	  pConfig->ulFreNav = 10;
	if(pConfig->ulFreImu == 0 || pConfig->ulFreImu > 100)
	  pConfig->ulFreImu = 10;
	if(pConfig->ulFreMag == 0 || pConfig->ulFreMag > 100)
	  pConfig->ulFreMag = 10;
}

/**
 * @brief
 * @param
 * @return 
*/

int SaveCalibrationResult()
{
  	int i;
	ConfigTabelTypeDef* pConfig;
	pConfig = GetConfigTable();
	NAVCTL* pNavCtl;	
	pNavCtl = getnavblk();

	if (pNavCtl->cali_mag.flagmag == 2)
	{
	  	pConfig->CalibrationFlag = 0xFFFFFFFF;
		
		for(i=0;i<3;i++)
			pConfig->Mag_Kap_1[i] = pNavCtl->cali_mag.Km2[i];
		for(i=0;i<9;i++)
			pConfig->Mag_k_1[i] = pNavCtl->cali_mag.Km2[i+3];
		for(i=0;i<3;i++)
			pConfig->Mag_k0_1[i] = pNavCtl->cali_mag.bm2[i];
		
		pConfig->Mag_Dec = pNavCtl->cali_mag.MagDeclination * NAV_RAD;
	    pConfig->Mag_Inc = pNavCtl->cali_mag.MagInclination * NAV_RAD;
	    pConfig->Mag_Str = pNavCtl->cali_mag.MagStrength;
		return 0;
	}
	else
	{
		return 2;
	}
}

/**
 * @brief  ������ñ�
 * @param
 * @return 
*/
int CheckConfigTable(ConfigTabelTypeDef* pConfig)
{
	int i;
	uint32_t tmp = 0x00U;
	uint8_t* pointer = (uint8_t*)pConfig;

	// ���ͷ��־
	if (pConfig->ulMarker != CONFIG_TABLE_MARKER_CV24)
	{
		return FUNC_ERROR;
	}
	
	// ���У���
	tmp = 0x00U;

	for (i=0;i<sizeof(ConfigTabelTypeDef)-4;i++)
	{
		tmp += pointer[i];
	}
	
	if (tmp != pConfig->ulCrcCheck)
	{
		return FUNC_ERROR;
	}
	return FUNC_OK;
}

FLASH_Status WriteFlash(uint32_t flashAddress, uint32_t* pBuffer, uint32_t bufferSize)
{
	int i;
	FLASH_Status status; 
	uint32_t pointer = flashAddress;
	
	if (flashAddress % 4 != 0 || flashAddress > FLASH_MEMORY_UPPER_BOUNDARY || flashAddress < FLASH_MEMORY_LOWER_BOUNDARY)
	{
		return FLASH_ERROR_RD;
	}
	FLASH_Unlock();

	for (i=0; i<bufferSize; i++)
	{
		status = FLASH_ProgramWord(pointer, pBuffer[i]);
		pointer += 4;
		if (status != FLASH_COMPLETE || pointer > FLASH_MEMORY_UPPER_BOUNDARY)
		{
			FLASH_Lock();
			return FLASH_ERROR_RD;
		}
	}
	FLASH_Lock();
	return FLASH_COMPLETE;
}

int WriteConfigTable(ConfigTabelTypeDef* pConfig)
{
	FLASH_Status status;
	
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);
	
	status = FLASH_EraseSector(FLASH_Sector_11, VoltageRange_3);
	
	if (status != FLASH_COMPLETE)
	{
	  	FLASH_Lock();
		return FUNC_ERROR;
	}

	status = WriteFlash(CONFIG_TABEL_FLASH_ADDRESS, (uint32_t*)pConfig, sizeof(ConfigTabelTypeDef)/sizeof(uint32_t));
	
	if (status == FLASH_COMPLETE)
	{
		return FUNC_OK;
	}
	else
	{
		return FUNC_ERROR;
	}
}

int ReadFlash(uint32_t flashAddress, uint32_t* pBuffer, uint32_t NumberToRead, uint32_t* NumberReaded)
{
	int i;
	uint32_t pointer = flashAddress;
	
	if (flashAddress % 4 != 0 || flashAddress > FLASH_MEMORY_UPPER_BOUNDARY || flashAddress < FLASH_MEMORY_LOWER_BOUNDARY)
	{
		return FUNC_ERROR;
	}
	
	*NumberReaded = 0;
	for (i=0; i<NumberToRead; i++)
	{
		pBuffer[i] = *(__IO uint32_t *)pointer;
		pointer += 4;
		(*NumberReaded)++;
		if (pointer > FLASH_MEMORY_UPPER_BOUNDARY)
		{
			return FUNC_ERROR;
		}
	}
	return FUNC_OK;
}

/**
 * @brief  
 * @param
 * @return 
*/
int ReadConfigTable(ConfigTabelTypeDef* pConfig)
{
	uint32_t numberReaded;
	int status;

	status = ReadFlash(CONFIG_TABEL_FLASH_ADDRESS, (uint32_t*)pConfig, sizeof(ConfigTabelTypeDef)/sizeof(uint32_t), &numberReaded);
	
	if (numberReaded == sizeof(ConfigTabelTypeDef)/sizeof(uint32_t) && status == FUNC_OK)
	{
		return FUNC_OK;
	}
	else
	{
		return FUNC_ERROR;
	}
}

/************************ (C) COPYRIGHT XiLang CO. Ltd. ****** END OF FILE ****/

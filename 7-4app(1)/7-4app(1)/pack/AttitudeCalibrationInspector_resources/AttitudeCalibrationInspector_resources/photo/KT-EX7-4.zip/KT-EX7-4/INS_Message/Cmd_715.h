#ifndef __CMD_715_H
#define __CMD_715_H
#include "Global.h"
#include "Config.h"

int32_t QSENS_AckInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_AckFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_AckFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_AckFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);







#endif
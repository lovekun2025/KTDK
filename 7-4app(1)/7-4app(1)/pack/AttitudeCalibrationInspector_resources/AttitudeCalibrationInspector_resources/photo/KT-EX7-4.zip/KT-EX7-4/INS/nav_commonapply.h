#ifndef _NAV_COMMONAPPLY_H_
#define _NAV_COMMONAPPLY_H_

#define CIRCLE_PI   3.14159265358
typedef struct _HEIGHTLOGIC HEIGHTLOGIC;
struct _HEIGHTLOGIC
{
	float Err_Level;
	float Err_Hi;			
	int Hi_counter;
	int Level_counter;
};

typedef struct _DO_HEIGHT DO_HEIGHT;
struct _DO_HEIGHT
{
	int counter;
	float ave[2];
	float hi[100];
	int Num;
	float Revise_h;
	char Stop;
	int Stop_Counter;
};


typedef struct _HEADINGFILTER HEADINGFILTER;
struct _HEADINGFILTER
{
	float delt_lamd;
	float delt_B;
	float dheading;
	float Dif_INS;
	float Dif_VEL;
	char state;
	int UNcnt;
};

typedef struct _COMMONAPPLY COMMONAPPLY;
struct _COMMONAPPLY
{
	DO_HEIGHT        do_height;	
	HEADINGFILTER    headingfilter;
	HEIGHTLOGIC      heightlogic;
	float           FOG_KS;
	float           FOG_THITA;
	float           FOG_GAMA;
	float           (*app_Cal_atan)(float y, float x);
	float           (*app_Cal_asin)(float x);
	int              (*Get_Hi_Filter)(COMMONAPPLY *com_apply);	
	int				 (*Get_Heading_Filter)(COMMONAPPLY *com_apply);
	int              (*Get_VelErr)(COMMONAPPLY *com_apply, float dr_v, float v1[3]);
	int              (*Get_Height_Logic)(COMMONAPPLY *com_apply);
	int              Redo_Counter;
	char			 FOG_UpdatFlg;//qi 190130
//	float           q[4];
	float ins_q[4];
	float ins_ksaig;
	float ins_thita;
	float ins_gama;
	float ins_omegaz;
	double          FOG_LAMD;
	double           FOG_B;
	double           FOG_HIGHT;
};

int navCommAppCreate(COMMONAPPLY *com_apply);
void navCommAppDelete(COMMONAPPLY *com_apply);

#endif

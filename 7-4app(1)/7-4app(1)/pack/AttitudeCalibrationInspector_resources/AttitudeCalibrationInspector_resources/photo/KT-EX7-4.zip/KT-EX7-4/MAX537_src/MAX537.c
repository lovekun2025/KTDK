#include "Includes.h"
#include "MAX537.h"

void MAX537_Write(uint8_t addr, uint8_t data)
{
  uint16_t wrData = 0;
  uint16_t rdData = 0;
  
  wrData = (0x4000 | (addr << 8)) | data;
  
  MAX537_Write_Read(wrData,&rdData);
}

void MAX537_Read(uint8_t addr,uint16_t *rdData)
{
  uint16_t wrData;
  uint16_t *rdDataPt = rdData;
  
  wrData = (0x0000 | (addr << 8));
 
  MAX537_Write_Read(wrData,rdDataPt); 

}



void Acce_init()
{
    GPIO_ResetBits(SPI_ACCEX_CS_PORT,SPI_ACCEX_CS_PIN);//0 
    while (SPI_I2S_GetFlagStatus(SPI_1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI_1, 0x2A7F);
    while (SPI_I2S_GetFlagStatus(SPI_1, SPI_I2S_FLAG_RXNE) == RESET);
    SPI_I2S_ReceiveData(SPI_1);
    GPIO_SetBits(SPI_ACCEX_CS_PORT,SPI_ACCEX_CS_PIN);//1
    
    GPIO_ResetBits(SPI_ACCEY_CS_PORT,SPI_ACCEY_CS_PIN);//0 
    while (SPI_I2S_GetFlagStatus(SPI_1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI_1, 0x2A7F);
    while (SPI_I2S_GetFlagStatus(SPI_1, SPI_I2S_FLAG_RXNE) == RESET);
    SPI_I2S_ReceiveData(SPI_1);       
    GPIO_SetBits(SPI_ACCEY_CS_PORT,SPI_ACCEY_CS_PIN);//1
    
    GPIO_ResetBits(SPI_ACCEZ_CS_PORT,SPI_ACCEZ_CS_PIN);//0
    while (SPI_I2S_GetFlagStatus(SPI_1, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(SPI_1, 0x2A7F);
    while (SPI_I2S_GetFlagStatus(SPI_1, SPI_I2S_FLAG_RXNE) == RESET);
    SPI_I2S_ReceiveData(SPI_1);
    GPIO_SetBits(SPI_ACCEZ_CS_PORT,SPI_ACCEZ_CS_PIN);//1 
    
}

  
  
  
  
  
uint8_t MAX537_Get_ready_Stauts(uint8_t DeviceNum)
{
  unsigned short int rdData;
  MAX537_CS_Set(DeviceNum, 0);
  MAX537_Read(MAX537_READY_STATUS_ADDR,&rdData); 
  MAX537_CS_Set(DeviceNum, 1);
  rdData = rdData&0x80;//ȡbit5��Ϊ1��������Ч    
  return rdData;
  
}
  
  



  
  
  
  
  
  
  
  
/**************************************
* ���� [IN] DeviceNum       : ���ݱ��
* ���� [OUT] gyroData       : �������
* ���� [OUT] temperatrueData: ����¶�
* ���� [OUT] gyroStatus     : ���״̬
***************************************/
void MAX537_Get_Data(uint8_t DeviceNum,float *accedata,float *temperatrueData)
{
  uint8_t readyTemp = 0;
  
  int16_t temp=0;
  int32_t acce=0;  
  int32_t gX24=0;
  unsigned short int Data_Rx[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    
  
  readyTemp = MAX537_Get_ready_Stauts(DeviceNum); 
  
   if(readyTemp==0x80)
   {  
      MAX537_CS_Set(DeviceNum, 0);
      MAX537_Read(0xFA,&Data_Rx[0]); 
      MAX537_Read(0x00,&Data_Rx[1]);  
      MAX537_Read(0x00,&Data_Rx[2]);        
      MAX537_CS_Set(DeviceNum, 1);      


      //�¶��ź�
      temp =(Data_Rx[0]&0xff) | (Data_Rx[1]&0xff00);
      
      if((temp & 0x8000) == 0)
      {
        temp = temp;//Ӧ�ó��Կ̶����ӣ�����
      }
      else
      {
        temp = -(~temp+1);
      }
      
      //�����ź�
      if((Data_Rx[2] & 0x80) == 0) //�жϷ���λ
      {
              acce=(((uint32_t)Data_Rx[2]&0xff)<<16) | ((Data_Rx[2]&0xff00)) | (Data_Rx[1]&0xff);  //����
      }
      else
      {
            gX24 = 0xFF000000 | (((uint32_t)Data_Rx[2]&0xff)<<16) | ((Data_Rx[2]&0xff00)) | (Data_Rx[1]&0xff); //������ǰ�油�����λ
            acce = -(~gX24+1);  //ת��Ϊ�з�������������ԭ����÷�������
      }

      temperatrueData[0] = (float)temp;
      temperatrueData[0] = 0.003118774072342 * temperatrueData[0] +  24.029098217047387;
      accedata[0] = (float)acce;
   } 
}

//void MGZ2067_Get_Data_withStatus(uint8_t DeviceNum,float *gyroData,float *temperatrueData,uint8_t *gyroStatus)
//{
//  uint8_t readyTemp = 0;
//  uint8_t gyroErroStatus = 0;
//  static uint32_t readyErroCnt = 0;
//  static uint32_t statusErroCnt = 0;
//  static uint32_t scaleErroCnt = 0;
//  int16_t temperatureTemp = 0;
//  int32_t gyroTemp = 0;
//  uint8_t statusTemp = 0;
//  
//  
//  readyTemp = MGZ2067_Get_ready_Stauts(DeviceNum); 
//  
//  delay_1us(MGZ2067_TWO_SPI_DELAY_US);
//  
//  if((readyTemp & MGZ2067_DATA_READY_BIT) == 0)
//  {
//    readyErroCnt ++;
//    if(readyErroCnt > MGZ2067_ERRO_CNT_MAX)
//      gyroErroStatus = gyroErroStatus | 0x01;
//  }
//  else
//  {
//    readyErroCnt = 0;
//    MGZ2067_Get_Gyro_T(DeviceNum,&gyroTemp,&temperatureTemp);
//    
//    //�����ݴ���501��/s����С��0��ʱ�򣬳���200�����ϣ����ж������쳣
//    if((abs(gyroTemp) > 8210000) || (gyroTemp == 0))
//    {
//      scaleErroCnt ++;
//      if(scaleErroCnt > MGZ2067_ERRO_CNT_MAX)
//      {
//        gyroErroStatus = gyroErroStatus | 0x02;
//      }
//    }
//    else
//    {
//      scaleErroCnt = 0;
//    }  
//  }
//  
//  statusTemp = MGZ2067_Get_Status(DeviceNum);
// 
//  if(((statusTemp & 0x08) == 0) || ((statusTemp & 0x80) == 0))
//  {
//    statusErroCnt++;
//    if(statusErroCnt > MGZ2067_ERRO_CNT_MAX)
//      gyroErroStatus = gyroErroStatus | 0x04;
//  }
//  else
//  {
//    statusErroCnt = 0;
//  }
//  
//  *gyroStatus = gyroErroStatus;
//  *temperatrueData = MGZ2067_TEMPERATURE_K * temperatureTemp +  MGZ2067_TEMPERATURE_B;
//  *gyroData = gyroTemp * 1.0;
//}

//void MGZ2067_Erro_Deal(uint8_t gyroErroStatus)
//{
//  static uint8_t gyroResetStatus = 0;
//  static uint32_t gyroErroTick = 0;
//  
//  uint8_t erroStatusTemp = gyroErroStatus;
//  
//  //��λ����
//  if((gyroResetStatus == 0) && (erroStatusTemp > 0))
//  {
//    gyroResetStatus = 1;
//    MGZ2067_Reset();    
//  }
//  
//  //���ָ��������ӳ�
//  if((gyroResetStatus == 1) && (erroStatusTemp == 0))
//  {
//    gyroResetStatus = 2;
//    gyroErroTick = getTicks();
//  }
//  
//  //��ʱ200ms  ����
//  if(gyroResetStatus == 2)
//  {
//    if((getTicks() - gyroErroTick) > 200)
//    {
//      gyroResetStatus = 0;
//    }         
//  }
//}
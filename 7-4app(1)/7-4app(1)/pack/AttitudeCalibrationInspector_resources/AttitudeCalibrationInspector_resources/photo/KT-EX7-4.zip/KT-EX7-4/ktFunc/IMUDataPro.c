/************************************************
1���Բɼ����imu���ݽ����˲����¶Ȳ��������ת���ȡ�

************************************************/
#ifndef  OS_MASTER_FILE
#include "includes.h"
#endif



/********************************************
1����׼����������ע�͵����õĿ飬���ǲ�Ҫ�ı����
2������˳��
IMUOriginalData ��17��Ԫ�أ������е�˳��
X���ݣ�Y���ݣ�Z���ݣ�                     0-2
X�ӱ���Y�ӱ���Z�ӱ���                     3-5
T121�¶ȣ����������¶ȣ��²�ʹ�õ��¶�     6
X�����¶ȣ�Y�����¶ȣ�Z�����¶�           7-9
X�ӱ��¶ȣ�Y�ӱ��¶ȣ�Z�ӱ��¶�           10-12
X���/�ţ�Y���/�ţ�Z���/��              13-15
��ѹ��                                   16
*************************************************/
void IMUDataComp(float *original_data, float *inertial_data)
{
  uint8_t i;
  float temp[3];                    
  float temp1=0;
  float temp2=0;
  float temp3=0; 
  
  for(i = 0 ; i < SENSOR_NUMBER ; i++)
  {
    *(inertial_data + i) = *(original_data + i);
  }            
    
  TemperatureSmooth_AveragePerSecond( *(inertial_data+6) ); //����old_temp
  
  *(inertial_data+6) = old_temp;    //����͵��¶ȡ���
  
  temp1 = old_temp;  
  temp2 = temp1*temp1;
  temp3 = temp2*temp1;   
  
  if(WenBuFlag == VALID)
  {
  /***************************************************************************������λ�¶�����*****************************************************************/
  /*Gx BiasOverTemp comp*/
    if (temp1<ParaGyro.Gyro_Temp1_X)
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D1_X1*temp1 + ParaGyro.GyroBias_D1_X0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp1_X)&&(temp1<ParaGyro.Gyro_Temp2_X))
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D2_X1*temp1 + ParaGyro.GyroBias_D2_X0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp2_X)&&(temp1<ParaGyro.Gyro_Temp3_X))
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D3_X1*temp1 + ParaGyro.GyroBias_D3_X0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp3_X)&&(temp1<ParaGyro.Gyro_Temp4_X))
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D4_X1*temp1 + ParaGyro.GyroBias_D4_X0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp4_X)&&(temp1<ParaGyro.Gyro_Temp5_X))
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D5_X1*temp1 + ParaGyro.GyroBias_D5_X0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp5_X)&&(temp1<ParaGyro.Gyro_Temp6_X))
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D6_X1*temp1 + ParaGyro.GyroBias_D6_X0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp6_X)&&(temp1<ParaGyro.Gyro_Temp7_X))
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D7_X1*temp1 + ParaGyro.GyroBias_D7_X0);
    }
    else if(temp1>=ParaGyro.Gyro_Temp7_X)
    {
      *(inertial_data + 0) = *(inertial_data + 0) - (ParaGyro.GyroBias_D8_X1*temp1 + ParaGyro.GyroBias_D8_X0);
    }
    
    /*Gy BiasOverTemp comp*/
    if (temp1<ParaGyro.Gyro_Temp1_Y)
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D1_Y1*temp1 + ParaGyro.GyroBias_D1_Y0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp1_Y)&&(temp1<ParaGyro.Gyro_Temp2_Y))
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D2_Y1*temp1 + ParaGyro.GyroBias_D2_Y0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp2_Y)&&(temp1<ParaGyro.Gyro_Temp3_Y))
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D3_Y1*temp1 + ParaGyro.GyroBias_D3_Y0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp3_Y)&&(temp1<ParaGyro.Gyro_Temp4_Y))
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D4_Y1*temp1 + ParaGyro.GyroBias_D4_Y0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp4_Y)&&(temp1<ParaGyro.Gyro_Temp5_Y))
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D5_Y1*temp1 + ParaGyro.GyroBias_D5_Y0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp5_Y)&&(temp1<ParaGyro.Gyro_Temp6_Y))
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D6_Y1*temp1 + ParaGyro.GyroBias_D6_Y0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp6_Y)&&(temp1<ParaGyro.Gyro_Temp7_Y))
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D7_Y1*temp1 + ParaGyro.GyroBias_D7_Y0);
    }
    else if(temp1>=ParaGyro.Gyro_Temp7_Y)
    {
      *(inertial_data + 1) = *(inertial_data + 1) - (ParaGyro.GyroBias_D8_Y1*temp1 + ParaGyro.GyroBias_D8_Y0);
    }
    
    /*Gz BiasOverTemp comp*/
    if (temp1<ParaGyro.Gyro_Temp1_Z)
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D1_Z1*temp1 + ParaGyro.GyroBias_D1_Z0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp1_Z)&&(temp1<ParaGyro.Gyro_Temp2_Z))
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D2_Z1*temp1 + ParaGyro.GyroBias_D2_Z0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp2_Z)&&(temp1<ParaGyro.Gyro_Temp3_Z))
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D3_Z1*temp1 + ParaGyro.GyroBias_D3_Z0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp3_Z)&&(temp1<ParaGyro.Gyro_Temp4_Z))
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D4_Z1*temp1 + ParaGyro.GyroBias_D4_Z0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp4_Z)&&(temp1<ParaGyro.Gyro_Temp5_Z))
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D5_Z1*temp1 + ParaGyro.GyroBias_D5_Z0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp5_Z)&&(temp1<ParaGyro.Gyro_Temp6_Z))
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D6_Z1*temp1 + ParaGyro.GyroBias_D6_Z0);
    }
    else if((temp1>=ParaGyro.Gyro_Temp6_Z)&&(temp1<ParaGyro.Gyro_Temp7_Z))
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D7_Z1*temp1 + ParaGyro.GyroBias_D7_Z0);
    }
    else if(temp1>=ParaGyro.Gyro_Temp7_Z)
    {
      *(inertial_data + 2) = *(inertial_data + 2) - (ParaGyro.GyroBias_D8_Z1*temp1 + ParaGyro.GyroBias_D8_Z0);
    }
    ////////////////////////////////**************���������λ�²�*/
    /*********************************************************************��һ�׼ӱ���λ�²�******************************************************************/
   /*Ay BiasOverTemp comp*/
    if(1 == ParaAcce.AcceTempCoef_X_Flag )
    {
      /*Ax BiasOverTemp comp*/
      if (temp1<ParaAcce.Acce_Temp1_X)
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D1_X1*temp1 + ParaAcce.AcceBias_D1_X0);
      }
      else if((temp1>=ParaAcce.Acce_Temp1_X)&&(temp1<ParaAcce.Acce_Temp2_X))
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D2_X1*temp1 + ParaAcce.AcceBias_D2_X0);
      }
      else if((temp1>=ParaAcce.Acce_Temp2_X)&&(temp1<ParaAcce.Acce_Temp3_X))
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D3_X1*temp1 + ParaAcce.AcceBias_D3_X0);
      }
      else if((temp1>=ParaAcce.Acce_Temp3_X)&&(temp1<ParaAcce.Acce_Temp4_X))
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D4_X1*temp1 + ParaAcce.AcceBias_D4_X0);
      }
      else if((temp1>=ParaAcce.Acce_Temp4_X)&&(temp1<ParaAcce.Acce_Temp5_X))
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D5_X1*temp1 + ParaAcce.AcceBias_D5_X0);
      }
      else if((temp1>=ParaAcce.Acce_Temp5_X)&&(temp1<ParaAcce.Acce_Temp6_X))
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D6_X1*temp1 + ParaAcce.AcceBias_D6_X0);
      }
      else if((temp1>=ParaAcce.Acce_Temp6_X)&&(temp1<ParaAcce.Acce_Temp7_X))
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D7_X1*temp1 + ParaAcce.AcceBias_D7_X0);
      }
      else if(temp1>=ParaAcce.Acce_Temp7_X)
      {
         *(inertial_data + 3) = *(inertial_data + 3) - (ParaAcce.AcceBias_D8_X1*temp1 + ParaAcce.AcceBias_D8_X0);
      }
    }
    /*Ay BiasOverTemp comp*/
    if(1 == ParaAcce.AcceTempCoef_Y_Flag )
    {
      if (temp1<ParaAcce.Acce_Temp1_Y)
      {
         *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D1_Y1*temp1 + ParaAcce.AcceBias_D1_Y0);
      }
      else if((temp1>=ParaAcce.Acce_Temp1_Y)&&(temp1<ParaAcce.Acce_Temp2_Y))
      {
         *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D2_Y1*temp1 + ParaAcce.AcceBias_D2_Y0);
      }
      else if((temp1>=ParaAcce.Acce_Temp2_Y)&&(temp1<ParaAcce.Acce_Temp3_Y))
      {
              *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D3_Y1*temp1 + ParaAcce.AcceBias_D3_Y0);
      }
      else if((temp1>=ParaAcce.Acce_Temp3_Y)&&(temp1<ParaAcce.Acce_Temp4_Y))
      {
              *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D4_Y1*temp1 + ParaAcce.AcceBias_D4_Y0);
      }
      else if((temp1>=ParaAcce.Acce_Temp4_Y)&&(temp1<ParaAcce.Acce_Temp5_Y))
      {
              *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D5_Y1*temp1 + ParaAcce.AcceBias_D5_Y0);
      }
      else if((temp1>=ParaAcce.Acce_Temp5_Y)&&(temp1<ParaAcce.Acce_Temp6_Y))
      {
              *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D6_Y1*temp1 + ParaAcce.AcceBias_D6_Y0);
      }
      else if((temp1>=ParaAcce.Acce_Temp6_Y)&&(temp1<ParaAcce.Acce_Temp7_Y))
      {
              *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D7_Y1*temp1 + ParaAcce.AcceBias_D7_Y0);
      }
      else if(temp1>=ParaAcce.Acce_Temp7_Y)
      {
              *(inertial_data + 4) = *(inertial_data + 4) - (ParaAcce.AcceBias_D8_Y1*temp1 + ParaAcce.AcceBias_D8_Y0);
      }
    }
         /*Az BiasOverTemp comp*/
    if(1 == ParaAcce.AcceTempCoef_Z_Flag)
    {
              
      if (temp1<ParaAcce.Acce_Temp1_Z)
      {
         *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D1_Z1*temp1 + ParaAcce.AcceBias_D1_Z0);
      }
      else if((temp1>=ParaAcce.Acce_Temp1_Z)&&(temp1<ParaAcce.Acce_Temp2_Z))
      {
         *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D2_Z1*temp1 + ParaAcce.AcceBias_D2_Z0);
      }
      else if((temp1>=ParaAcce.Acce_Temp2_Z)&&(temp1<ParaAcce.Acce_Temp3_Z))
      {
              *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D3_Z1*temp1 + ParaAcce.AcceBias_D3_Z0);
      }
      else if((temp1>=ParaAcce.Acce_Temp3_Z)&&(temp1<ParaAcce.Acce_Temp4_Z))
      {
              *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D4_Z1*temp1 + ParaAcce.AcceBias_D4_Z0);
      }
      else if((temp1>=ParaAcce.Acce_Temp4_Z)&&(temp1<ParaAcce.Acce_Temp5_Z))
      {
              *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D5_Z1*temp1 + ParaAcce.AcceBias_D5_Z0);
      }
      else if((temp1>=ParaAcce.Acce_Temp5_Z)&&(temp1<ParaAcce.Acce_Temp6_Z))
      {
              *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D6_Z1*temp1 + ParaAcce.AcceBias_D6_Z0);
      }
      else if((temp1>=ParaAcce.Acce_Temp6_Z)&&(temp1<ParaAcce.Acce_Temp7_Z))
      {
              *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D7_Z1*temp1 + ParaAcce.AcceBias_D7_Z0);
      }
      else if(temp1>=ParaAcce.Acce_Temp7_Z)
      {
              *(inertial_data + 5) = *(inertial_data + 5) - (ParaAcce.AcceBias_D8_Z1*temp1 + ParaAcce.AcceBias_D8_Z0);
      }
    }
       //���Ӵ����̵���λ�²�20220413
//      *(inertial_data+13) = *(inertial_data+13) - (ParaQJ.AcceTempCoef_X2*temp2 + ParaQJ.AcceTempCoef_X1*temp1);
//      *(inertial_data+14) = *(inertial_data+14) - (ParaQJ.AcceTempCoef_Y2*temp2 + ParaQJ.AcceTempCoef_Y1*temp1);
//      *(inertial_data+15) = *(inertial_data+15) - (ParaQJ.AcceTempCoef_Z2*temp2 + ParaQJ.AcceTempCoef_Z1*temp1); 
    
  
  }     /*�²����*/
  
  if(ReleaseFlag == VALID)
  {
    //******************************************************���� *******************************************//  
    //���ݱ�������¶�����
    Gyro_Calibration[0][1] = (ParaGyro.GyroSFOT_X3*temp3 + ParaGyro.GyroSFOT_X2*temp2 + ParaGyro.GyroSFOT_X1*temp1 + ParaGyro.GyroSFOT_X0);
    Gyro_Calibration[1][1] = (ParaGyro.GyroSFOT_Y3*temp3 + ParaGyro.GyroSFOT_Y2*temp2 + ParaGyro.GyroSFOT_Y1*temp1 + ParaGyro.GyroSFOT_Y0); 
    Gyro_Calibration[2][1] = (ParaGyro.GyroSFOT_Z3*temp3 + ParaGyro.GyroSFOT_Z2*temp2 + ParaGyro.GyroSFOT_Z1*temp1 + ParaGyro.GyroSFOT_Z0);
 
    // ���ݱ��ת��
    *(inertial_data+0) = ((*(inertial_data+0) - ParaGyro.GyroBias_X)/Gyro_Calibration[0][1]);
    *(inertial_data+1) = ((*(inertial_data+1) - ParaGyro.GyroBias_Y)/Gyro_Calibration[1][1]); 
    *(inertial_data+2) = ((*(inertial_data+2) - ParaGyro.GyroBias_Z)/Gyro_Calibration[2][1]); 

    //******************************************************�ӱ� *******************************************// 
     Acce_Calibration[0][1] = ParaAcce.AcceSFOT_X1*(temp1-ParaAcce.AcceNT_X) + ParaAcce.AcceSF_X;
     Acce_Calibration[1][1] = ParaAcce.AcceSFOT_Y1*(temp1-ParaAcce.AcceNT_Y) + ParaAcce.AcceSF_Y;
     Acce_Calibration[2][1] = ParaAcce.AcceSFOT_Z1*(temp1-ParaAcce.AcceNT_Z) + ParaAcce.AcceSF_Z;
    
    *(inertial_data+3) = ((*(inertial_data+3) - ParaAcce.AcceBias_X)/Acce_Calibration[0][1]);
    *(inertial_data+4) = ((*(inertial_data+4) - ParaAcce.AcceBias_Y)/Acce_Calibration[1][1]);
    *(inertial_data+5) = ((*(inertial_data+5) - ParaAcce.AcceBias_Z)/Acce_Calibration[2][1]);     
    
    //���ݰ�װ����
    /**/
    mat_vectn(3,3,temp,(inertial_data),Gyro_Disalignment);
    for(i=0;i<3;i++)
    {
     *(inertial_data+i)=temp[i];   
    }
    
    mat_vectn(3,3,temp,(inertial_data+3),Acce_Disalignment);    
    for(i=0;i<3;i++)
    {
    *(inertial_data+i+3)=temp[i];
    }  
       
  }/*������ת�����*/
  
   return;  
}

/**************************************************************************
* �¶�ƽ��������ǰ���벻ƽ������ֹ���ϵ�ʱ�¶���Ծ��ɵ���λƯ�ơ�
* 
***************************************************************************/
void TemperatureSmooth_AveragePerSecond(float currentTemperature)
{
    // �ȴ������У�ǰ���벻ƽ����
    if (First_Temp_Flag == 1)
    {
        old_temp = currentTemperature;
        Temp_Counter++;
        
        if ( Temp_Counter >= (ktFrequency[frameID].calFrequencyHz>>1) )
        {
            First_Temp_Flag = 0;
            Temp_Sum = 0;
            Temp_Counter = 0;
        }
    }
    else
    {
        Temp_Sum=Temp_Sum + currentTemperature;   
        Temp_Counter++;      
        
        if ( Temp_Counter>=ktFrequency[frameID].calFrequencyHz )
        {
            old_temp= Temp_Sum / ktFrequency[frameID].calFrequencyHz;
            Temp_Counter=0;
            Temp_Sum=0.0;  
        }
    }
}




/******************* (C) COPYRIGHT 2010 BEIJINGKAITUO*****END OF FILE****/

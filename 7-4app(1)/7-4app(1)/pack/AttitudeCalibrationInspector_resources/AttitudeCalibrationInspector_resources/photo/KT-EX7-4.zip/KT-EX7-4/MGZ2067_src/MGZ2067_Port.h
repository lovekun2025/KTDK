#ifndef __MGZ2067_PORT_H
#define __MGZ2067_PORT_H


/****************************************************************************** 
*��������  2067   320
* SPIʱ���Ƽ�����Mode3ʱ�����͡���CPOL=1��CPHA=1
* ���⣬��Ҫ��ʼ��EN�ܽţ�����ʼ�������
******************************************************************************/


/******  1 ѡ��Ӳ��ƽ̨���ӿ� ************************************************/
//#define MGZ2067_GD_F103_SPI
//#define MGZ2067_ST_F103_SPI
#define MGZ2067_GD_F405_SPI


/******  2 ȷ����������  ****************************************************/
#define MGZ2067_NUM    3

/******  3 �������϶��壬�޸��·���Ӧ��Ӳ�����ú궨�� ***********************/



/******************************************************************************
*  STM32F103��Ƭѡ�Ǻ궨��
******************************************************************************/
#ifdef MGZ2067_ST_F103_SPI


#define MGZ2067_ENABLE_PORT           GPIOA
#define MGZ2067_ENABLE_PIN            GPIO_PIN_12    

#define MGZ2067_CS1_PORT              GPIOA 
#define MGZ2067_CS1_PIN               GPIO_PIN_11

#define MGZ2067_CS2_PORT              GPIOA 
#define MGZ2067_CS2_PIN               GPIO_PIN_2

#define MGZ2067_CS3_PORT              GPIOA 
#define MGZ2067_CS3_PIN               GPIO_PIN_3

#define MGZ2067_SPI                   SPI0

typedef struct
{
    uint32_t csPort;
    uint32_t csPin;
}MGXXXXcsMap_s;

#endif


/******************************************************************************
*  GD32F103��Ƭѡ�Ǻ궨��
******************************************************************************/
#ifdef MGZ2067_GD_F103_SPI


#define MGZ2067_ENABLE_PORT           GPIOB
#define MGZ2067_ENABLE_PIN            GPIO_PIN_1  

#define MGZ2067_CS1_PORT              GPIOA 
#define MGZ2067_CS1_PIN               GPIO_PIN_0

#define MGZ2067_CS2_PORT              GPIOA 
#define MGZ2067_CS2_PIN               GPIO_PIN_1

#define MGZ2067_CS3_PORT              GPIOA 
#define MGZ2067_CS3_PIN               GPIO_PIN_3

#define MGZ2067_SPI                   SPI0

typedef struct
{
    uint32_t csPort;
    uint32_t csPin;
}MGXXXXcsMap_s;

#endif


/******************************************************************************
*  GD32F405��Ƭѡ�Ǻ궨��
******************************************************************************/
#ifdef MGZ2067_GD_F405_SPI


#define MGZ2067_ENABLE_PORT           GPIOA        //7-4��Ʒʹ��Ӳ��û��IO��
#define MGZ2067_ENABLE_PIN            GPIO_Pin_0 

#define MGZ2067_CS1_PORT              GPIOA 
#define MGZ2067_CS1_PIN               GPIO_Pin_4

#define MGZ2067_CS2_PORT              GPIOA
#define MGZ2067_CS2_PIN               GPIO_Pin_1

#define MGZ2067_CS3_PORT              GPIOC
#define MGZ2067_CS3_PIN               GPIO_Pin_3

#define MGZ2067_SPI                   SPI1


typedef struct
{
  GPIO_TypeDef *csPort;
  uint16_t csPin;  
}MGZ2067csMap_s;

#endif


void MGZ2067_CS_Set(uint8_t csNum, uint8_t ioStatus);
void MGZ2067_Write_Read(uint16_t wrData,uint16_t *rdData);

#endif


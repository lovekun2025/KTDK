#include "CommandFrame.h"
#include "Config.h"
#include "Signal.h"
#include "msg_QsensCmd.h"
#include "DatagramFrame.h"
#include "Includes.h"
#include "Gd32_Hardware_To_Ins.h"
/*--------------------------- Macro Define    ----------------------------*/
#define CMD_DISABLE				FUNC_DISABLE  // ȡ��������ʾ��Ϣ
#define CMD_ENABLE_NORMAL_SHOW  0x01  				// ʹ�ܣ���qshow������ʾ
#define CMD_ENABLE_TEST_SHOW    0x02  				// ʹ�ܣ���qtest������ʾ

#define CMD_MESSAGE_MAX_LENGTH 	128
/*--------------------------- Struct Define    ----------------------------*/
int qsave(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qcom(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qconfig(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qreset(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qshow(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qboot(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qbatch(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qGyroKg(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qGyroKgn(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qGyroDF(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qGyroE(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qGyroEn(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qAccKap(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qAcck0(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qAcck(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qMagKap(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qMagk0(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qMagk(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qSatks(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qcalib(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qloc(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qfre(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qsend(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qsn(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
int qfluxgate(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);  //��ͨ�ų��Ҳ�������
int qMagDecl(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);//���ô�ƫ��
int qMagIncl(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);//���ô����
int qsendFre(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);//����ÿ������֡��Ƶ��
int qmagCalib(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);//�����Ƿ���д�ͨ�ű궨����//������ʾnt����ԭʼ����
int qmag_iic_uart(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);//����ʹ��iic�����ƻ���uart������

int qfluxgateShow(ConfigTabelTypeDef* config, uint32_t nSource); //��ͨ�ų��Ҳ�����ʾ
int qcomShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qGyroKgShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qGyroKgnShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qGyroDFShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qGyroEShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qGyroEnShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qAccKapShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qAcck0Show(ConfigTabelTypeDef* config, uint32_t nSource);
int qAcckShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qMagKapShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qMagk0Show(ConfigTabelTypeDef* config, uint32_t nSource);
int qMagkShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qSatksShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qcalibShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qlocShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qfreShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qsendShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qsnShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qMagDeclShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qMagInclShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qsendFreShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qmagCalibShow(ConfigTabelTypeDef* config, uint32_t nSource);
int qmag_iic_uartShow(ConfigTabelTypeDef* config, uint32_t nSource);


/*--------------------------- Local Variable  ----------------------------*/
// ��������������
COMMAND_SETUP_BEGIN(cmdList)
	COMMAND_SET("#qconfig", qconfig, 0, CMD_ENABLE_NORMAL_SHOW)	// ��������ģʽ
	COMMAND_SET("#qboot", qboot, 0, CMD_ENABLE_NORMAL_SHOW)		// ����
	COMMAND_SET("#qsave", qsave, 0, CMD_ENABLE_NORMAL_SHOW) 		// ��������
	COMMAND_SET("#qshow", qshow, 0, CMD_ENABLE_NORMAL_SHOW)		// ��ѯ����
	COMMAND_SET("#qsn", qsn, qsnShow, CMD_ENABLE_NORMAL_SHOW)	// �豸���
	COMMAND_SET("#qcom", qcom, qcomShow, CMD_ENABLE_NORMAL_SHOW)			// ���ô���
	COMMAND_SET("#qmagCalib", qmagCalib, qmagCalibShow, CMD_ENABLE_NORMAL_SHOW)   //����ʹ��IIC����UART�Ĵ�ͨ��
	COMMAND_SET("#qmag_iic_uart", qmag_iic_uart, qmag_iic_uartShow, CMD_ENABLE_NORMAL_SHOW)   //����ʹ��IIC����UART�Ĵ�ͨ��
	COMMAND_SET("#qfre", qfre, qfreShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qsendFre", qsendFre, qsendFreShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qsend", qsend, qsendShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qGyroKg", qGyroKg, qGyroKgShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qGyroKgn", qGyroKgn, qGyroKgnShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qGyroDF", qGyroDF, qGyroDFShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qGyroE", qGyroE, qGyroEShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qGyroEn", qGyroEn, qGyroEnShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qAccKap", qAccKap, qAccKapShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qAcck0", qAcck0, qAcck0Show, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qAcck", qAcck, qAcckShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qMagKap", qMagKap, qMagKapShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qMagk0", qMagk0, qMagk0Show, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qMagk", qMagk, qMagkShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qSatks", qSatks, qSatksShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qloc", qloc, qlocShow, CMD_ENABLE_NORMAL_SHOW)
	COMMAND_SET("#qcalib", qcalib, qcalibShow, CMD_ENABLE_TEST_SHOW)    	// ��ʾ/����/����궨��
	COMMAND_SET("#qreset", qreset, 0, CMD_ENABLE_NORMAL_SHOW)		// �ָ���������
	COMMAND_SET("#qMagDecl", qMagDecl, qMagDeclShow, CMD_ENABLE_NORMAL_SHOW)
       COMMAND_SET("#qMagIncl", qMagIncl, qMagInclShow, CMD_ENABLE_NORMAL_SHOW)
COMMAND_SETUP_END

// ��ʾ�ַ���
char mismatchedParam[] = "#Mismatched Parameter\r\n";
char unknownParam[] = "#Unknown Parameter\r\n";
char successfulSet[] = "#OK\r\n";
char DebugData[] = __DATE__;
char DebugTime[] = __TIME__;
char SoftwareVersion[] = " KT-EX7-4 V1.03";
extern int isReceivedCommand ;
extern int navDataCouter;
static char strMessage[CMD_MESSAGE_MAX_LENGTH];
/*--------------------------- Local Prototype ----------------------------*/

//��ͨ��
//int32_t QSENS_MagInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
//{
//	return FUNC_OK;
//}
//
//int32_t QSENS_MagFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
//{
//	return FUNC_OK;
//}
//
//int32_t QSENS_MagFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
//{
//	return FUNC_OK;
//}
//
//extern int32_t MagBuff[5];// X Y Z �¶� ��Ч��־
//int32_t QSENS_MagFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
//{
//	char *p,*q,*val[10];
//	int n=0,i=0;
//
//	if(nLength > 50)
//		return FUNC_ERROR;
//	
//	/* parse fields */
//	for (p=(char*)(pBuffer+1); *p && n<10; p=q+1)//ÿ�ν��ָ����ĵ�ַ+1��ֵ��p
//	{
//		if (((q=strchr(p,',')) != NULL) || ((q=strchr(p,'\r')) != NULL))
//		{
//			val[n++]=p; *q='\0';
//        }
//		else break;
//	}
//	for(i=0; i<4; i++)
//	{
//		MagBuff[i] = atoi(val[i]);
//	}
//	MagBuff[4] = 1;
//	return FUNC_OK;
//}


//��������
int32_t QSENS_CmdInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	DisableAllCommand(cmdList, COMMAND_SETUP_NUMBER(cmdList));
	EnableCommand("#qconfig", cmdList, COMMAND_SETUP_NUMBER(cmdList));
	return FUNC_OK;
}

int32_t QSENS_CmdFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}

int32_t QSENS_CmdFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{
	return FUNC_OK;
}

int32_t QSENS_CmdFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource)
{

	ParseParam* pParse = (ParseParam*)nSource;
	pBuffer[nLength-2] = (unsigned char)('\0'); // �������һ������������ֽ�Ϊ \r\n
	CmdProcss((char*)pBuffer, cmdList, COMMAND_SETUP_NUMBER(cmdList), strMessage, pParse->PortId);
	PrintUartMessage(pParse->PortId, strMessage, CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qhelp(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	int i;
	int size = (sizeof(cmdList)/sizeof(CommandMap))-1;

	for(i=0; i < size; i++)
	{
		if(cmdList[i].VersionDefine == CMD_ENABLE_NORMAL_SHOW)
		{
			PrintUartMessage(nSource ,cmdList[i].CommandKey ,CMD_MESSAGE_MAX_LENGTH);
			PrintUartMessage(nSource ,"\r\n" ,CMD_MESSAGE_MAX_LENGTH);
		}
	}
	return FUNC_OK;
}

int qsave(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	int result;
	int resval;
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#Saving config, please wait...");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	if (argn == 1)
	{
		result = SaveConfig();
	}
	else if (argn == 2)
	{
		if (STRNCASECMP(argc[1], "calib", CMD_KEY_MAX_LEN) == 0)
		{
			resval = SaveCalibrationResult();
			if (resval == 0)
			{
				result = SaveConfig();
			}
			else if (resval == 1)
			{
				PrintUartMessage(nSource ,"Not in Calibration Mode!\r\n" ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
			else if (resval == 2)
			{
				PrintUartMessage(nSource ,"Calibration not finish!\r\n" ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
			else
			{
				PrintUartMessage(nSource ,"Calibration Failed!\r\n" ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	if (result==FUNC_OK)
	{
		snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH," done!\r\n");
	}
	else
	{
		snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH," failed!\r\n");
	}
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qcomShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qcom main %d\r\n", config->ulUart1Baudrate);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qcom(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	unsigned long temp;
	
	if(argn==1)
	{
		qcomShow(config, nSource);
	}
	else if(argn==3)
	{
		if (STRNCASECMP(argc[1], "MAIN", CMD_KEY_MAX_LEN) == 0)
		{
			temp = strtoul(argc[2], NULL, 10);
			if(IS_COM_BAUDRATE(temp))
			{
				config->ulUart1Baudrate = temp;
			}
			else
			{
				PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qconfig(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	EnableSignalKey(&(GetGlobalSignalStatus()->flag_config_mode));
	EnableAllCommand(cmdList, COMMAND_SETUP_NUMBER(cmdList));
	PrintUartMessage(nSource ,"#Config Mode\r\n" ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qreset(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	int result;
	ConfigTabelTypeDef* config;
	if(argn!=2)
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	if (STRNCASECMP(argc[1], "factory", CMD_KEY_MAX_LEN) == 0)
	{
		config = GetConfigTable();
		InitConfigTable(config);
		result = SaveConfig();
		if (result == FUNC_OK)
		{
			PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
		}
		else
		{
			PrintUartMessage(nSource ,"#Save Config Failed.\r\n" ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}
	}
	else
	{
		PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	return FUNC_OK;
}

int qshow(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	int i;
	ConfigTabelTypeDef* config;
	int size = (sizeof(cmdList)/sizeof(CommandMap))-1;

	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "\r\n#Firmware version: %s %s %s\r\n", DebugData, DebugTime, SoftwareVersion);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);

	if(argn==1)
	{
		config = GetConfigTable();
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	for(i=0; i < size; i++)
	{
		if(cmdList[i].ShowCallBack != 0 && cmdList[i].VersionDefine == CMD_ENABLE_NORMAL_SHOW)
		{
			cmdList[i].ShowCallBack(config, nSource);
		}
	}
		
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "======= End =======\r\n");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qboot(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "#Waiting for reboot......\r\n");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
  	NVIC_SystemReset();
	return FUNC_OK;
}

/**
 * @brief  ���õ�������
 * @param
 * @return 
*/
int qbatch(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	return FUNC_OK;
}

/**
 * @brief  
 * @param
 * @return 
*/

int qGyroKgShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qGyroKg %f %f %f\r\n", config->Gyro_Kg[0],config->Gyro_Kg[1],config->Gyro_Kg[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qGyroKg(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qGyroKgShow(config ,nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Gyro_Kg[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Gyro_Kg[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Gyro_Kg[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qGyroKgnShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qGyroKgn %f %f %f\r\n", config->Gyro_Kgn[0],config->Gyro_Kgn[1],config->Gyro_Kgn[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qGyroKgn(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qGyroKgnShow(config ,nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Gyro_Kgn[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Gyro_Kgn[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Gyro_Kgn[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qGyroDFShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qGyroDF %f %f %f\r\n", config->Gyro_DF[0],config->Gyro_DF[1],config->Gyro_DF[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qGyroDF(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qGyroDFShow(config, nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Gyro_DF[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Gyro_DF[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Gyro_DF[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qGyroEShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qGyroE %f %f %f %f %f %f %f %f %f\r\n", config->Gyro_E[0],config->Gyro_E[1],config->Gyro_E[2],config->Gyro_E[3],config->Gyro_E[4],config->Gyro_E[5],config->Gyro_E[6],config->Gyro_E[7],config->Gyro_E[8]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qGyroE(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qGyroEShow(config, nSource);
	}
	else if(argn == 10)
	{
		ftemp = strtof(argc[1], NULL);
		config->Gyro_E[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Gyro_E[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Gyro_E[2] = ftemp;
		
		ftemp = strtof(argc[4], NULL);
		config->Gyro_E[3] = ftemp;
		
		ftemp = strtof(argc[5], NULL);
		config->Gyro_E[4] = ftemp;
		
		ftemp = strtof(argc[6], NULL);
		config->Gyro_E[5] = ftemp;
		
		ftemp = strtof(argc[7], NULL);
		config->Gyro_E[6] = ftemp;
		
		ftemp = strtof(argc[8], NULL);
		config->Gyro_E[7] = ftemp;
		
		ftemp = strtof(argc[9], NULL);
		config->Gyro_E[8] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qGyroEnShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qGyroEn %f %f %f %f %f %f %f %f %f\r\n", config->Gyro_En[0],config->Gyro_En[1],config->Gyro_En[2],config->Gyro_En[3],config->Gyro_En[4],config->Gyro_En[5],config->Gyro_En[6],config->Gyro_En[7],config->Gyro_En[8]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qGyroEn(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qGyroEnShow(config, nSource);
	}
	else if(argn == 10)
	{
		ftemp = strtof(argc[1], NULL);
		config->Gyro_En[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Gyro_En[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Gyro_En[2] = ftemp;
		
		ftemp = strtof(argc[4], NULL);
		config->Gyro_En[3] = ftemp;
		
		ftemp = strtof(argc[5], NULL);
		config->Gyro_En[4] = ftemp;
		
		ftemp = strtof(argc[6], NULL);
		config->Gyro_En[5] = ftemp;
		
		ftemp = strtof(argc[7], NULL);
		config->Gyro_En[6] = ftemp;
		
		ftemp = strtof(argc[8], NULL);
		config->Gyro_En[7] = ftemp;
		
		ftemp = strtof(argc[9], NULL);
		config->Gyro_En[8] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qAccKapShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qAccKap %f %f %f\r\n", config->Acc_Kap[0],config->Acc_Kap[1],config->Acc_Kap[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qAccKap(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qAccKapShow(config, nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Acc_Kap[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Acc_Kap[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Acc_Kap[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qAcck0Show(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qAcck0 %f %f %f\r\n", config->Acc_k0[0],config->Acc_k0[1],config->Acc_k0[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qAcck0(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qAcck0Show(config, nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Acc_k0[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Acc_k0[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Acc_k0[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qAcckShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qAcck %f %f %f %f %f %f %f %f %f\r\n", config->Acc_k[0],config->Acc_k[1],config->Acc_k[2],config->Acc_k[3],config->Acc_k[4],config->Acc_k[5],config->Acc_k[6],config->Acc_k[7],config->Acc_k[8]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qAcck(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qAcckShow(config, nSource);
	}
	else if(argn == 10)
	{
		ftemp = strtof(argc[1], NULL);
		config->Acc_k[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Acc_k[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Acc_k[2] = ftemp;
		
		ftemp = strtof(argc[4], NULL);
		config->Acc_k[3] = ftemp;
		
		ftemp = strtof(argc[5], NULL);
		config->Acc_k[4] = ftemp;
		
		ftemp = strtof(argc[6], NULL);
		config->Acc_k[5] = ftemp;
		
		ftemp = strtof(argc[7], NULL);
		config->Acc_k[6] = ftemp;
		
		ftemp = strtof(argc[8], NULL);
		config->Acc_k[7] = ftemp;
		
		ftemp = strtof(argc[9], NULL);
		config->Acc_k[8] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qMagKapShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qMagKap %f %f %f\r\n", config->Mag_Kap[0],config->Mag_Kap[1],config->Mag_Kap[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qMagKap(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qMagKapShow(config, nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Mag_Kap[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Mag_Kap[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Mag_Kap[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qMagk0Show(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qMagk0 %f %f %f\r\n", config->Mag_k0[0],config->Mag_k0[1],config->Mag_k0[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qMagk0(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();

	if(argn == 1)
	{
		qMagk0Show(config, nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Mag_k0[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Mag_k0[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Mag_k0[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qMagkShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qMagk %f %f %f %f %f %f %f %f %f\r\n", config->Mag_k[0],config->Mag_k[1],config->Mag_k[2],config->Mag_k[3],config->Mag_k[4],config->Mag_k[5],config->Mag_k[6],config->Mag_k[7],config->Mag_k[8]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qMagk(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qMagkShow(config, nSource);
	}
	else if(argn == 10)
	{
		ftemp = strtof(argc[1], NULL);
		config->Mag_k[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Mag_k[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Mag_k[2] = ftemp;
		
		ftemp = strtof(argc[4], NULL);
		config->Mag_k[3] = ftemp;
		
		ftemp = strtof(argc[5], NULL);
		config->Mag_k[4] = ftemp;
		
		ftemp = strtof(argc[6], NULL);
		config->Mag_k[5] = ftemp;
		
		ftemp = strtof(argc[7], NULL);
		config->Mag_k[6] = ftemp;
		
		ftemp = strtof(argc[8], NULL);
		config->Mag_k[7] = ftemp;
		
		ftemp = strtof(argc[9], NULL);
		config->Mag_k[8] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}

int qfluxgateShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qfluxgate %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\r\n", \
                 config->fluxgate[0],config->fluxgate[1],config->fluxgate[2],config->fluxgate[3],config->fluxgate[4],config->fluxgate[5],config->fluxgate[6],config->fluxgate[7],config->fluxgate[8],config->fluxgate[9],config->fluxgate[10],config->fluxgate[11],config->fluxgate[12],config->fluxgate[13],config->fluxgate[14]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qfluxgate(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qfluxgateShow(config, nSource);
	}
	else if(argn == 16)
	{
		ftemp = strtof(argc[1], NULL);
		config->fluxgate[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->fluxgate[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->fluxgate[2] = ftemp;
		
		ftemp = strtof(argc[4], NULL);
		config->fluxgate[3] = ftemp;
		
		ftemp = strtof(argc[5], NULL);
		config->fluxgate[4] = ftemp;
		
		ftemp = strtof(argc[6], NULL);
		config->fluxgate[5] = ftemp;
		
		ftemp = strtof(argc[7], NULL);
		config->fluxgate[6] = ftemp;
		
		ftemp = strtof(argc[8], NULL);
		config->fluxgate[7] = ftemp;
		
		ftemp = strtof(argc[9], NULL);
		config->fluxgate[8] = ftemp;

                ftemp = strtof(argc[10], NULL);
		config->fluxgate[9] = ftemp;
                
                 ftemp = strtof(argc[11], NULL);
		config->fluxgate[10] = ftemp;
                
                ftemp = strtof(argc[12], NULL);
		config->fluxgate[11] = ftemp;
                
                ftemp = strtof(argc[13], NULL);
		config->fluxgate[12] = ftemp;
                
                ftemp = strtof(argc[14], NULL);
		config->fluxgate[13] = ftemp;
                
                ftemp = strtof(argc[15], NULL);
		config->fluxgate[14] = ftemp;
                

                
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}
int qSatksShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qSatks %f %f %f\r\n", config->Sat_ks[0],config->Sat_ks[1],config->Sat_ks[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qSatks(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qSatksShow(config, nSource);
	}
	else if(argn == 4)
	{
		ftemp = strtof(argc[1], NULL);
		config->Sat_ks[0] = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Sat_ks[1] = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Sat_ks[2] = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	
	return FUNC_OK;
}
/**
* @brief ��ӡ�궨����
*/
int qcalibShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "Calibration: %s\r\nMag_Dec: %f\r\nMag_Inc: %f\r\nMag_Str: %f\r\n", 	
			(config->CalibrationFlag == 0x00000000)? "NONE":"DONE",	config->Mag_Dec, config->Mag_Inc, config->Mag_Str);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "Mag_Kap_1[0]: %f\r\nMag_Kap_1[1]: %f\r\nMag_Kap_1[2]: %f\r\n", 	
			config->Mag_Kap_1[0], config->Mag_Kap_1[1], config->Mag_Kap_1[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "Mag_k0_1[0]: %f\r\nMag_k0_1[1]: %f\r\nMag_k0_1[2]: %f\r\n", 	
			config->Mag_k0_1[0], config->Mag_k0_1[1], config->Mag_k0_1[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH, "Mag_k_1[0]: %f\r\nMag_k_1[1]: %f\r\nMag_k_1[2]: %f\r\n", 	
			config->Mag_k_1[0], config->Mag_k_1[1], config->Mag_k_1[2]);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	
	return FUNC_OK;
}

/**
 * @brief  ��ʾ/����/����궨��
 *         #qcalib - ��ʾ�궨��
 *         #qcalib clear - ����궨��
 * 		   #qcalib [p1] [p2]
 * @param
 * @return 
*/
int qcalib(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* pConfig;
	pConfig = GetConfigTable();
	float ftemp;
	int resval;
	int i;
	if (argn == 1)
	{
		qcalibShow(pConfig, nSource);
	}
	else if(argn==2)
	{
		if (STRNCASECMP(argc[1], "clear", CMD_KEY_MAX_LEN) == 0)
		{
			// ����궨�� #qcalib clear
			pConfig->CalibrationFlag = 0x00000000;
			pConfig->Mag_Dec = 0.0f;
			pConfig->Mag_Inc = 0.0f;
			pConfig->Mag_Str = 0.0f;
			for(i=0; i<3; i++)
			{
				pConfig->Mag_Kap_1[i] = 0.45f;
				pConfig->Mag_k0_1[i] = 0.0f;
			}
			for(i=0; i<9; i++)
			{
				pConfig->Mag_k_1[i] = 0.0f;
			}
		}
		else if (STRNCASECMP(argc[1], "assign", CMD_KEY_MAX_LEN) == 0)
		{
			// ����ʹ���� #qcalib assign
			resval = SaveCalibrationResult();
			if (resval == 0)
			{
				qcalibShow(pConfig, nSource);
			}
			else if (resval == 1)
			{
				PrintUartMessage(nSource ,"Not in Calibration Mode!\r\n" ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
			else if (resval == 2)
			{
				PrintUartMessage(nSource ,"Calibration not finish!\r\n" ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
			else
			{
				PrintUartMessage(nSource ,"Calibration Failed!\r\n" ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}		
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else if(argn==3)
	{
		// �Ӳ�����ȡ����ĵı궨��
		if (STRNCASECMP(argc[1], "Mag_Dec", CMD_KEY_MAX_LEN) == 0)
		{
		  	ftemp = strtof(argc[2], NULL);
			pConfig->Mag_Dec = ftemp;
		}
		else if (STRNCASECMP(argc[1], "Mag_Inc", CMD_KEY_MAX_LEN) == 0)
		{
			ftemp = strtof(argc[2], NULL);
			pConfig->Mag_Inc = ftemp;
		}
		else if (STRNCASECMP(argc[1], "Mag_Str", CMD_KEY_MAX_LEN) == 0)
		{
			ftemp = strtof(argc[2], NULL);
			pConfig->Mag_Str = ftemp;
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		pConfig->CalibrationFlag = 0xFFFFFFFF;
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else if(argn==5)
	{
		// �Ӳ�����ȡ����ĵı궨��
		if (STRNCASECMP(argc[1], "Mag_Kap_1", CMD_KEY_MAX_LEN) == 0)
		{
		  	for(i=0; i<3; i++)
			{
				ftemp = strtof(argc[i+2], NULL);
				pConfig->Mag_Kap_1[i] = ftemp;
			}
		}
		else if (STRNCASECMP(argc[1], "Mag_k0_1", CMD_KEY_MAX_LEN) == 0)
		{
			for(i=0; i<3; i++)
			{
				ftemp = strtof(argc[i+2], NULL);
				pConfig->Mag_k0_1[i] = ftemp;
			}
		}
		else if (STRNCASECMP(argc[1], "Mag_k_1", CMD_KEY_MAX_LEN) == 0)
		{
			for(i=0; i<3; i++)
			{
				ftemp = strtof(argc[i+2], NULL);
				pConfig->Mag_k_1[i] = ftemp;
			}
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		pConfig->CalibrationFlag = 0xFFFFFFFF;
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	return FUNC_OK;
}

int qlocShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qloc %f %f %f %f\r\n", config->Mag_lamda,config->Mag_B,config->Mag_h,config->Mag_Date);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qloc(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	float ftemp;
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qlocShow(config, nSource);
	}
	else if(argn == 5)
	{
		ftemp = strtof(argc[1], NULL);
		config->Mag_lamda = ftemp;
		
		ftemp = strtof(argc[2], NULL);
		config->Mag_B = ftemp;
		
		ftemp = strtof(argc[3], NULL);
		config->Mag_h = ftemp;
		
		ftemp = strtof(argc[4], NULL);
		config->Mag_Date = ftemp;

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qfreShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qfre %d\r\n", config->ulFre);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qfre(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
		qfreShow(config, nSource);
	}
	else if(argn == 2)
	{
		if (STRNCASECMP(argc[1], "1", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 1;
		}
		else if (STRNCASECMP(argc[1], "2", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 2;
		}
		else if (STRNCASECMP(argc[1], "5", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 5;
		}
		else if (STRNCASECMP(argc[1], "10", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 10;
		}
		else if (STRNCASECMP(argc[1], "20", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 20;
		}
		else if (STRNCASECMP(argc[1], "50", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 50;
		}
		else if (STRNCASECMP(argc[1], "100", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFre = 100;
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qsendFreShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsendFre nav %d\r\n", config->ulFreNav);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsendFre imu %d\r\n", config->ulFreImu);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsendFre mag %d\r\n", config->ulFreMag);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qsendFre(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	uint32_t temp;
	
	if(argn == 1)
	{
		qsendFreShow(config, nSource);
	}
	else if(argn == 3)
	{
		temp = strtoul(argc[2], NULL, 10);
		if(temp == 0 || temp > 100)
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		if (STRNCASECMP(argc[1], "nav", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFreNav = temp;
		}
		else if (STRNCASECMP(argc[1], "imu", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFreImu = temp;
		}
		else if (STRNCASECMP(argc[1], "mag", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulFreMag = temp;
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qsendShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsend nav %s\r\n", (config->ulIsNavDataSend == 0x00000001)? "ON":"OFF");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsend imu %s\r\n", (config->ulIsImuDataSend == 0x00000001)? "ON":"OFF");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	
	snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsend mag %s\r\n", (config->ulIsMagDataSend == 0x00000001)? "ON":"OFF");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qsend(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();

    if(argn==1)
	{
		qsendShow(config, nSource);
	}
	else if(argn == 3)
	{
		if (STRNCASECMP(argc[1], "nav", CMD_KEY_MAX_LEN) == 0)
		{
			if (STRNCASECMP(argc[2], "on", CMD_KEY_MAX_LEN) == 0)
			{
				config->ulIsNavDataSend = 1;
			}
			else if (STRNCASECMP(argc[2], "off", CMD_KEY_MAX_LEN) == 0)
			{
				config->ulIsNavDataSend = 0;
			}
			else
			{
				PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
		}
		else if (STRNCASECMP(argc[1], "imu", CMD_KEY_MAX_LEN) == 0)
		{
			if (STRNCASECMP(argc[2], "on", CMD_KEY_MAX_LEN) == 0)
			{
				config->ulIsImuDataSend = 1;
			}
			else if (STRNCASECMP(argc[2], "off", CMD_KEY_MAX_LEN) == 0)
			{
				config->ulIsImuDataSend = 0;
			}
			else
			{
				PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
		}
		else if (STRNCASECMP(argc[1], "mag", CMD_KEY_MAX_LEN) == 0)
		{
			if (STRNCASECMP(argc[2], "on", CMD_KEY_MAX_LEN) == 0)
			{
				config->ulIsMagDataSend = 1;
			}
			else if (STRNCASECMP(argc[2], "off", CMD_KEY_MAX_LEN) == 0)
			{
				config->ulIsMagDataSend = 0;
			}
			else
			{
				PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
				return FUNC_ERROR;
			}
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}
	return FUNC_OK;
}

int qsnShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qsn %02d %03d\r\n", config->ulSerialNumber1, config->ulSerialNumber2);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qsn(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	unsigned long temp1;
	unsigned long temp2;
	
	if(argn == 1)
	{
		qsnShow(config, nSource);
	}
	else if(argn == 3)
	{
		temp1 = strtoul(argc[1], NULL, 10);
		temp2 = strtoul(argc[2], NULL, 10);
		if(IS_SERIAL_NUMBER1(temp1) && IS_SERIAL_NUMBER2(temp2))
		{
			config->ulSerialNumber1 = temp1;
			config->ulSerialNumber2 = temp2;
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qMagDeclShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qMagDecl %f\r\n", config->MagDecl);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qMagDecl(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
              qMagDeclShow(config, nSource);
	}
	else if(argn == 2)
	{
                config->MagDecl = strtof(argc[1], NULL);
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qMagInclShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qMagIncl %f\r\n", config->MagIncl);
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}

int qMagIncl(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();
	
	if(argn == 1)
	{
              qMagInclShow(config, nSource);
	}
	else if(argn == 2)
	{
                config->MagIncl = strtof(argc[1], NULL);
		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qmagCalibShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qmagCalib %s\r\n", (config->ulMagCalibStatus == 0x00000001)? "ON":"OFF");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}


int qmag_iic_uartShow(ConfigTabelTypeDef* config, uint32_t nSource)
{
    snprintf(strMessage, CMD_MESSAGE_MAX_LENGTH,"#qmag_iic_uart %s\r\n", (config->ulMag_iic_uart == 0x00000001)? "ON":"OFF");
	PrintUartMessage(nSource ,strMessage ,CMD_MESSAGE_MAX_LENGTH);
	return FUNC_OK;
}


int qmagCalib(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();

	if(argn == 1)
	{
		qmagCalibShow(config, nSource);
	}
	else if(argn == 2)
	{
		if (STRNCASECMP(argc[1], "on", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulMagCalibStatus = 1;
		}
		else if (STRNCASECMP(argc[1], "off", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulMagCalibStatus = 0;
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}

int qmag_iic_uart(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource)
{
	ConfigTabelTypeDef* config;
	config = GetConfigTable();

	if(argn == 1)
	{
		qmagCalibShow(config, nSource);
	}
	else if(argn == 2)
	{
		if (STRNCASECMP(argc[1], "on", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulMag_iic_uart= 1;
		}
		else if (STRNCASECMP(argc[1], "off", CMD_KEY_MAX_LEN) == 0)
		{
			config->ulMag_iic_uart = 0;
		}
		else
		{
			PrintUartMessage(nSource ,unknownParam ,CMD_MESSAGE_MAX_LENGTH);
			return FUNC_ERROR;
		}

		PrintUartMessage(nSource ,successfulSet ,CMD_MESSAGE_MAX_LENGTH);
	}
	else
	{
		PrintUartMessage(nSource ,mismatchedParam ,CMD_MESSAGE_MAX_LENGTH);
		return FUNC_ERROR;
	}

	return FUNC_OK;
}









//�ж��Ƿ�֧��715�����ʶ��ͽ���
int QSENS_BinInit(unsigned char* pBuffer, int nLength, uint32_t nSource)
{
    return FUNC_OK;
}

int QSENS_BinFrameLength(unsigned char* pBuffer, int nLength, uint32_t nSource)
{
	unsigned short nFrameLength = 0x00;
	memcpy(&nFrameLength, &pBuffer[4], 2);
	return nFrameLength+3;
}

int QSENS_BinFrameCheck(unsigned char* pBuffer, int nLength, uint32_t nSource)
{
    int i;
    unsigned char crc = 0x00;
	for (i=2;i<nLength-1;i++)
	{
		crc += pBuffer[i];
	}
	if (crc==pBuffer[nLength-1])
	{
		return FUNC_SUCCESS;
	}
	else
	{
		return FUNC_FAIL;
	}
}

int QSENS_BinFrameParse(unsigned char* pBuffer, int nLength, uint32_t nSource)
{
    unsigned short FrameID;
    ParseParam* pParse = (ParseParam*)nSource;
    memcpy(&FrameID, &pBuffer[2], 2);
	char closeByte[7] = {0xEA,0x51,0x03,0x03,0x04,0x00,0x0A};
	char openByte[7] = {0xEA,0x51,0x04,0x04,0x04,0x00,0x0C};
	switch (FrameID)
    {
		case 0x0101:
			isReceivedCommand = 0;
			PrintUartMessage(pParse->PortId ,closeByte ,CMD_MESSAGE_MAX_LENGTH);
			break;
		case 0x0202:
			isReceivedCommand = 1;
			PrintUartMessage(pParse->PortId ,openByte ,CMD_MESSAGE_MAX_LENGTH);
			break;
		default:
			break;
	}
	return FUNC_OK;
}


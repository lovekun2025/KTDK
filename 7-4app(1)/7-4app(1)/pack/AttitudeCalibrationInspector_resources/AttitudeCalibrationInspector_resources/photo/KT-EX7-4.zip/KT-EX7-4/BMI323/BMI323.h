#ifndef __BMI323_H
#define __BMI323_H

#include "BMI323_port.h"
#define BMI323_Dummy                0X00    
#define CHIP_ID                     0X00
//���ƼĴ���
#define ACCE_CONF                   0X20    
#define GYRO_CONF                   0X21
//״̬�Ĵ���
#define ERR_REG                     0X01
#define STATUS                      0X02
//���ݼĴ���
#define ACCE_DATA_X                 0X03
#define ACCE_DATA_Y                 0X04
#define ACCE_DATA_Z                 0X05
#define GYRO_DATA_X                 0X06
#define GYRO_DATA_Y                 0X07
#define GYRO_DATA_Z                 0X08
#define TEMP_DATA                   0X09
//���ݱ��ת��
#define BMI323Range2000_Scale        0.06103515625
#define BMI323Range1000_Scale        0.030517578125
#define BMI323Range500_Scale        0.0152587890625
#define BMI323Range250_Scale       0.00762939453125
#define BMI323Range125_Scale       0.003814697265625


typedef enum
{
  BMI323_ACCE_ODR_12          = 0x05,
  BMI323_ACCE_ODR_25          = 0x06,
  BMI323_ACCE_ODR_50          = 0x07,
  BMI323_ACCE_ODR_100         = 0x08,
  BMI323_ACCE_ODR_200         = 0x09,
  BMI323_ACCE_ODR_400         = 0x0A,
  BMI323_ACCE_ODR_800         = 0x0B,
  BMI323_ACCE_ODR_1600        = 0x0C,
  BMI323_ACCE_ODR_3200        = 0x0D,
  BMI323_ACCE_ODR_6400        = 0x0E
}BMI323_ACCE_ODR_TypeDef;

typedef enum
{
  BMI323_ACCE_RANGE_2         = 0x00,
  BMI323_ACCE_RANGE_4         = 0x10,
  BMI323_ACCE_RANGE_8         = 0x20,
  BMI323_ACCE_RANGE_16        = 0x30,
}BMI323_ACCE_RANGE_TypeDef;  

typedef enum
{
  BMI323_ACCE_BW_DIV2         = 0x00,
  BMI323_ACCE_BW_DIV4         = 0x80,
}BMI323_ACCE_BW_DIV_TypeDef;  

typedef enum
{
  BMI323_ACCE_AVER_DIV0          = 0x0000,
  BMI323_ACCE_AVER_DIV2          = 0x0100,
  BMI323_ACCE_AVER_DIV4          = 0x0200,
  BMI323_ACCE_AVER_DIV8          = 0x0300,
  BMI323_ACCE_AVER_DIV16         = 0x0400,
  BMI323_ACCE_AVER_DIV32         = 0x0500,
  BMI323_ACCE_AVER_DIV64         = 0x0600
}BMI323_ACCE_AVER_DIV_TypeDef;  


typedef enum
{
  BMI323_ACCE_MODE_DIS          = 0x0000,
  BMI323_ACCE_MODE_LOW          = 0x3000,
  BMI323_ACCE_MODE_NOR          = 0x4000,
  BMI323_ACCE_MODE_PER          = 0x7000,
}BMI323_ACCE_MODE_TypeDef; 


typedef enum
{
  BMI323_GYRO_ODR_12          = 0x05,
  BMI323_GYRO_ODR_25          = 0x06,
  BMI323_GYRO_ODR_50          = 0x07,
  BMI323_GYRO_ODR_100         = 0x08,
  BMI323_GYRO_ODR_200         = 0x09,
  BMI323_GYRO_ODR_400         = 0x0A,
  BMI323_GYRO_ODR_800         = 0x0B,
  BMI323_GYRO_ODR_1600        = 0x0C,
  BMI323_GYRO_ODR_3200        = 0x0D,
  BMI323_GYRO_ODR_6400        = 0x0E
}BMI323_GYRO_ODR_TypeDef;

typedef enum
{
  BMI323_GYRO_RANGE_125         = 0x00,
  BMI323_GYRO_RANGE_250         = 0x10,
  BMI323_GYRO_RANGE_500         = 0x20,
  BMI323_GYRO_RANGE_1000        = 0x30,
  BMI323_GYRO_RANGE_2000        = 0x40,
}BMI323_GYRO_RANGE_TypeDef;  

typedef enum
{
  BMI323_GYRO_BW_DIV2         = 0x00,
  BMI323_GYRO_BW_DIV4         = 0x80,
}BMI323_GYRO_BW_DIV_TypeDef;  

typedef enum
{
  BMI323_GYRO_AVER_DIV0          = 0x0000,
  BMI323_GYRO_AVER_DIV2          = 0x0100,
  BMI323_GYRO_AVER_DIV4          = 0x0200,
  BMI323_GYRO_AVER_DIV8          = 0x0300,
  BMI323_GYRO_AVER_DIV16         = 0x0400,
  BMI323_GYRO_AVER_DIV32         = 0x0500,
  BMI323_GYRO_AVER_DIV64         = 0x0600
}BMI323_GYRO_AVER_DIV_TypeDef;  


typedef enum
{
  BMI323_GYRO_MODE_DIS          = 0x0000,
  BMI323_GYRO_MODE_LOW          = 0x3000,
  BMI323_GYRO_MODE_NOR          = 0x4000,
  BMI323_GYRO_MODE_PER          = 0x7000,
}BMI323_GYRO_MODE_TypeDef; 


typedef struct
{
  BMI323_ACCE_ODR_TypeDef ACCE_ODR;
  BMI323_ACCE_RANGE_TypeDef ACCE_RANGE;
  BMI323_ACCE_BW_DIV_TypeDef ACCE_BW_DIV;
  BMI323_ACCE_AVER_DIV_TypeDef ACCE_AVER_DIV;
  BMI323_ACCE_MODE_TypeDef ACCE_MODE;
  
  BMI323_GYRO_ODR_TypeDef GYRO_ODR;
  BMI323_GYRO_RANGE_TypeDef GYRO_RANGE;
  BMI323_GYRO_BW_DIV_TypeDef GYRO_BW_DIV;
  BMI323_GYRO_AVER_DIV_TypeDef GYRO_AVER_DIV;
  BMI323_GYRO_MODE_TypeDef GYRO_MODE;

}BMI323_InitTypeDef;

void BMI323_Config_init(void);
/********************************BASE***********************************/
void BMI323_Write(uint8_t addr, uint16_t data);
uint16_t BMI323_Read(uint8_t addr);
void BMI323_MultiRead(uint8_t addr, uint16_t rdData[2]);
uint8_t BMI323_Get_CHIP_ID(uint8_t DeviceNum);
uint8_t BMI323_Get_ERR_REG(uint8_t DeviceNum);
uint8_t BMI323_Get_STATUS(uint8_t DeviceNum);
uint8_t BMI323_GyroDrdy(uint8_t DeviceNum);
uint8_t BMI323_AyroDrdy(uint8_t DeviceNum);
uint8_t BMI323_AllDrdy(uint8_t DeviceNum);
void BMI323_Init(uint8_t DeviceNum, BMI323_InitTypeDef *BMI323_InitStruct);
/********************************ACCE***********************************/
uint16_t BMI323_Get_AcceCfg_Reg(uint8_t DeviceNum);
void BMI323_Set_ACCE_ODR(uint8_t DeviceNum, BMI323_ACCE_ODR_TypeDef Value);
void BMI323_Set_ACCE_Range(uint8_t DeviceNum, BMI323_ACCE_RANGE_TypeDef Value);
void BMI323_Set_ACCE_BW_DIV(uint8_t DeviceNum, BMI323_ACCE_BW_DIV_TypeDef Value);
void BMI323_Set_ACCE_AVER_DIV(uint8_t DeviceNum, BMI323_ACCE_AVER_DIV_TypeDef Value);
void BMI323_Set_ACCE_MODE(uint8_t DeviceNum, BMI323_ACCE_MODE_TypeDef Value);
/********************************GYRO***********************************/
uint16_t BMI323_Get_GyroCfg_Reg(uint8_t DeviceNum);
void BMI323_Set_GYRO_ODR(uint8_t DeviceNum, BMI323_GYRO_ODR_TypeDef Value);
void BMI323_Set_GYRO_Range(uint8_t DeviceNum, BMI323_GYRO_RANGE_TypeDef Value);
void BMI323_Set_GYRO_BW_DIV(uint8_t DeviceNum, BMI323_GYRO_BW_DIV_TypeDef Value);
void BMI323_Set_GYRO_AVER_DIV(uint8_t DeviceNum, BMI323_GYRO_AVER_DIV_TypeDef Value);
void BMI323_Set_GYRO_MODE(uint8_t DeviceNum, BMI323_GYRO_MODE_TypeDef Value);
/******************************Get_Data*********************************/
void BMI323_Get_GyroTData(uint8_t DeviceNum, float Data[3], float *Temp_Data);
void BMI323_Get_AcceTData(uint8_t DeviceNum, float Data[3], float *Temp_Data);
void BMI323_Get_AllData(uint8_t DeviceNum, float Data[6], float *Temp_Data);
void BMI323_Data_Coversion(float Raw_Data[3], float New_Data[3], BMI323_GYRO_RANGE_TypeDef Value);
/******************************End*********************************/
void BMI323_Cfg_Write(uint8_t DeviceNum ,uint8_t addr, uint16_t data);
void BMI323_write(uint8_t id,uint8_t addr,uint16_t data);
uint16_t BMI323_read(uint8_t id,uint8_t addr);

#endif
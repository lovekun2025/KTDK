#ifndef  OS_MASTER_FILE
#include "Includes.h"
#endif

/*********************************************/
/*   ȫ�ֱ����ĳ�ʼ��                        */
/*********************************************/
void GlobalVariableToZero(void)
{
  uint8_t i=0;

////////////////////////////////  �ж�ISR ȫ�ֱ�����ʼ��
// ת�嶨�� imu����bufferָ��
  //��ʱ���ɼ�imu����
  for(i=0;i<SENSOR_NUMBER;i++)
  {
    IMUOriginalData[i] = 0.0;
    InertialDataInsSum[i] = 0.0;
  }  
  
  count_of_sumAD = 0;    /*ad�ۼ���*/
  count_of_cycleAD = 0;  /*ad�������ڼ���*/   
  count_ready = 0;
  ktUart0SendEn = 1;
  Ins_Timer = 0;       /*ʱ��*/

/*******************************/
  old_temp = 0.0; 
  Temp_Sum = 0.0;
  First_Temp_Flag = 1; 
    
  if(ImuStatus==0x80)
  {
      Acce_Calibration[0][1] = ParaAcce.AcceSF_X;   Acce_Calibration[0][0] = ParaAcce.AcceBias_X;
      Acce_Calibration[1][1] = ParaAcce.AcceSF_Y;   Acce_Calibration[1][0] = ParaAcce.AcceBias_Y;
      Acce_Calibration[2][1] = ParaAcce.AcceSF_Z;   Acce_Calibration[2][0] = ParaAcce.AcceBias_Z; 
        
      Gyro_Calibration[0][1] = ParaGyro.GyroSF_X;   Gyro_Calibration[0][0] = ParaGyro.GyroBias_X;
      Gyro_Calibration[1][1] = ParaGyro.GyroSF_Y;   Gyro_Calibration[1][0] = ParaGyro.GyroBias_Y;
      Gyro_Calibration[2][1] = ParaGyro.GyroSF_Z;   Gyro_Calibration[2][0] = ParaGyro.GyroBias_Z;   
  }	
  else
  {
      Acce_Calibration[0][1] = 1000.0;   Acce_Calibration[0][0] = 0.0;
      Acce_Calibration[1][1] = 1000.0;   Acce_Calibration[1][0] = 0.0;
      Acce_Calibration[2][1] = 1000.0;   Acce_Calibration[2][0] = 0.0; 
      
      Gyro_Calibration[0][1] = 1000.0;   Gyro_Calibration[0][0] = 0.0;
      Gyro_Calibration[1][1] = 1000.0;   Gyro_Calibration[1][0] = 0.0;
      Gyro_Calibration[2][1] = 1000.0;   Gyro_Calibration[2][0] = 0.0;
  }
  
  Acce_Disalignment[0] = 1.0;
  Acce_Disalignment[1] = -ParaAcce.ACCE_THETA_YX;
  Acce_Disalignment[2] = -ParaAcce.ACCE_THETA_ZX;
  
  Acce_Disalignment[3] = -ParaAcce.ACCE_THETA_XY;
  Acce_Disalignment[4] = 1.0;
  Acce_Disalignment[5] = -ParaAcce.ACCE_THETA_ZY;
  
  Acce_Disalignment[6] = -ParaAcce.ACCE_THETA_XZ;
  Acce_Disalignment[7] = -ParaAcce.ACCE_THETA_YZ;
  Acce_Disalignment[8] = 1.0;
  
  Gyro_Disalignment[0] =  1.0;
  Gyro_Disalignment[1] = -ParaGyro.GYRO_THETA_YX;
  Gyro_Disalignment[2] = -ParaGyro.GYRO_THETA_ZX;
  
  Gyro_Disalignment[3] = -ParaGyro.GYRO_THETA_XY;
  Gyro_Disalignment[4] =  1.0;
  Gyro_Disalignment[5] = -ParaGyro.GYRO_THETA_ZY; 
  
  Gyro_Disalignment[6] = -ParaGyro.GYRO_THETA_XZ;
  Gyro_Disalignment[7] = -ParaGyro.GYRO_THETA_YZ;
  Gyro_Disalignment[8] =  1.0;    

/*����Ϊ�û��궨�Ĳ���*/
  Acce_Disalignment_Crcted[0] = 1.0;
  Acce_Disalignment_Crcted[1] = -ParaUser.AcceYX_CROSS;
  Acce_Disalignment_Crcted[2] = -ParaUser.AcceZX_CROSS;
  
  Acce_Disalignment_Crcted[3] = -ParaUser.AcceXY_CROSS;
  Acce_Disalignment_Crcted[4] = 1.0;
  Acce_Disalignment_Crcted[5] = -ParaUser.AcceZY_CROSS;
  
  Acce_Disalignment_Crcted[6] = -ParaUser.AcceXZ_CROSS;
  Acce_Disalignment_Crcted[7] = -ParaUser.AcceYZ_CROSS;
  Acce_Disalignment_Crcted[8] = 1.0;
  
  Gyro_Disalignment_Crcted[0] =  1.0;
  Gyro_Disalignment_Crcted[1] = -ParaUser.GyroYX_CROSS;
  Gyro_Disalignment_Crcted[2] = -ParaUser.GyroZX_CROSS;
  
  Gyro_Disalignment_Crcted[3] = -ParaUser.GyroXY_CROSS;
  Gyro_Disalignment_Crcted[4] =  1.0;
  Gyro_Disalignment_Crcted[5] = -ParaUser.GyroZY_CROSS; 
  
  Gyro_Disalignment_Crcted[6] = -ParaUser.GyroXZ_CROSS;
  Gyro_Disalignment_Crcted[7] = -ParaUser.GyroYZ_CROSS;
  Gyro_Disalignment_Crcted[8] =  1.0; 
    
  return;
}

void waitingForIMUStable(void)
{
  while(count_ready < WAIT_FOR_STAB *  ktFrequency[frameID].sampleFrequencyHz / 1000);
}


/******************* (C) COPYRIGHT 2010 BEIJINGKAITUO*****END OF FILE****/

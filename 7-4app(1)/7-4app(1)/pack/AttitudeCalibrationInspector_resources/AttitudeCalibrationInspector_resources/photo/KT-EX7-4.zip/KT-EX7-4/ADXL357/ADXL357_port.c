#include "ADXL357_port.h" 

#ifdef ADXL357_GD_F405_SPI


void ADXL357_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(csNum == 0)
  {
    if(statusTemp == 0)
      GPIO_ResetBits(ADXL357_CS_PORT, ADXL357_CS_PIN);
    else
      GPIO_SetBits(ADXL357_CS_PORT, ADXL357_CS_PIN);  
  }
  //�ȴ�������������csNum��9-2��ֻһ��ADXL357�ӱ�
}


uint16_t ADXL357_Write_Read(uint16_t wrData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdData = 0;

  wrDataTemp = wrData;

  while(SPI_I2S_GetFlagStatus(ADXL357_SPI, SPI_I2S_FLAG_TXE) == 0);
  SPI_I2S_SendData(ADXL357_SPI, wrDataTemp);
  while(SPI_I2S_GetFlagStatus(ADXL357_SPI, SPI_I2S_FLAG_RXNE) == 0);
  rdData = SPI_I2S_ReceiveData(ADXL357_SPI);
  
  return rdData;

}

#endif


#ifdef ADXL357_ST_F103_SPI

#include "stm32f10x.h"

void ADXL357_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(csNum == 0)
  {
    if(statusTemp == 0)
      GPIO_ResetBits(ADXL357_CS_PORT, ADXL357_CS_PIN);
    else
      GPIO_SetBits(ADXL357_CS_PORT, ADXL357_CS_PIN);  
  }
  //�ȴ�������������csNum��9-2��ֻһ��ADXL357�ӱ�
}


uint16_t ADXL357_Write_Read(uint16_t wrData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdData = 0;

  wrDataTemp = wrData;

  while(SPI_I2S_GetFlagStatus(ADXL357_SPI, SPI_I2S_FLAG_TXE) == 0);
  SPI_I2S_SendData(ADXL357_SPI, wrDataTemp);
  while(SPI_I2S_GetFlagStatus(ADXL357_SPI, SPI_I2S_FLAG_RXNE) == 0);
  rdData = SPI_I2S_ReceiveData(ADXL357_SPI);
  
  return rdData;

}

#endif


#ifdef ADXL357_GD_F103_SPI

#include "gd32f10x.h"

void ADXL357_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(csNum == 0)
  {
    if(statusTemp == 0)
      gpio_bit_reset(ADXL357_CS_PORT, ADXL357_CS_PIN);
    else
      gpio_bit_set(ADXL357_CS_PORT, ADXL357_CS_PIN);  
  }
  //�ȴ�������������csNum��9-2��ֻһ��ADXL357�ӱ�
}


uint16_t ADXL357_Write_Read(uint16_t wrData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdData = 0;

  wrDataTemp = wrData;

  
  while(RESET == spi_i2s_flag_get(ADXL357_SPI, SPI_FLAG_TBE));
  spi_i2s_data_transmit(ADXL357_SPI, wrDataTemp);
  while(RESET == spi_i2s_flag_get(ADXL357_SPI, SPI_FLAG_RBNE));
  rdData = spi_i2s_data_receive(ADXL357_SPI);
  
  return rdData;

}

#endif


#ifndef _NAV_PRESSMETER_H_
#define _NAV_PRESSMETER_H_

#define PRESS_M 2
typedef struct _PRESSKFDONE PRESSKFDONE;
struct _PRESSKFDONE
{
	float PRESS_X1[PRESS_M];
	float PRESS_z1[1];
	float PRESS_H1[PRESS_M];
	float PRESS_R1[1];
	float PRESS_P1[PRESS_M*PRESS_M];	
};

typedef struct _PRESSMETER PRESSMETER;
struct _PRESSMETER
{
	PRESSKFDONE   presskfdone;
	float        kph_sqr;
	float        kph;
	float        kp0;
	float        Min_Hi;
	float        Max_Hi;
	char          start;
	char          flagpress;
	char          UpdatFlg;
	float        height;
	float        Record_Press;
	float         Record_GPS_H[20];
	int           RECORD_GPS_COUNTER;
	int           Press_Counter;
	int           (*Get_kf_calipress)(PRESSMETER *pressmeter, int m);
	int           (*Get_Calibrat_PressMeter)(PRESSMETER *pressmeter, float press, float Hi);
};

int nav_PressMeterCreate(PRESSMETER *pressmeter);
void nav_PressMeterDelete(PRESSMETER *pressmeter);
#endif

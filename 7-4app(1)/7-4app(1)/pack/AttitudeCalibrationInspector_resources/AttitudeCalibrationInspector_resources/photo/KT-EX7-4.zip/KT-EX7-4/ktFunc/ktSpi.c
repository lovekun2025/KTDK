#include  "Includes.h"

/*
GD32F405R���õ�ST�Ŀ⣬����SPI1��ӦGD��SPI0,....
/////////////////////ktSpiMap///////////////////////////////
            GD32E103xB/GD32F103xB          STM32F405RG(GD32F405RG)           STM32F103xB   ............        
ktSpi0       SPI0/PA5/PA6/PA7                 SPI1/PA5/PA6/PA7
ktSpi1                                      
ktSpi2
ktSpi3
......
*/

#if defined(GD32E103V_MD) || defined(GD32F10X_MD)

void ktSpi0GpioInit()
{ 
  //1�� ʹ�����gpio��gpio afʱ��
  rcu_periph_clock_enable(RCU_GPIOA);    
  rcu_periph_clock_enable(RCU_AF);   
  
  //2��JTAG/SWD���ù�����ӳ��   ��Է���������Ҫ��ֿ�����ӳ�䣡
  gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP,ENABLE); 
 
  //4�� ����gpio��Ӧ�ܽ�ΪAF����
  gpio_init (GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_5);   //SCK   
  gpio_init (GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_7);  //MOSI  
  gpio_init (GPIOA, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_6);  //MISO  
  
}

void ktSpi0Init()
{
  spi_parameter_struct spi_init_struct;
  
  rcu_periph_clock_enable(RCU_SPI0);
  
  /* SPI initial  -------------------------------------------------------------*/
  spi_i2s_deinit(SPI0);   //reset spi
  
  spi_init_struct.trans_mode = SPI_TRANSMODE_FULLDUPLEX;
  spi_init_struct.device_mode = SPI_MASTER;     //  ��������ģʽ 
  spi_init_struct.frame_size = SPI_FRAMESIZE_16BIT;    // һ֡ 16bits 
  spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;   //spi
  spi_init_struct.nss = SPI_NSS_SOFT;            // CS
  spi_init_struct.prescale = SPI_PSC_16;  //  clk  spi0/16 6.75MHz
  spi_init_struct.endian = SPI_ENDIAN_MSB;   // MSB first
  spi_init(SPI0, &spi_init_struct);
  
  spi_enable(SPI0);
}


#endif



#if defined(STM32F40XX)

void ktSpi0GpioInit()
{ 
  GPIO_InitTypeDef GPIO_InitStructure;

  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
  //RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1,ENABLE);
  
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource5, GPIO_AF_SPI1);
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource6, GPIO_AF_SPI1);
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource7, GPIO_AF_SPI1);
  
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5 | GPIO_Pin_6 |GPIO_Pin_7;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
   

  
}

void ktSpi0Init()
{
  
  SPI_InitTypeDef SPI_InitStructure;//84M
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1,ENABLE);
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;  //10.5M
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  //SPI_InitStructure.SPI_CRCPolynomial = 7;DISABLE
  SPI_Init(SPI1, &SPI_InitStructure); 
 // SPI_SSOutputCmd(SPI1,ENABLE);
  SPI_Cmd(SPI1, ENABLE);
  
}


#endif


#ifndef __ADXL357_PORT_H
#define __ADXL357_PORT_H


#include "Includes.h" 
#define ADXL357_GD_F405_SPI

#ifdef ADXL357_GD_F405_SPI
#include "stm32f4xx.h"

#define ADXL357_CS_PORT              GPIOA
#define ADXL357_CS_PIN               GPIO_Pin_3
#define ADXL357_SPI                  SPI1

#endif

#ifdef ADXL357_ST_F103_SPI
#include "stm32f10x.h"

#define ADXL357_CS_PORT              SPI_ACCE_CS_PORT
#define ADXL357_CS_PIN               SPI_ACCE_CS_PIN
#define ADXL357_SPI                  SPI_ACCE

#endif


#ifdef ADXL357_GD_F103_SPI
#include "gd32f10x.h"

#define ADXL357_CS_PORT              SPI_ACCE_CS_PORT 
#define ADXL357_CS_PIN               SPI_ACCE_CS_PIN
#define ADXL357_SPI                  SPI_ACCE

#endif

/*ʾ��
#ifdef ADXL357_����_�ͺ�_�ӿ�
#include "оƬͷ�ļ�"

���Ķ�����ĺ궨�壬ȥ�Ķ���GPIO.h����Hardware.h�еĺ궨������
#define ADXL357_CS_PORT              SPI_ACCE_CS_PORT 
#define ADXL357_CS_PIN               SPI_ACCE_CS_PIN
#define ADXL357_WRITE_READ_PORT      SPI_ACCE

#endif
*/
void ADXL357_CS_Set(uint8_t csNum, uint8_t ioStatus);
uint16_t ADXL357_Write_Read(uint16_t wrData);

#endif
#ifndef _matrix_h
#define _matrix_h

#define a_PI          (3.141592653589793)
void matmul(float out[3], float A[3][3], float B[3]);
float Vector_Product(float a[3],float b[3]);
//      ����ת�ú���
void MatRev(float *a,float *b, int m,int n);
void matplus(float *out, float *A, float *B, int m);
float *MatrixMul( float *ppdSrcM1, float *ppdSrcM2, float *ppdResult, int M1_Row, int M1_Col, int M2_Col ); 
float *MatrixMul3( float *ppdSrcM1, float *ppdSrcM2,  float *ppdSrcM3, float *ppdResult, int n, int nm, int mk, int k );
void Matrixim(float *a,int m);
void MatrixMultiply(float A[],float B[],int m,int n,int k,float C[]);
void MatrixReverse(float a[],int m,int n,float b[]);
void coortranna(float  Wni[3],float  Wbi[3],float  C[3][3]);//������ϵ�µ������ٶ�ת��������ϵ��
void coortra_mulsample(float  Wni[3],float  Wbi[3],float  C[3][3], float a[3]);
void Cal_Var( float Array[],int dim,float var[2]);
void H_Var( float Array[],int dim,float var[2]);
float cal_mean(float *array, int sum);
void sort_decrease(float *array, int sum);
void MatPara(float *a,float *b,float k,int n,int m);
int Find_Min(float *Array, int dim);
void mmdv(float *a,float *b,float *c,int m,int n);
int bf(float x,float *y,float *y1,float *x1,float b0,float *b,float *a,int N);

void select(float *a,float *b,int n,int m);
int SCJ(float a[3],float b[3],float c[3]);
int AccMean(int n,float acc[3], float macc[3],float std[3]);
int AccMean1(int n,float acc[3], float macc[3],float lim,int flag);
int GyroMean(int n,float acc[3], float macc[3],float std[3]);
float Cal_asin(float x);
#endif

/**
  ******************************************************************************
  * @file    ReadPara.h
  * @brief   Flash������ȡ.             
  ******************************************************************************
  * @attention
  *
  *  COPYRIGHT(c) 2018 ���غ���
  *
  * ���ܣ�������в����Ķ�д��
  * û�����ϵĲ������뵽FloatParaNull��ByteParaNull�����С�
  * Ŀǰ��������������Ժ���Ҫ�õ���ʱ����������C�ļ������¸������塣
  * ��C�ļ����������޸ġ�
  ******************************************************************************
  */ 
#ifndef _READ_PARA_H
#define _READ_PARA_H

#ifdef   IMU_GLOBALS      /*��ȫ�ֱ�������*/
#define  IMU_EXT
#else
#define  IMU_EXT   extern 
#endif     



#ifdef DSP28_F2812     //Ϊ�˳���ͨ����  dsp��arm�ж�����ʹ�ã����廥���Ա�������
typedef unsigned int        uint8_t;
typedef unsigned int        uint16_t;
#endif

//����оƬѡ����ʵ�flash��ַ
#if defined(DSP28_F2812) 
  //dsp f2812
  #define FLASH_PARA_FACTORY    0x3DA000
  #define FLASH_PARA_USER       0x3D8000
  #define UserParmentAddress    0x3D9000      /* �������趨�û�ģʽ */

#elif defined (STM32F10X_MD) || defined(GD32F10X_MD)  || defined(GD32E103V_MD)//arm stm32f103rc
 
  #define FLASH_PARA_FACTORY    0x08003000
  #define FLASH_PARA_USER       0x08002000

  #define FLASH_PARA_FACTORY1   0x08005000  //��2�ײ���
  #define FLASH_PARA_USER1      0x08004000

  #define UserParmentAddress    0x08006000      /*������λ��*/
  #define UartBaudAddress       0x08008000      /*������λ��,9-2��*/
  #define FirFilterAddress      0x08007000      /*������λ��,9-2��*/

#elif defined (STM32F40XX) 
  #define FLASH_PARA_FACTORY1    0x0800C000  //��2�ײ���
  #define FLASH_PARA_USER1       0x0800C000

  #define FLASH_PARA_FACTORY    0x08008000
  #define FLASH_PARA_USER       0x08004000

  #define UserParmentAddress    0x08010000      /*������λ��*/

#endif

//�ö���8KB��ʹ��4KB  �û����α궨����  ��Flash281x_API_Library.h�ж���
#define USER_PAR_SECT          SECTORJ

#define FLASH_CRC1_Address    4094            /*FLASH CRC1 λ��*/
#define FLASH_CRC2_Address    224             /*FLASH CRC2 λ��*/

//����KT-EX6-1�Ĳ������ý��ж�ȡ
/*��ȡFlash����*/
IMU_EXT uint8_t FlashStatus;        /*Flash״̬��CRCУ���Ƿ�ͨ��*/

IMU_EXT uint8_t productID[10];      /*��Ʒ����*/
IMU_EXT uint8_t productNum[10];     /*��Ʒ���*/
IMU_EXT uint8_t softwareVer[10];    /*�����汾��*/
IMU_EXT uint8_t hardwareVer[10];    /*Ӳ���汾��*/
IMU_EXT uint8_t batchNum[10];       /*��Ʒ���κ�*/
IMU_EXT uint8_t ImuStatus;          /*IMU״̬����Ʒ���������Ǹ����ڣ��²�������*/
IMU_EXT uint8_t Rec_Data01;         

//�ӱ�������������
typedef struct
{
  int    AcceTempCoef_X_Flag;      /*�ֶα�־�� ���ڼӱ������ֶΣ�����������*/
  int    AcceTempCoef_Y_Flag;
  int    AcceTempCoef_Z_Flag; 
  
  float  Acce_Temp_X;
  float  Acce_Temp_Y;
  float  Acce_Temp_Z;
  /*�ӱ���λ�²�*/
  float  	Acce_Temp1_X;
   float  	Acce_Temp2_X;
   float  	Acce_Temp3_X;
   float  	Acce_Temp4_X;
   float  	Acce_Temp5_X;
   float  	Acce_Temp6_X;
   float  	Acce_Temp7_X;
   float  	AcceBias_D1_X1;
   float  	AcceBias_D1_X0;
   float  	AcceBias_D2_X1;
   float  	AcceBias_D2_X0;
   float  	AcceBias_D3_X1;
   float  	AcceBias_D3_X0;
   float  	AcceBias_D4_X1;
   float  	AcceBias_D4_X0;
   float  	AcceBias_D5_X1;
   float  	AcceBias_D5_X0;
   float  	AcceBias_D6_X1;
   float  	AcceBias_D6_X0;
   float  	AcceBias_D7_X1;
   float  	AcceBias_D7_X0;
   float  	AcceBias_D8_X1;
   float  	AcceBias_D8_X0;

   float  	Acce_Temp1_Y;
   float  	Acce_Temp2_Y;
   float  	Acce_Temp3_Y;
   float  	Acce_Temp4_Y;
   float  	Acce_Temp5_Y;
   float  	Acce_Temp6_Y;
   float  	Acce_Temp7_Y;
   float  	AcceBias_D1_Y1;
   float  	AcceBias_D1_Y0;
   float  	AcceBias_D2_Y1;
   float  	AcceBias_D2_Y0;
   float  	AcceBias_D3_Y1;
   float  	AcceBias_D3_Y0;
   float  	AcceBias_D4_Y1;
   float  	AcceBias_D4_Y0;
   float  	AcceBias_D5_Y1;
   float  	AcceBias_D5_Y0;
   float  	AcceBias_D6_Y1;
   float  	AcceBias_D6_Y0;
   float  	AcceBias_D7_Y1;
   float  	AcceBias_D7_Y0;
   float  	AcceBias_D8_Y1;
   float  	AcceBias_D8_Y0;

   float  	Acce_Temp1_Z;
   float  	Acce_Temp2_Z;
   float  	Acce_Temp3_Z;
   float  	Acce_Temp4_Z;
   float  	Acce_Temp5_Z;
   float  	Acce_Temp6_Z;
   float  	Acce_Temp7_Z;
   float  	AcceBias_D1_Z1;
   float  	AcceBias_D1_Z0;
   float  	AcceBias_D2_Z1;
   float  	AcceBias_D2_Z0;
   float  	AcceBias_D3_Z1;
   float  	AcceBias_D3_Z0;
   float  	AcceBias_D4_Z1;
   float  	AcceBias_D4_Z0;
   float  	AcceBias_D5_Z1;
   float  	AcceBias_D5_Z0;
   float  	AcceBias_D6_Z1;
   float  	AcceBias_D6_Z0;
   float  	AcceBias_D7_Z1;
   float  	AcceBias_D7_Z0;
   float  	AcceBias_D8_Z1;
   float  	AcceBias_D8_Z0;

  /*�ӱ���������¶�ϵ��*/
  int    AcceSF_X_Flag;
  int    AcceSF_Y_Flag;
  int    AcceSF_Z_Flag;
  
  float  AcceSF_Temp_X;
  float  AcceSF_Temp_Y;
  float  AcceSF_Temp_Z;

  float  AcceSFOT_X2;
  float  AcceSFOT_X1;
  float  AcceSFOT_X0;
  
  float  AcceSFDW_X2;
  float  AcceSFDW_X1;
  float  AcceSFDW_X0;
  float  AcceSFGW_X2;
  float  AcceSFGW_X1;
  float  AcceSFGW_X0;

  float  AcceSFOT_Y2;
  float  AcceSFOT_Y1;
  float  AcceSFOT_Y0;
  
  float  AcceSFDW_Y2;
  float  AcceSFDW_Y1;
  float  AcceSFDW_Y0;
  float  AcceSFGW_Y2;
  float  AcceSFGW_Y1;
  float  AcceSFGW_Y0;

  float  AcceSFOT_Z2;
  float  AcceSFOT_Z1;
  float  AcceSFOT_Z0;
  
  float  AcceSFDW_Z2;
  float  AcceSFDW_Z1;
  float  AcceSFDW_Z0;
  float  AcceSFGW_Z2;
  float  AcceSFGW_Z1;
  float  AcceSFGW_Z0;

  /*�ӱ����±궨*/
  float  AcceSF_X;
  float  AcceBias_X;
  float  AcceNT_X;
  
  float  AcceSF_Y;
  float  AcceBias_Y;
  float  AcceNT_Y;
  
  float  AcceSF_Z;
  float  AcceBias_Z;
  float  AcceNT_Z;
  /*�ӱ���װ���*/
  float  ACCE_THETA_YX;
  float  ACCE_THETA_ZX;

  float  ACCE_THETA_XY;
  float  ACCE_THETA_ZY;

  float  ACCE_THETA_XZ;
  float  ACCE_THETA_YZ;

  /*�ӱ������־*/
  int AcceX_sign_Flag;
  int AcceY_sign_Flag;
  int AcceZ_sign_Flag;

  float  AcceSF_X_Crcted;
  float  AcceSF_Y_Crcted;
  float  AcceSF_Z_Crcted;
}ACCE_PARA;

//��ǲ�����������
typedef struct
{
  float  AcceTempCoef_X2;
  float  AcceTempCoef_X1;
  float  AcceTempCoef_X0;
  
  float  AcceTempCoef_Y2;
  float  AcceTempCoef_Y1;
  float  AcceTempCoef_Y0;
  
  float  AcceTempCoef_Z2;
  float  AcceTempCoef_Z1;
  float  AcceTempCoef_Z0;

  /*�ӱ���������¶�ϵ��*/

  float  AcceSFOT_X2;
  float  AcceSFOT_X1;
  float  AcceSFOT_X0;

  float  AcceSFOT_Y2;
  float  AcceSFOT_Y1;
  float  AcceSFOT_Y0;

  float  AcceSFOT_Z2;
  float  AcceSFOT_Z1;
  float  AcceSFOT_Z0;

  /*�ӱ����±궨*/
  float  AcceSF_X;
  float  AcceBias_X;
  float  AcceNT_X;
  
  float  AcceSF_Y;
  float  AcceBias_Y;
  float  AcceNT_Y;
  
  float  AcceSF_Z;
  float  AcceBias_Z;
  float  AcceNT_Z;
  /*�ӱ���װ���*/
  float  ACCE_THETA_YX;
  float  ACCE_THETA_ZX;

  float  ACCE_THETA_XY;
  float  ACCE_THETA_ZY;

  float  ACCE_THETA_XZ;
  float  ACCE_THETA_YZ;

  /*�ӱ������־*/
  int AcceX_sign_Flag;
  int AcceY_sign_Flag;
  int AcceZ_sign_Flag;
}ACCE_QJ_PARA;


////////////////////���ݲ�����������
typedef struct
{
  /*���ݳ��±궨*/
  float  GyroBias_X;
  float  GyroSF_X;

  float  GyroBias_Y;
  float  GyroSF_Y;

  float  GyroBias_Z;
  float  GyroSF_Z;

  /*������λ�²�*/  
  int    GyroTempCoef_X_Flag;      /*�ֶα�־��  6��8��10Ϊ��6��8��10��*/
  int    GyroTempCoef_Y_Flag;
  int    GyroTempCoef_Z_Flag;   
  
  float  	Gyro_Temp1_X;
  float  	Gyro_Temp2_X;
  float  	Gyro_Temp3_X;
  float  	Gyro_Temp4_X;
  float  	Gyro_Temp5_X;
  float  	Gyro_Temp6_X;
  float  	Gyro_Temp7_X;
  float  	Gyro_Temp8_X;
  float  	Gyro_Temp9_X;
  float  	GyroBias_D1_X1;
  float  	GyroBias_D1_X0;
  float  	GyroBias_D2_X1;
  float  	GyroBias_D2_X0;
  float  	GyroBias_D3_X1;
  float  	GyroBias_D3_X0;
  float  	GyroBias_D4_X1;
  float  	GyroBias_D4_X0;
  float  	GyroBias_D5_X1;
  float  	GyroBias_D5_X0;
  float  	GyroBias_D6_X1;
  float  	GyroBias_D6_X0;
  float  	GyroBias_D7_X1;
  float  	GyroBias_D7_X0;
  float  	GyroBias_D8_X1;
  float  	GyroBias_D8_X0;
  float  	GyroBias_D9_X1;
  float  	GyroBias_D9_X0;
  float  	GyroBias_D10_X1;
  float  	GyroBias_D10_X0;
  
  float  	Gyro_Temp1_Y;
  float  	Gyro_Temp2_Y;
  float  	Gyro_Temp3_Y;
  float  	Gyro_Temp4_Y;
  float  	Gyro_Temp5_Y;
  float  	Gyro_Temp6_Y;
  float  	Gyro_Temp7_Y;
  float  	Gyro_Temp8_Y;
  float  	Gyro_Temp9_Y;
  float  	GyroBias_D1_Y1;
  float  	GyroBias_D1_Y0;
  float  	GyroBias_D2_Y1;
  float  	GyroBias_D2_Y0;
  float  	GyroBias_D3_Y1;
  float  	GyroBias_D3_Y0;
  float  	GyroBias_D4_Y1;
  float  	GyroBias_D4_Y0;
  float  	GyroBias_D5_Y1;
  float  	GyroBias_D5_Y0;
  float  	GyroBias_D6_Y1;
  float  	GyroBias_D6_Y0;
  float  	GyroBias_D7_Y1;
  float  	GyroBias_D7_Y0;
  float  	GyroBias_D8_Y1;
  float  	GyroBias_D8_Y0;
  float  	GyroBias_D9_Y1;
  float  	GyroBias_D9_Y0;
  float  	GyroBias_D10_Y1;
  float  	GyroBias_D10_Y0;
  
  float  	Gyro_Temp1_Z;
  float  	Gyro_Temp2_Z;
  float  	Gyro_Temp3_Z;
  float  	Gyro_Temp4_Z;
  float  	Gyro_Temp5_Z;
  float  	Gyro_Temp6_Z;
  float  	Gyro_Temp7_Z;
  float  	Gyro_Temp8_Z;
  float  	Gyro_Temp9_Z;
  float  	GyroBias_D1_Z1;
  float  	GyroBias_D1_Z0;
  float  	GyroBias_D2_Z1;
  float  	GyroBias_D2_Z0;
  float  	GyroBias_D3_Z1;
  float  	GyroBias_D3_Z0;
  float  	GyroBias_D4_Z1;
  float  	GyroBias_D4_Z0;
  float  	GyroBias_D5_Z1;
  float  	GyroBias_D5_Z0;
  float  	GyroBias_D6_Z1;
  float  	GyroBias_D6_Z0;
  float  	GyroBias_D7_Z1;
  float  	GyroBias_D7_Z0;
  float  	GyroBias_D8_Z1;
  float  	GyroBias_D8_Z0;
  float  	GyroBias_D9_Z1;
  float  	GyroBias_D9_Z0;
  float  	GyroBias_D10_Z1;
  float  	GyroBias_D10_Z0;  
  /*���ݱ�������²�*/
  int    GyroSFOT_X_Flag;          /*�ֶα�־��  2Ϊ��2��*/
  int    GyroSFOT_Y_Flag;
  int    GyroSFOT_Z_Flag;   
  
  float  GyroSF_Temp_X;            /*SFOT�ֶε��¶ȵ�*/
  float  GyroSF_Temp_Y;
  float  GyroSF_Temp_Z;     
  
  float  GyroSFOT_X3; 
  float  GyroSFOT_X2; 
  float  GyroSFOT_X1; 
  float  GyroSFOT_X0;
  
  float  GyroSFDW_X3; 
  float  GyroSFDW_X2; 
  float  GyroSFDW_X1; 
  float  GyroSFDW_X0; 
  
  float  GyroSFGW_X3; 
  float  GyroSFGW_X2; 
  float  GyroSFGW_X1; 
  float  GyroSFGW_X0;
  
  float  GyroSFOT_Y3; 
  float  GyroSFOT_Y2; 
  float  GyroSFOT_Y1; 
  float  GyroSFOT_Y0;
  
  float  GyroSFDW_Y3; 
  float  GyroSFDW_Y2; 
  float  GyroSFDW_Y1; 
  float  GyroSFDW_Y0; 
  
  float  GyroSFGW_Y3; 
  float  GyroSFGW_Y2; 
  float  GyroSFGW_Y1; 
  float  GyroSFGW_Y0;
  
  float  GyroSFOT_Z3; 
  float  GyroSFOT_Z2; 
  float  GyroSFOT_Z1; 
  float  GyroSFOT_Z0;
  
  float  GyroSFDW_Z3; 
  float  GyroSFDW_Z2; 
  float  GyroSFDW_Z1; 
  float  GyroSFDW_Z0; 
  
  float  GyroSFGW_Z3; 
  float  GyroSFGW_Z2; 
  float  GyroSFGW_Z1; 
  float  GyroSFGW_Z0;
  /*�Բв����3�����*/
  float  resPzX[4];
  float  resPfX[4];
  float  resPzY[4];
  float  resPfY[4];
  float  resPzZ[4];
  float  resPfZ[4];
  /*���ݰ�װ���*/
  float  GYRO_THETA_YX;
  float  GYRO_THETA_ZX;

  float  GYRO_THETA_XY;
  float  GYRO_THETA_ZY;

  float  GYRO_THETA_XZ;
  float  GYRO_THETA_YZ;

  /*���ݷ����־*/
  int GyroX_sign_Flag;
  int GyroY_sign_Flag;
  int GyroZ_sign_Flag;
  
  /*����Gֵ������*/
  float GYRO_G_SENSITIVITY_XX;
  float GYRO_G_SENSITIVITY_YX;
  float GYRO_G_SENSITIVITY_ZX;
  float GYRO_G_SENSITIVITY_XY;
  float GYRO_G_SENSITIVITY_YY;
  float GYRO_G_SENSITIVITY_ZY;
  float GYRO_G_SENSITIVITY_XZ;
  float GYRO_G_SENSITIVITY_YZ;
  float GYRO_G_SENSITIVITY_ZZ;

}GYRO_PARA;

//////////////////�������ʱ���ֵ��޷�����
typedef struct
{
   /*����޷��趨*/
   float WX_FS_Z;
   float WX_FS_F;
   float WY_FS_Z;
   float WY_FS_F;
   float WZ_FS_Z;
   float WZ_FS_F;

   float AX_FS_Z;
   float AX_FS_F;
   float AY_FS_Z;
   float AY_FS_F;
   float AZ_FS_Z;
   float AZ_FS_F;

   float WX_SCALE;
   float WY_SCALE;
   float WZ_SCALE;
   float AX_SCALE;
   float AY_SCALE;
   float AZ_SCALE;
}PRODUCT_RANGE;


//////////////////////�û���������
typedef struct
{
  float  AcceX_relativeSF;
  float  AcceY_relativeSF;
  float  AcceZ_relativeSF;

  float  AcceX_relativeBIAS;
  float  AcceY_relativeBIAS;
  float  AcceZ_relativeBIAS;

  float  AcceYX_CROSS;
  float  AcceZX_CROSS;
  float  AcceXY_CROSS;

  float  AcceZY_CROSS;
  float  AcceXZ_CROSS;
  float  AcceYZ_CROSS;

  float  GyroX_relativeSF;
  float  GyroY_relativeSF;
  float  GyroZ_relativeSF;

  float  GyroYX_CROSS;
  float  GyroZX_CROSS;
  float  GyroXY_CROSS;

  float  GyroZY_CROSS;
  float  GyroXZ_CROSS;
  float  GyroYZ_CROSS;
  
  float  GyroRelativeBias_X;
  float  GyroRelativeBias_Y;
  float  GyroRelativeBias_Z;
  
  uint8_t Resv[74];
  uint8_t FactorySet[20];
  uint8_t ExperimentStatus; //��Ʒ�Ľ���ǰ״̬�����ں�SPI�����л�
  uint8_t DataFormat;
  uint8_t TERM;
  uint8_t UNIT;
  uint8_t SampleFreq;
  uint8_t LPFilter;
  uint8_t FilterAxis;
  uint8_t BitRate;
  uint8_t Parity;
  uint8_t StopBit;
  uint8_t productID[10];
  uint8_t productNum[10];
  uint8_t softwareVer[10];
  uint8_t hardwareVer[10];
  uint8_t checkNUM[2];

}USER_PARA;

typedef struct
{
  /*��ͨ�˲���*/
  float  LowPass_Gain;
  float  LowPass_b;
  float  LowPass_c;

  /*31�׵�ͨ�˲���*/
    float BB[32];
}FILTER_PARA;

typedef struct
{
    uint8_t UserData[96];
    uint8_t Resv[78];
}USER_PARA2;		//	дflashʱ����flash�е�������ʱ����

IMU_EXT FILTER_PARA ParaFilter;
IMU_EXT ACCE_PARA ParaAcce;
IMU_EXT ACCE_QJ_PARA ParaQJ;
IMU_EXT GYRO_PARA ParaGyro;
IMU_EXT USER_PARA ParaUser;
//IMU_EXT USER_PARA2 ParaUser2;
IMU_EXT PRODUCT_RANGE ProductRange;  
IMU_EXT float FloatParaNull[73];
IMU_EXT uint8_t ByteParaNull[3];

float Flash_get_F32(uint8_t* receive,int pos);
//uint16_t CRC16(uint8_t *pch,int len);
//uint16_t crc_calculate_Par(uint8_t data,uint16_t crc);
void Reset_ReadPara();
//void SetDataFreq();


#endif

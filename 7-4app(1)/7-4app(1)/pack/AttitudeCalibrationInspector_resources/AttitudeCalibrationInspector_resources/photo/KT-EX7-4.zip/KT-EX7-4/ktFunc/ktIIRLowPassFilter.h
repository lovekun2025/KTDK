#ifndef __KT_IIR_LOW_PASS_FILTER_H
#define __KT_IIR_LOW_PASS_FILTER_H



//#define IIR_FILER_1_ENABLE
//#define IIR_FILER_2_ENABLE

typedef struct
{
  float u0;
  float u1;
  float u2;
  float y0;
  float y1;
  float y2;
  float Gain;
  float a;
  float b;
  float c;
}FILTER_LOWPASS;

#ifdef IIR_FILER_1_ENABLE

#define KT_IIR_LOW_PASS_FILER_1_N  6   //Ĭ��6����ͨ�˲���

extern FILTER_LOWPASS LowPassFilter1[KT_IIR_LOW_PASS_FILER_1_N];   

//����,���ڱ���ͨ��
//extern FILTER_LOWPASS LowPassFilter_x, LowPassFilter_y, LowPassFilter_z;
//extern FILTER_LOWPASS LowPassFilter_ax, LowPassFilter_ay, LowPassFilter_az,LowPassFilter_a1x, LowPassFilter_a1y, LowPassFilter_a1z, LowPassFilter_az,LowPassFilter_accex,LowPassFilter_accey,LowPassFilter_accez;

#define  IIR_FILER_1_SAMPLE_100_TO_50

#ifdef IIR_FILER_1_SAMPLE_1000_TO_150     
#define IIR_LOW_PASS_FILER_1_GYRO_GAIN    0.13110643991662596           
#define IIR_LOW_PASS_FILER_1_GYRO_B       -0.74778917825850344       
#define IIR_LOW_PASS_FILER_1_GYRO_C       0.27221493792500728        

#define IIR_LOW_PASS_FILER_1_ACCE_GAIN    0.13110643991662596     
#define IIR_LOW_PASS_FILER_1_ACCE_B       -0.74778917825850344  
#define IIR_LOW_PASS_FILER_1_ACCE_C       0.27221493792500728

#define IIR_LOW_PASS_FILER_1_TITL_GAIN    1    
#define IIR_LOW_PASS_FILER_1_TITL_B       0
#define IIR_LOW_PASS_FILER_1_TITL_C       0
#endif    

#ifdef IIR_FILER_1_SAMPLE_100_TO_50     
#define IIR_LOW_PASS_FILER_1_GYRO_GAIN    0.99999999999999989              
#define IIR_LOW_PASS_FILER_1_GYRO_B       1.9999999999999998             
#define IIR_LOW_PASS_FILER_1_GYRO_C       0.99999999999999978             

#define IIR_LOW_PASS_FILER_1_ACCE_GAIN    0.99999999999999989   
#define IIR_LOW_PASS_FILER_1_ACCE_B       1.9999999999999998  
#define IIR_LOW_PASS_FILER_1_ACCE_C       0.99999999999999978

#define IIR_LOW_PASS_FILER_1_TITL_GAIN    1    
#define IIR_LOW_PASS_FILER_1_TITL_B       0
#define IIR_LOW_PASS_FILER_1_TITL_C       0
#endif 

#ifdef IIR_FILER_1_SAMPLE_100_TO_10     
#define IIR_LOW_PASS_FILER_1_GAIN    0.067455273889071896      
#define IIR_LOW_PASS_FILER_1_B       (-1.1429805025399011)     
#define IIR_LOW_PASS_FILER_1_C       0.41280159809618877         
#endif  



#endif


#ifdef IIR_FILER_2_ENABLE

#define KT_IIR_LOW_PASS_FILER_2_N  3  

extern FILTER_LOWPASS LowPassFilter2[KT_IIR_LOW_PASS_FILER_2_N];

#ifdef IIR_FILER_2_SAMPLE_1000_TO_200     
#define IIR_LOW_PASS_FILER_2_GAIN    0.067455273889071896      
#define IIR_LOW_PASS_FILER_2_B       (-1.1429805025399011)     
#define IIR_LOW_PASS_FILER_2_C       0.41280159809618877         
#endif

#endif


void ktIIRLowPassFilter1Init();
void ktIIRLowPassFilter2Init();
void ktIIRLowPassFilterDeal(float *ins_data,FILTER_LOWPASS *filter);


#endif


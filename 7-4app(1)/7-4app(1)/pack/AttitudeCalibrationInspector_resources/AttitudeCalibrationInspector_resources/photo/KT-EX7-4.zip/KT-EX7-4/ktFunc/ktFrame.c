/*******************************************************
* ktFrame ����3��״̬��0��ȣ�1��֤��2����
��Ӧ�Ĳ���Ƶ�ʣ�����Ƶ�ʣ�����Ƶ��
��Ӧ�ķ���֡��ʽ�����պ������ж�Ӧ�ĺ���

ktFrequency_s ktFrequency[3] = 
{
  {BD_SAMPLE_FREQ_Hz,BD_CALC_FREQ_Hz,BD_SEND_FREQ_Hz},   //0�궨
  {YZ_SAMPLE_FREQ_Hz,YZ_CALC_FREQ_Hz,YZ_SEND_FREQ_Hz},   //1��֤ 
  {JF_SAMPLE_FREQ_Hz,JF_CALC_FREQ_Hz,JF_SEND_FREQ_Hz},   //2����
};


const ktFrameFun_s ktFrameFun[KT_FRAME_NUM] = 
{
  {makeBdFrame,rxBdFrameDeal},      //�궨
  {makeYzFrame,rxYzFrameDeal},      //��֤
  {makeJfFrame,rxJfFrameDeal},      //����
};


�궨Э�飺makeBdFrame()
�ڲ���֤��makeYzFrame() �����������������ָ��ʹ�ñ궨Э��makeBdFrame()
����Э�飺��ktFrameUser.c��ʵ�ֽ���Э�顣
ktFrame����ɱ궨Э�飬�ڲ���֤Э�顣
*******************************************************/

#include  "Includes.h"
#include "ktUart.h"
//ȫ�ֱ���
uint8_t frameID = 0;

//ktUart0
uint8_t  ktUart0TxBuff[KT_UART0_TX_BUFF_LEN];    // ktUart0�������ݻ���
uint16_t ktUart0TxLength;                        // ktUart0�������ݳ���
uint8_t  ktUart0SendEn;                          // ktUart0����ʹ��

uint8_t  ktUart0RxBuff[KT_UART0_RX_BUFF_LEN];    // ktUart0�������ݻ���
uint16_t ktUart0RxLength;                        // ktUart0�������ݳ���
uint16_t ktUart0RxPos;                           // ktUart0���յ���������ktUart0RxBuff�е�λ��
uint8_t  ktUart0RxReady = 0;                     // ktUart0������һ�����ݱ�־

uint8_t  ktUart0RxBuff1[KT_UART0_RX_BUFF1_LEN];  //ktUart0�������ݵĶ������棬���Ⱥ�Ӧ�����

ktFrequency_s ktFrequency[3] = 
{
  {BD_SAMPLE_FREQ_Hz,BD_CALC_FREQ_Hz,BD_SEND_FREQ_Hz},   //0�궨
  {YZ_SAMPLE_FREQ_Hz,YZ_CALC_FREQ_Hz,YZ_SEND_FREQ_Hz},   //1��֤ 
  {JF_SAMPLE_FREQ_Hz,JF_CALC_FREQ_Hz,JF_SEND_FREQ_Hz},   //2����
};


const ktFrameFun_s ktFrameFun[KT_FRAME_NUM] = 
{
  {makeBdFrame,rxBdFrameDeal},      //�궨
  {makeYzFrame,rxYzFrameDeal},      //��֤
  {makeJfFrame,rxJfFrameDeal},      //����
};


void funNull()
{
  ;
}


void ktFrameInit()
{
  if((ImuStatus == 0x80) && (ParaUser.ExperimentStatus == 1))
    frameID = 2;
  else if((ImuStatus == 0x80) && (ParaUser.ExperimentStatus == 0))
    frameID = 1;
  else
    frameID = 0;
  
  if(Rec_Data01 == 0x08)
  {
    ktFrequency[0].sendFrequencyHz  = 20;
    ktFrequency[0].calFrequencyHz = 20;
  } 
  if((Rec_Data01 == 0x00) || (Rec_Data01 == 0x02))
  {
    ktFrequency[0].sendFrequencyHz  = 1; 
    ktFrequency[0].calFrequencyHz = 1;
  }
  
  
  if(ImuStatus == 0x80)
  {
    FilterFlag = VALID;
  }
  else if(0x03 == Rec_Data01) 
  {
    FilterFlag = VALID;
  }
  else
  {
    FilterFlag = INVALID;
  }
  
 
  if(ImuStatus == 0x80)
  {
//    FilterFlag = VALID;
    WenBuFlag = VALID;
    ReleaseFlag = VALID; 
  }
  else if(ImuStatus == 0x00)
  {
//    FilterFlag = INVALID;
    WenBuFlag = INVALID;
    ReleaseFlag = INVALID;  
  }
  else if(ImuStatus == 0x08)
  {
//    FilterFlag = INVALID;
    WenBuFlag = VALID;
    ReleaseFlag = INVALID; 
  }
  else
  {
//    FilterFlag = INVALID;
    WenBuFlag = INVALID;
    ReleaseFlag = INVALID;  
  }
}


void makeStateCheckFrame()
{
  ktUart0TxLength = 6;
  ktUart0TxBuff[0] = 0xEB;
  ktUart0TxBuff[1] = 0x90;
  ktUart0TxBuff[2] = 0x03;
  ktUart0TxBuff[3] = 0xF1;
  ktUart0TxBuff[4] = Rec_Data01&0xff;
  ktUart0TxBuff[5] = CheckSum(&ktUart0TxBuff[0],5);
}


void makeProductStateFrame()
{
  ktUart0TxLength = 6;
  ktUart0TxBuff[0] = 0xEB;
  ktUart0TxBuff[1] = 0x90;
  ktUart0TxBuff[2] = 0x03;//���ݰ�����
  ktUart0TxBuff[3] = 0xF4;//֡ID
  ktUart0TxBuff[4] = ParaUser.ExperimentStatus; //0x00����ǰ��֤��0x01����״̬
  ktUart0TxBuff[5] = CheckSum(&ktUart0TxBuff[0],5);
  
}
void makeCmdBackFrame()
{
  ktUart0TxLength = 5;
  ktUart0TxBuff[0] = 0xEB;
  ktUart0TxBuff[1] = 0x90;
  ktUart0TxBuff[2] = 0x02;
  ktUart0TxBuff[3] = 0xF3;  		
  ktUart0TxBuff[4] = CheckSum(&ktUart0TxBuff[0],4);
  
}

void makeProNumCheckFrame()
{
  ktUart0TxLength = 15;
  ktUart0TxBuff[0] = 0xEB;
  ktUart0TxBuff[1] = 0x90;
  ktUart0TxBuff[2] = 0x0C;
  ktUart0TxBuff[3] = 0xF2;  
  ktUart0TxBuff[4] = productNum[0]&0xff; 	
  ktUart0TxBuff[5] = productNum[1]&0xff; 
  ktUart0TxBuff[6] = productNum[2]&0xff; 
  ktUart0TxBuff[7] = productNum[3]&0xff; 
  ktUart0TxBuff[8] = productNum[4]&0xff; 
  ktUart0TxBuff[9] = productNum[5]&0xff; 
  ktUart0TxBuff[10] = productNum[6]&0xff; 
  ktUart0TxBuff[11] = productNum[7]&0xff; 
  ktUart0TxBuff[12] = productNum[8]&0xff; 
  ktUart0TxBuff[13] = productNum[9]&0xff; 
  ktUart0TxBuff[14] = CheckSum(&ktUart0TxBuff[0],14);  	
}

extern unsigned short int iic_value[4];
void makeBdFrame()
{
  static uint8_t bdFrameCnt = 0;
  uint16_t i = 0;
  
  ktUart0TxLength = 70;  
  
  for(i = 0; i < ktUart0TxLength; i++)
    ktUart0TxBuff[0] = 0;
  
  ktUart0TxBuff[0] = 0xEB;
  ktUart0TxBuff[1] = 0x90;
  ktUart0TxBuff[2] = 0x43;
  ktUart0TxBuff[3] = 0x02;
  
  make_F32_LH(InertialDataIns[0], &ktUart0TxBuff[4],1,2147483648);
  make_F32_LH(InertialDataIns[1], &ktUart0TxBuff[8],1,2147483648);
  make_F32_LH(InertialDataIns[2], &ktUart0TxBuff[12],1,2147483648);
  
  make_F32_LH(InertialDataIns[3], &ktUart0TxBuff[16],1,2147483648);
  make_F32_LH(InertialDataIns[4], &ktUart0TxBuff[20],1,2147483648);
  make_F32_LH(InertialDataIns[5], &ktUart0TxBuff[24],1,2147483648);
  
  make_F32_LH(InertialDataIns[6], &ktUart0TxBuff[28],1,2147483648);
  make_F32_LH(InertialDataIns[7], &ktUart0TxBuff[32],1,2147483648);
  
  
    make_F32_LH(iic_value[0], &ktUart0TxBuff[56],1,2147483648);
    make_F32_LH(iic_value[1], &ktUart0TxBuff[60],1,2147483648);  
    make_F32_LH(iic_value[2], &ktUart0TxBuff[64],1,2147483648);  

  
  
  ktUart0TxBuff[68] = bdFrameCnt++;       
  ktUart0TxBuff[69] = CheckSum(ktUart0TxBuff,69);  
  
}

uint8_t getRxBdFrame()
{
  uint16_t i = 0;
  uint16_t dataLengthTemp = 0;
  uint16_t dataPosTemp = 0;
  uint16_t rxFrameLength = 0;
  uint16_t startPos = 0;
  
  static uint8_t  frameSyn = 0;
  static uint16_t rxLengthSum = 0;
  static uint16_t destPos = 0;
  
 
  ktUart0IdleIntDisable();
  ktUart0RxReady = 0;
  dataLengthTemp  = ktUart0RxLength;
  dataPosTemp = ktUart0RxPos;
  ktUart0IdleIntEnable();

  if(dataLengthTemp > RX_BD_FRAME_LENGTH_MAX)
  {
    rxLengthSum = 0;
    frameSyn = 0;
    return 1 ;
  }
    
  destPos = rxLengthSum;
  rxLengthSum = rxLengthSum + dataLengthTemp;
  if(rxLengthSum > RX_BD_FRAME_LENGTH_MAX)
  {
    destPos = 0;
    frameSyn = 0;
    rxLengthSum = dataLengthTemp;
  }

  copyDataFromRxBuff(ktUart0RxBuff1 + destPos,ktUart0RxBuff,dataPosTemp,dataLengthTemp,KT_UART0_RX_BUFF_LEN);
  
  if(rxLengthSum < 4) //������С���ݰ�
    return 2;
  
  if(frameSyn == 0)
  {
    for(i = 0; i < rxLengthSum - 1; i++)
    {
      if((ktUart0RxBuff1[i] == 0xEB) && (ktUart0RxBuff1[(i + 1)] == 0x90))
      {
        startPos = i;
        frameSyn = 1;
        break;
      }   
    }
    
    if(frameSyn == 0)   //û�ҵ�֡ͷ���ص���ʼλ��
    {
      rxLengthSum = 0;
      return 3;
    }
    
    if((frameSyn == 1) && (startPos > 0))  //ͬ���ɹ�������֡ͷ���м�λ��
    {
      rxLengthSum = rxLengthSum - startPos;
      memcpy(ktUart0RxBuff1,ktUart0RxBuff1 + startPos,rxLengthSum);
    }
  }
  
  if(frameSyn == 1)
  {
    rxFrameLength = ktUart0RxBuff1[2] + 3;
    if(rxFrameLength > rxLengthSum)  //û��ȫ
      return 4;
    
    rxLengthSum = 0;
    frameSyn = 0;
    
    if(ktUart0RxBuff1[rxFrameLength - 1] == CheckSum(ktUart0RxBuff1,rxFrameLength - 1))
    {
      return 0;
    } 
    else
      return 5;  
  } 
  
  return 6;
}
                                                

void rxBdFrameDeal()
{
  if(0 == getRxBdFrame())   //����������ݰ�
  { 
    ktUart0DMAWaitIdleWithTimeout(1);  //�첽���ͣ���������buff֮ǰ���豣֤֮ǰ��DMA�������
    
    if(ktUart0RxBuff1[3] == 0x01)
    { 
      
      Rec_Data01 = ktUart0RxBuff1[4];    
      if((Rec_Data01 & 0xFF)==0x03)     /*0x03  --������״̬�����˲�*/
      {
        FilterFlag = VALID;
      }
      else
      {
        FilterFlag = INVALID;
      }     
      
      if(Rec_Data01 == 0x08)
      {
        ktFrequency[0].sendFrequencyHz  = 20;
        ktFrequency[0].calFrequencyHz = 20;
      } 
      
      else if((Rec_Data01 == 0x00) || (Rec_Data01 == 0x02))
      {
        ktFrequency[0].sendFrequencyHz  = 1; 
        ktFrequency[0].calFrequencyHz = 1;
      }
      else
      {
        ktFrequency[0].sendFrequencyHz  = BD_SEND_FREQ_Hz; 
        ktFrequency[0].calFrequencyHz = BD_CALC_FREQ_Hz;
      }

      write_Rec_Data01_to_flash();
      
      makeStateCheckFrame();
      ktUart0DMASend(ktUart0TxLength);
      
    }
    
    if(ktUart0RxBuff1[3] == 0x08)
    {
      makeProductStateFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    if(ktUart0RxBuff1[3] == 0x04)
    {
      makeStateCheckFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    if(ktUart0RxBuff1[3] == 0x02)
    {
      makeProNumCheckFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    
    if(ktUart0RxBuff1[3] == 0x03)
    {  
      ktUart0SendEn = 0;
      makeCmdBackFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    
    if(ktUart0RxBuff1[3] == 0x05)
    { 
      ktUart0SendEn = 1;
    }
  }
  
}


//������֤
void makeYzFrame()
{
  makeBdFrame();
}


void rxYzFrameDeal()
{
  
  if(0 == getRxBdFrame())   //����������ݰ�
  {
    ktUart0DMAWaitIdleWithTimeout(1);  //�첽���ͣ���������buff֮ǰ���豣֤֮ǰ��DMA�������
    
    if(ktUart0RxBuff1[3] == 0x08)
    {
      makeProductStateFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    if(ktUart0RxBuff1[3] == 0x04)
    {
      makeStateCheckFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    if(ktUart0RxBuff1[3] == 0x02)
    {
      makeProNumCheckFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    
    if(ktUart0RxBuff1[3] == 0x03)
    {  
      ktUart0SendEn = 0;
      makeCmdBackFrame();
      ktUart0DMASend(ktUart0TxLength);
    }
    
    if(ktUart0RxBuff1[3] == 0x05)
    { 
      ktUart0SendEn = 1;
    }
  }
}





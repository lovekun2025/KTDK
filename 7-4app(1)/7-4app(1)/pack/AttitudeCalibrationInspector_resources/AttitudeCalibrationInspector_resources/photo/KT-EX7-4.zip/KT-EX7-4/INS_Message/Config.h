#ifndef CONFIG_H_20180628151042
#define CONFIG_H_20180628151042
/**
 * @file Config.h
 * @author Qiaoyy@xlnav.com
 * @date 2018-06-28
 * @brief  �������ù���
 * Copyright (c) 2018 XiLang Co. Ltd.
 * All rights reserved.
 */
 
/* Includes ------------------------------------------------------------------*/
#include "Global.h"

/* Exported macro ------------------------------------------------------------*/
#define CONFIG_TABLE_MARKER_CV24				0xFFFF1000
#define CONFIG_TABLE_MARKER_CV24_V1001	0xFFFF1001

#define CONFIG_UART_STOPBITS_1          ((uint32_t)0x00000000U)
#define CONFIG_UART_STOPBITS_2          ((uint32_t)0x00000001U)

#define CONFIG_UART_PARITY_NONE         ((uint32_t)0x00000000U)
#define CONFIG_UART_PARITY_EVEN         ((uint32_t)0x00000001U)
#define CONFIG_UART_PARITY_ODD          ((uint32_t)0x00000002U)

#define CONFIG_UART_WORDLENGTH_7B       ((uint32_t)0x0001U)
#define CONFIG_UART_WORDLENGTH_8B       ((uint32_t)0x0000U)
#define CONFIG_UART_WORDLENGTH_9B       ((uint32_t)0x0002U)

#define IS_COM_BAUDRATE(rate) ((rate==9600)||(rate==19200)||(rate==38400)||(rate==57600)||(rate==115200)||(rate==230400)||(rate==460800))
#define IS_CAN_BAUDRATE(rate) ((rate==250)||(rate==500)||(rate==1000))
#define IS_VEL_SOURCE(vel) ((vel==CONFIG_VEL_SOURCE_DR)||(vel==CONFIG_VEL_SOURCE_GNSS))
#define IS_START_METHOD(met) ((met==CONFIG_START_METHOD_VEL)||(met==CONFIG_START_METHOD_DA)||(met==CONFIG_START_METHOD_CMD))
#define IS_SERIAL_NUMBER1(sn) ((sn>0)||(sn<=99))
#define IS_SERIAL_NUMBER2(sn) ((sn>0)||(sn<=999))
/* Exported types ------------------------------------------------------------*/ 
typedef struct
{
	uint32_t ulMarker;					//!< ������ʶ���ֶ�
	uint32_t ulUart1Baudrate;
	uint32_t ulFre;
	// �궨���� 
	////////////////////////  Gyro Para(3 paras)
    float Gyro_Kg[3];
    float Gyro_Kgn[3];
    float Gyro_DF[3];
	float Gyro_E[9];
	float Gyro_En[9];
    
	////////////////////////  Acc Para(15 paras)
	float Acc_Kap[3];
    float Acc_k0[3];
    float Acc_k[9];

	////////////////////////  Mag Para(15 paras)
    float Mag_Kap[3];
    float Mag_k0[3];
    float Mag_k[9];
	float Mag_Kap_1[3];
	float Mag_k0_1[3];
	float Mag_k_1[9];
	////////////////////////  SatAten Para(3 paras)
	float Sat_ks[3];
	
	float Mag_lamda;
	float Mag_B;
	float Mag_h;
	float Mag_Date;
	
	float Mag_Dec;
	float Mag_Inc;
	float Mag_Str;
	
	uint32_t CalibrationFlag;//0xFFFFFFFF:�ѱ궨, 0x00000000:δ�궨
	
	/////////////////////// Reserved(6 paras) 
	uint32_t ulIsNavDataSend;
	uint32_t ulIsImuDataSend;
	uint32_t ulIsMagDataSend;
	uint32_t ulIsOnlyNavData;
	uint32_t ulSerialNumber1;
	uint32_t ulSerialNumber2;
	float fluxgate[15];   //��ͨ��28�ȱ궨����
	float MagDecl;       //��ƫ������
	float MagIncl;       //���������
	uint32_t ulFreNav;	//ŷ���Ƿ���Ƶ��
	uint32_t ulFreImu;	//imu����Ƶ��
	uint32_t ulFreMag;	//��ͨ������
	uint32_t ulMagCalibStatus;	//�Ƿ���д�ͨ��ԭʼ������������б궨
        uint32_t ulMag_iic_uart;
	uint32_t ulReserved[138];
	uint32_t ulCrcCheck;				//!< 32λ�ۼ�У���
}ConfigTabelTypeDef;

/* Exported constants --------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
int LoadConfig(void);
int SaveConfig(void);
ConfigTabelTypeDef* GetConfigTable(void);
void InitConfigTable(ConfigTabelTypeDef* pConfig);
int CheckConfigTable(ConfigTabelTypeDef* pConfig);
void CalculateConfigTableCheckSum(ConfigTabelTypeDef* pConfig);
int ReadConfigTable(ConfigTabelTypeDef* pConfig);
int WriteConfigTable(ConfigTabelTypeDef* pConfig);
int SaveCalibrationResult();
void SetNavParameter();

void ReceiveMagData(uint8_t DataByte);
#endif
/************************ (C) COPYRIGHT XiLang CO. Ltd. *******END OF FILE*****/

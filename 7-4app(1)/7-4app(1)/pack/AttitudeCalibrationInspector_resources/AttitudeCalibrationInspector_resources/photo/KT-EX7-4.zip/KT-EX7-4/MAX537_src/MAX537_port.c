#include "includes.h"
#include "MAX537_port.h" 


const MAX537csMap_s MAX537csMap[MAX537_NUM] = 
{

  {MAX537_CS1_PORT,MAX537_CS1_PIN}, 

#if MAX537_NUM > 1
  {MAX537_CS2_PORT,MAX537_CS2_PIN},
#endif
  
#if MAX537_NUM > 2  
  {MAX537_CS3_PORT,MAX537_CS3_PIN}, 
#endif
  
#if MAX537_NUM > 3  
  {MAX537_CS4_PORT,MAX537_CS4_PIN}, 
#endif
  
#if MAX537_NUM > 4  
  {MAX537_CS5_PORT,MAX537_CS5_PIN}, 
#endif
  
};


#ifdef MAX537_ST_F103_SPI

void MAX537_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(statusTemp == 0)  
    gpio_bit_reset(MAX537csMap[csNum].csPort,MAX537csMap[csNum].csPin);
  else
    gpio_bit_set(MAX537csMap[csNum].csPort,MAX537csMap[csNum].csPin);

}


void MAX537_Write_Read(uint16_t wrData,uint16_t *rdData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdDataTemp = 0;
  uint16_t *rdDataPt = rdData;
  

  wrDataTemp = wrData;
  
  while(RESET == spi_i2s_flag_get(MAX537_SPI, SPI_FLAG_TBE));
  spi_i2s_data_transmit(MAX537_SPI, wrDataTemp);
  while(RESET == spi_i2s_flag_get(MAX537_SPI, SPI_FLAG_RBNE));
  rdDataTemp = spi_i2s_data_receive(MAX537_SPI);
  
  *rdDataPt =  rdDataTemp;

}

/*******************************************************************************
* ˵�����ֲ���û�У�ʵ����Ҫ700ms���ܳ�����
*******************************************************************************/
void MAX537_Reset()
{
  gpio_bit_reset (MAX537_ENABLE_PORT, MAX537_ENABLE_PIN);   
  delay_1ms(1);
  gpio_bit_set (MAX537_ENABLE_PORT, MAX537_ENABLE_PIN);   
  
}

#endif


#ifdef MAX537_GD_F103_SPI

void MAX537_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(statusTemp == 0)  
    gpio_bit_reset(MAX537csMap[csNum].csPort,MAX537csMap[csNum].csPin);
  else
    gpio_bit_set(MAX537csMap[csNum].csPort,MAX537csMap[csNum].csPin);

}


void MAX537_Write_Read(uint16_t wrData,uint16_t *rdData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdDataTemp = 0;
  uint16_t *rdDataPt = rdData;
  

  wrDataTemp = wrData;
  
  while(RESET == spi_i2s_flag_get(MAX537_SPI, SPI_FLAG_TBE));
  spi_i2s_data_transmit(MAX537_SPI, wrDataTemp);
  while(RESET == spi_i2s_flag_get(MAX537_SPI, SPI_FLAG_RBNE));
  rdDataTemp = spi_i2s_data_receive(MAX537_SPI);
  
  *rdDataPt =  rdDataTemp;

}

/*******************************************************************************
* ˵�����ֲ���û�У�ʵ����Ҫ700ms���ܳ�����
*******************************************************************************/
void MAX537_Reset()
{
  gpio_bit_reset (MAX537_ENABLE_PORT, MAX537_ENABLE_PIN);   
  delay_1ms(1);
  gpio_bit_set (MAX537_ENABLE_PORT, MAX537_ENABLE_PIN);   
  
}

#endif



#ifdef MAX537_GD_F405_SPI

void MAX537_CS_Set(uint8_t csNum, uint8_t ioStatus)
{
  uint8_t statusTemp = 0;
  statusTemp = ioStatus;
  
  if(statusTemp == 0)  
    GPIO_ResetBits(MAX537csMap[csNum].csPort,MAX537csMap[csNum].csPin);
  else
    GPIO_SetBits(MAX537csMap[csNum].csPort,MAX537csMap[csNum].csPin);

}

void MAX537_Write_Read(uint16_t wrData,uint16_t *rdData)
{
  uint16_t wrDataTemp = 0;
  uint16_t rdDataTemp = 0;
  uint16_t *rdDataPt = rdData;
  
  wrDataTemp = wrData;
  
  while (SPI_I2S_GetFlagStatus(MAX537_SPI, SPI_I2S_FLAG_TXE) == RESET);
  SPI_I2S_SendData(MAX537_SPI, wrDataTemp);
  while (SPI_I2S_GetFlagStatus(MAX537_SPI, SPI_I2S_FLAG_RXNE) == RESET);
  rdDataTemp = SPI_I2S_ReceiveData(MAX537_SPI);
  
  *rdDataPt =  rdDataTemp;
}

/*******************************************************************************
* ˵�����ֲ���û�У�ʵ����Ҫ700ms���ܳ�����
*******************************************************************************/
void MAX537_Reset()
{
  GPIO_ResetBits (MAX537_ENABLE_PORT, MAX537_ENABLE_PIN);   
  delay_1ms(1);
  GPIO_SetBits (MAX537_ENABLE_PORT, MAX537_ENABLE_PIN);   
  
}

#endif

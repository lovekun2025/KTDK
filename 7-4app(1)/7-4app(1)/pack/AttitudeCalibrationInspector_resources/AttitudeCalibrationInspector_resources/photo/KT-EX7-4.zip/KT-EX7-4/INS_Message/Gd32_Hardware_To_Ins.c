#include "Global.h"
#include "DatagramFrame.h"
#include "msg_QsensCmd.h"
#include "Config.h"
#include "Gd32_Hardware_To_Ins.h"
//#include "iic.h"
#include "ShenHaiLan.h"
#include "ktUart.h"
#include "DataTypeConverter.h"
#include "nav_interface.h"
#include "includes.h"
///////////////////////////////////////////////////////////////
TRANSPORT_LAYER_DEFINE_BEGIN(USART1_FRAME)
	QSENS_CMD_MAPPING_DEFINE
	QSENS_715_MAPPING_DEFINE
	QSENS_BIN_PROTOCOL_MAPPING_DEFINE
TRANSPORT_LAYER_DEFINE_END

TRANSPORT_LAYER_DEFINE_BEGIN(USART2_FRAME)
	QSENS_CMD_MAPPING_DEFINE
	QSENS_715_MAPPING_DEFINE
	QSENS_BIN_PROTOCOL_MAPPING_DEFINE
TRANSPORT_LAYER_DEFINE_END

TRANSPORT_LAYER_DEFINE_BEGIN(USART3_FRAME)
	QSENS_MAG_MAPPING_DEFINE
TRANSPORT_LAYER_DEFINE_END

CONSTRUCT_CIRCULAR_BUFFER_MEMORY_POOL(g_USART1_Buffer, 128);
CONSTRUCT_CIRCULAR_BUFFER_MEMORY_POOL(g_USART2_Buffer, 128);
//CONSTRUCT_CIRCULAR_BUFFER_MEMORY_POOL(g_USART3_Buffer, 128);
CONSTRUCT_DMA_CIRCULAR_BUFFER_MEMORY_POOL(g_USART3_Buffer, 1024 ,*DMA1_Stream1);

CONSTRUCT_PARSE_PARAM_MEMORY_POOL(g_Usart1Parse, 128, USART1_FRAME, 1);
CONSTRUCT_PARSE_PARAM_MEMORY_POOL(g_Usart2Parse, 128, USART2_FRAME, 2);
CONSTRUCT_PARSE_PARAM_MEMORY_POOL(g_Usart3Parse, 1024, USART3_FRAME, 3);

void init_FrameParse(void)
{
  ClearCircularBuffer(&g_USART1_Buffer);
  ClearCircularBuffer(&g_USART2_Buffer);

  InitFrameParse(&g_Usart1Parse, 0, 0);
  InitFrameParse(&g_Usart2Parse, 0, 0);  
//  InitFrameParse(&g_Usart3Parse, 0, 0);    


}


void ParseFrameUsart1(void)
{
	ParseFrame(&g_USART1_Buffer, &g_Usart1Parse, 1024);
}

void ParseFrameUsart2(void)
{
	ParseFrame(&g_USART2_Buffer, &g_Usart2Parse, 1024);
}

void ParseFrameUsart3(void)
{
	//ParseFrame(&g_USART3_Buffer, &g_Usart3Parse, 1024);
	ParseFrame_DMA(&g_USART3_Buffer, &g_Usart3Parse, 1024*13);
}
/*
����1 422�ʹ���2 485 �Ĵ�������ins����ָ����Ӧ
*/

void PrintUartMessage(unsigned int portId, char* string, int limit)
{

	switch(portId)
	{
		case 1:
			while(*string != '\0')
			{
                               while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);
				USART_SendData(USART1,*string++);
			}
			break;
		case 2:
			USART_485_Mode_Tx();
			while(*string != '\0')
			{
				USART_SendData(USART2,*string++);
				while(USART_GetFlagStatus(USART2,USART_FLAG_TC)==RESET);
			}
			USART_485_Mode_Rx();
			break;
		default:
			break;
	}
}
//void make_u16_LH(uint16_t source,uint8_t *destination)
//{
//  uint8_t* p;
//  p=(uint8_t*)&source;
//  
//  *(destination+0) = *(p+0);
//  *(destination+1) = *(p+1);
//}
//
//void make_u32_LH(uint32_t source,uint8_t *destination)
//{
//  uint8_t* p;
//  p=(uint8_t*)&source;
//  
//  *(destination+0) = *(p+0);
//  *(destination+1) = *(p+1);
//  *(destination+2) = *(p+2);
//  *(destination+3) = *(p+3); 
//}  
//void make_F32_LH(float source,uint8_t *destination)
//{
//  uint8_t* p;
//  p=(uint8_t*)&source;
//  
//  *(destination+0) = *(p+0);
//  *(destination+1) = *(p+1);
//  *(destination+2) = *(p+2);
//  *(destination+3) = *(p+3);      
//}
uint16_t CheckSumCrc(uint8_t *buff,uint8_t len)
{
	uint16_t poly = 0x8408, crc16 = 0;
	uint8_t carry;
	int i;
	uint8_t i_bits;
	for (i = 0; i <len; i++)
	{
		crc16 = (uint16_t)(crc16 ^ buff[i]);
		for (i_bits = 0; i_bits < 8; i_bits++)
		{
			carry = (uint8_t)(crc16 & 1);
			crc16 = (uint16_t)(crc16 / 2);
			if (carry == 1)
			{
				crc16 = (uint16_t)(crc16 ^ poly);
			}
		}
	}
  	return(crc16);
}







int NavDataLen = 41;
int ImuDataLen = 67;
int MagDataLen = 39;
extern nav_QSENS_NavData1 *p_NavData;
extern unsigned short int iic_value[4]; 
//extern float gauss_form_voltage[3];
extern int32_t ShenHaiLan_MagBuff[4];// UART:X Y Z ������
uint8_t tx_buff[200];
/******************************************/
/*                ���ݴ��                */
/*    ��������ݰ������ݰ���ID���й�      */
/******************************************/
extern int navDataCouter;
void Send_Data()
{
	static uint32_t navCounter = 0;
	static uint32_t imuCounter = 0;
	static uint32_t magCounter = 0;
	uint16_t crc16 = 0;
	int data_length = 0;
	ConfigTabelTypeDef* pConfig;
	pConfig = GetConfigTable();
    if(pConfig->ulIsOnlyNavData == 1)
    {
        tx_buff[0+data_length] = 0xFF;
        tx_buff[1+data_length] = 0x5A;
        tx_buff[2+data_length] = 0x06;
        tx_buff[3+data_length] = 0x00;
        tx_buff[4+data_length] = 0x20;
        tx_buff[5+data_length] = 0x00;
        make_uI32_LH(p_NavData->uTNav,&tx_buff[6+data_length]);
        make_F32_LH(p_NavData->fRoll, &tx_buff[10+data_length],1,21000000);
        make_F32_LH(p_NavData->fPitch, &tx_buff[14+data_length],1,21000000);
        make_F32_LH(p_NavData->fYaw, &tx_buff[18+data_length],1,21000000);
        make_F32_LH(p_NavData->fPRoll, &tx_buff[22+data_length],1,21000000);
        make_F32_LH(p_NavData->fPPitch, &tx_buff[26+data_length],1,21000000);
        make_F32_LH(p_NavData->fPYaw, &tx_buff[30+data_length],1,21000000);
//		make_u32_LH(p_NavData->status,&tx_buff[34+data_length]);
        tx_buff[34+data_length] = 0x32;
        tx_buff[35+data_length] = 0x03;
        if(pConfig->CalibrationFlag == 0xFFFFFFFF)
        {
          tx_buff[36+data_length] = 0x02;
          tx_buff[37+data_length] = 0x00;
        }
        else
        {
          make_u16_LH((uint16_t)p_NavData->status,&tx_buff[36+data_length]);
        }
        
        crc16 = CheckSumCrc(&tx_buff[2+data_length],36);
        make_u16_LH(crc16, &tx_buff[38+data_length]);
        tx_buff[40+data_length] = 0x33;
        data_length += NavDataLen;
        
        pConfig->ulIsOnlyNavData = 0;
    }
    else
    {
      //IMU����
      if(pConfig->ulIsImuDataSend == 1)
      {
		if(imuCounter % (uint32_t)(100 / pConfig->ulFreImu) == 0)
		{
			imuCounter = 0;
			tx_buff[0+data_length] = 0xFF;
			tx_buff[1+data_length] = 0x5A;
			tx_buff[2+data_length] = 0x03;
			tx_buff[3+data_length] = 0x00;
			tx_buff[4+data_length] = 0x3A;
			tx_buff[5+data_length] = 0x00;
			make_uI32_LH(p_NavData->uTImu,&tx_buff[6+data_length]);
			make_u16_LH(p_NavData->usFImu, &tx_buff[10+data_length]);
			make_F32_LH(p_NavData->fAcc[0], &tx_buff[12+data_length],1,21000000);
			make_F32_LH(p_NavData->fAcc[1], &tx_buff[16+data_length],1,21000000);
			make_F32_LH(p_NavData->fAcc[2], &tx_buff[20+data_length],1,21000000);
			make_F32_LH(p_NavData->fGyro[0], &tx_buff[24+data_length],1,21000000);
			make_F32_LH(p_NavData->fGyro[1], &tx_buff[28+data_length],1,21000000);
			make_F32_LH(p_NavData->fGyro[2], &tx_buff[32+data_length],1,21000000);
			make_F32_LH(InertialDataIns[6], &tx_buff[36+data_length],1,21000000);//p_NavData->fTc
			make_F32_LH(p_NavData->fdV[0], &tx_buff[40+data_length],1,21000000);
			make_F32_LH(p_NavData->fdV[1], &tx_buff[44+data_length],1,21000000);
			make_F32_LH(p_NavData->fdV[2], &tx_buff[48+data_length],1,21000000);
			make_F32_LH(p_NavData->fdw[0], &tx_buff[52+data_length],1,21000000);
			make_F32_LH(p_NavData->fdw[1], &tx_buff[56+data_length],1,21000000);
			make_F32_LH(p_NavData->fdw[2], &tx_buff[60+data_length],1,21000000);
			
			crc16 = CheckSumCrc(&tx_buff[2+data_length],62);
			make_u16_LH(crc16, &tx_buff[64+data_length]);
			tx_buff[66+data_length] = 0x33;
			data_length += ImuDataLen;
		}
      }
      
      //�ش�����
      if(pConfig->ulIsMagDataSend == 1)
      {
		if(magCounter % (uint32_t)(100 / pConfig->ulFreMag) == 0)
		{
			magCounter = 0;
			tx_buff[0+data_length] = 0xFF;
			tx_buff[1+data_length] = 0x5A;
			tx_buff[2+data_length] = 0x04;
			tx_buff[3+data_length] = 0x00;
			tx_buff[4+data_length] = 0x1E;
			tx_buff[5+data_length] = 0x00;
			p_NavData->usFMag = 1;
			make_uI32_LH(p_NavData->uTMag,&tx_buff[6+data_length]);
			make_u16_LH(p_NavData->usFMag, &tx_buff[10+data_length]);

			if(pConfig->ulMagCalibStatus == 0)
			{
//				make_F32_LH(gauss_form_voltage[0]*100000, &tx_buff[12+data_length],1,21000000);
//				make_F32_LH(gauss_form_voltage[1]*100000, &tx_buff[16+data_length],1,21000000);
//				make_F32_LH(gauss_form_voltage[2]*100000, &tx_buff[20+data_length],1,21000000);
			}
			else
			{
                          if(pConfig->ulMag_iic_uart ==0)
                          {
				make_F32_LH(iic_value[0], &tx_buff[12+data_length],1,21000000);
				make_F32_LH(iic_value[1], &tx_buff[16+data_length],1,21000000);
				make_F32_LH(iic_value[2], &tx_buff[20+data_length],1,21000000);
                          }
                          if(pConfig->ulMag_iic_uart == 1)
                          {
                                make_F32_LH((float)ShenHaiLan_MagBuff[0], &tx_buff[12+data_length],1,21000000);
				make_F32_LH((float)ShenHaiLan_MagBuff[1], &tx_buff[16+data_length],1,21000000);
				make_F32_LH((float)ShenHaiLan_MagBuff[2], &tx_buff[20+data_length],1,21000000);
                          }  
			}
			make_F32_LH(p_NavData->fMAcc[0], &tx_buff[24+data_length],1,21000000);
			make_F32_LH(p_NavData->fMAcc[1], &tx_buff[28+data_length],1,21000000);
			make_F32_LH(p_NavData->fMAcc[2], &tx_buff[32+data_length],1,21000000);
			
			crc16 = CheckSumCrc(&tx_buff[2+data_length],34);
			make_u16_LH(crc16, &tx_buff[36+data_length]);
			tx_buff[38+data_length] = 0x33;
			data_length += MagDataLen;
		  }
	  }
	  //ŷ��������
	  if(pConfig->ulIsNavDataSend == 1)
      {
		if(navCounter % (uint32_t)(100 / pConfig->ulFreNav) == 0)
		{
			navCounter = 0;
			tx_buff[0+data_length] = 0xFF;
			tx_buff[1+data_length] = 0x5A;
			tx_buff[2+data_length] = 0x06;
			tx_buff[3+data_length] = 0x00;
			tx_buff[4+data_length] = 0x20;
			tx_buff[5+data_length] = 0x00;
			make_uI32_LH(p_NavData->uTNav,&tx_buff[6+data_length]);
			make_F32_LH(p_NavData->fRoll, &tx_buff[10+data_length],1,21000000);
			make_F32_LH(p_NavData->fPitch, &tx_buff[14+data_length],1,21000000);
			make_F32_LH(p_NavData->fYaw, &tx_buff[18+data_length],1,21000000);
			make_F32_LH(p_NavData->fPRoll, &tx_buff[22+data_length],1,21000000);
			make_F32_LH(p_NavData->fPPitch, &tx_buff[26+data_length],1,21000000);
			make_F32_LH(p_NavData->fPYaw, &tx_buff[30+data_length],1,21000000);
//			make_u32_LH(p_NavData->status,&tx_buff[34+data_length]);
			tx_buff[34+data_length] = 0x32;
			tx_buff[35+data_length] = 0x03;
			if(pConfig->CalibrationFlag == 0xFFFFFFFF)
			{
				tx_buff[36+data_length] = 0x02;
				tx_buff[37+data_length] = 0x00;
			}
			else
			{
				make_u16_LH((uint16_t)p_NavData->status,&tx_buff[36+data_length]);
			}

			crc16 = CheckSumCrc(&tx_buff[2+data_length],36);
			make_u16_LH(crc16, &tx_buff[38+data_length]);
			tx_buff[40+data_length] = 0x33;
			data_length += NavDataLen;
		}
      }
    }

    
  
  if(data_length > 0)
  {
    USART_422_DMA_Send(data_length);
    USART_485_DMA_Send(data_length);
  }
} 








//




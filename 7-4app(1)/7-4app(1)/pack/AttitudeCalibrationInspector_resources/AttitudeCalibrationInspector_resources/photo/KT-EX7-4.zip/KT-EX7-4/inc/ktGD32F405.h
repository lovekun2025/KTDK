#ifndef __KT_GD32F405_H
#define __KT_GD32F405_H



//GYRO X
#define SPI_GYROX_CS_PIN          GPIO_Pin_11 
#define SPI_GYROX_CS_PORT         GPIOB
#define SPI_GYROX_CS_CLK          RCC_AHB1Periph_GPIOB 
//GYRO Z
#define SPI_GYROZ_CS_PIN          GPIO_Pin_2 
#define SPI_GYROZ_CS_PORT         GPIOA
#define SPI_GYROZ_CS_CLK          RCC_AHB1Periph_GPIOA 
//GYRO Y
#define SPI_GYROY_CS_PIN          GPIO_Pin_9 
#define SPI_GYROY_CS_PORT         GPIOC
#define SPI_GYROY_CS_CLK          RCC_AHB1Periph_GPIOC 


void GPIO_config();
void GPIO_config_1();
void NVIC_config();
void write_Rec_Data01_to_flash();


#endif

/******************* (C) COPYRIGHT 2010 BEIJINGKAITUO *****END OF FILE****/



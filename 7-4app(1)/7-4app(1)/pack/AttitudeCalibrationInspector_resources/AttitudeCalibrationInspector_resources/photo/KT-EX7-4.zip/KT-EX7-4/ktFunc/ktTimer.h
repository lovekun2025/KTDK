#ifndef __KT_TIMER_H
#define __KT_TIMER_H


#if defined(GD32E103V_MD) || defined(GD32F10X_MD)

#define KT_TIMER0_IRQn        TIMER2_IRQn
#define KT_TIMER0_IRQHandler  TIMER2_IRQHandler

#endif


#ifdef STM32F40XX

#define KT_TIMER0_IRQn        TIM2_IRQn
#define KT_TIMER0_IRQHandler  TIM2_IRQHandler

#endif


void ktTimer0Init();
void ktTimer0UpdateIntEnable();
void TIM3_Int_Init(u16 arr,u16 psc);

#endif
#ifndef CMDFRAME_H_20175132143
#define CMDFRAME_H_20175132143
/**
* @file
* @author Qiaoyy@xlnav.com
* @date
* @brief
* Copyright (c) 2018 XiLang Co. Ltd.
* All rights reserved.
*/

/* Includes ------------------------------------------------------------------*/
#include "Global.h"
#include "Config.h"

#define CMD_KEY_MAX_NUM 16
#define CMD_KEY_MAX_LEN 16
/* Exported types ------------------------------------------------------------*/
typedef int(*CommandFunc)(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);
typedef int(*ShowFunc)(ConfigTabelTypeDef* config, uint32_t nSource);

typedef struct
{
	char CommandKey[CMD_KEY_MAX_LEN];
	CommandFunc CallBackFunc;
	ShowFunc ShowCallBack;
	int EnableFlag;
	int VersionDefine;
}CommandMap;
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define COMMAND_SETUP_BEGIN(command_list) CommandMap command_list[] = {
#define COMMAND_SETUP_END {"", 0x00000000, 0x00000000, FUNC_DISABLE, FUNC_DISABLE}};
#define COMMAND_SET(cmd, fun, show, ver) {cmd, fun, show, FUNC_DISABLE, ver},
#define COMMAND_SETUP_NUMBER(table) ((sizeof(table)/sizeof(CommandMap))-1)                             
#define COMMAND_DECLARATION(cmd)  int cmd(int argn, char argc[CMD_KEY_MAX_NUM][CMD_KEY_MAX_LEN], uint32_t nSource);\
                                  int cmd##Show(ConfigTabelTypeDef* config, uint32_t nSource);

/* Exported functions --------------------------------------------------------*/
int CmdProcss(char* cmdWord, CommandMap* cmdMap, int cmdMapSize, char* strMessage, uint32_t nSource);
int EnableAllCommand(CommandMap* cmdMap, int cmdMapSize);
int DisableAllCommand(CommandMap* cmdMap, int cmdMapSize);
int EnableCommand(char* cmd, CommandMap* cmdMap, int cmdMapSize);
int DisableCommand(char* cmd, CommandMap* cmdMap, int cmdMapSize);
#endif
/************************ (C) COPYRIGHT XiLang CO. Ltd. *******END OF FILE*****/

/**
  ******************************************************************************
  * @file    ReadPara.C
  * @brief   Flash������ȡ.             
  ******************************************************************************
  * @attention
  *  V1.01 ȥ����CRC���񣬲�У�����ݣ��ô�����Ϊ��ʡ�ռ�ȥ��
  *  COPYRIGHT(c) 2021/12/29 V1.01 ���غ���
  *  COPYRIGHT(c) 2020/11/19 V1.00 ���غ���
  *
  * ���ܣ�������в����Ķ�д��
  * û�����ϵĲ������뵽FloatParaNull��ByteParaNull�����С�
  * Ŀǰ��������������Ժ���Ҫ�õ���ʱ����������C�ļ������¸������塣
  * ��C�ļ����������޸ġ�ARM�汾
  ******************************************************************************
  */ 
#ifndef  OS_MASTER_FILE
#include "Includes.h"
#endif
/**********************************************************
    CRC�����ݱ�
************************************************************/
/*
static unsigned int crc16_table[256]={
	0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7, 0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
	0x1231, 0x210,  0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6, 0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
	0x2462, 0x3443, 0x420,  0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485, 0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
	0x3653, 0x2672, 0x1611, 0x630,  0x76D7, 0x66F6, 0x5695, 0x46B4, 0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
	0x48C4, 0x58E5, 0x6886, 0x78A7, 0x840,  0x1861, 0x2802, 0x3823, 0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
	0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0xA50,  0x3A33, 0x2A12, 0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
	0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41, 0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
	0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70, 0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
	0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F, 0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
	0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E, 0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
	0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D, 0x34E2, 0x24C3, 0x14A0, 0x481,  0x7466, 0x6447, 0x5424, 0x4405,
	0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C, 0x26D3, 0x36F2, 0x691,  0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
	0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB, 0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x8E1,  0x3882, 0x28A3,
	0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A, 0x4A75, 0x5A54, 0x6A37, 0x7A16, 0xAF1,  0x1AD0, 0x2AB3, 0x3A92,
	0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9, 0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
	0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8, 0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0xED1,  0x1EF0
	};
*/
/*data receive and pos is the initial  position of data in the message buffer*/
float Flash_get_F32(uint8_t* receive,int pos)
{
  	float res=0.0;

#ifdef  DSP28_F2812      //dsp  16bits  	flash���ڴ泤�Ȳ�ͬ
        uint16_t *p = (uint16_t *)&res;      
	*(p+0) = (*(receive+pos+0)&0xFF) | (*(receive+pos+1)&0xFF)<<8;
	*(p+1) = (*(receive+pos+2)&0xFF) | (*(receive+pos+3)&0xFF)<<8;
#else                //arm    8bits
      uint8_t* p;
      p=(uint8_t*)&res;
      
      *(p+0) = *(receive+pos+0);
      *(p+1) = *(receive+pos+1);
      *(p+2) = *(receive+pos+2);
      *(p+3) = *(receive+pos+3);
#endif

  return res;
}

/*****************************************************************
    �Ծݰ�����CRC����
*****************************************************************/
/*
uint16_t CRC16(uint8_t *pch,int len)
{
  unsigned short tmp;

  uint16_t crc=0;
  crc_data[0] = 0;
  crc_data[1] = 0;
  while(len>0)
  {
    tmp=((crc>>8) & 0xff)^((*pch) & 0xff);
    crc=((crc<<8) & 0xff00)^crc16_table[tmp];
    pch++;
    len--;
  }  
  
  crc_data[0] = (crc>>8)&0xFF;
  crc_data[1] = crc&0xFF;
  
  return crc;
}  
*/
/*****************************************************************
    ��FLASH�еĲ�������CRC
*****************************************************************/
/*
uint16_t crc_calculate_Par(uint8_t data,uint16_t crc)
{
    uint16_t tmp;

    tmp=((crc>>8) & 0xff)^((data) & 0xff);
    crc=((crc<<8) & 0xff00)^crc16_table[tmp];

    return crc;
}  
*/
/**************��������������*****************/
void Reset_ReadPara()
{
  int i;
  uint8_t *Dest_Addr_Factory;
  uint8_t *Dest_Addr_USER;
  //uint16_t crc1=0,crc2=0;   
	
  Dest_Addr_Factory = (uint8_t *)(FLASH_PARA_FACTORY);
  Dest_Addr_USER    = (uint8_t *)(FLASH_PARA_USER);
  /*
  for(i=0;i<FLASH_CRC1_Address;i++)
  {
    crc1 = crc_calculate_Par(*(Dest_Addr_Factory+i),crc1);
  } 
  for(i=0;i<FLASH_CRC2_Address;i++)
  {
    crc2 = crc_calculate_Par(*(Dest_Addr_USER+i),crc2);
  } 
  
  if(crc1 == *(uint16_t*)(Dest_Addr_Factory+FLASH_CRC1_Address))
  {
    FlashStatus = VALID;
  }
  else 
  {
    FlashStatus = INVALID;
  } 
  //��ȡ�û�������
  if(crc2 == *(uint16_t*)(Dest_Addr_USER+FLASH_CRC2_Address))
  {
    FlashStatus = VALID;
  }
  else 
  {
    FlashStatus = INVALID;
  }
  */
  /*��Ʒ��Ϣ*/
  for(i=0;i<10;i++)
  {
    productID[i]   = ((uint8_t)(*(Dest_Addr_Factory+i)));
    productNum[i]  = ((uint8_t)(*(Dest_Addr_Factory+10+i))); 
    softwareVer[i] = ((uint8_t)(*(Dest_Addr_Factory+20+i))); 
    hardwareVer[i] = ((uint8_t)(*(Dest_Addr_Factory+30+i)));
    batchNum[i]    = ((uint8_t)(*(Dest_Addr_Factory+40+i)));
  }
  
  //��ȡFlash����   ��Ʒ����״̬����
  Rec_Data01 = (uint8_t)(*((uint8_t *)UserParmentAddress));	
  ImuStatus = (uint8_t)(*((uint8_t *)Dest_Addr_Factory+50));    //  ��Ʒ����״̬�ֿ���
  
  /*�ӱ���λ�²�*/ 
  ParaAcce.AcceTempCoef_X_Flag = (int)(*(Dest_Addr_Factory+51)&0xff);
  ParaAcce.AcceTempCoef_Y_Flag = (int)(*(Dest_Addr_Factory+52)&0xff);  
  ParaAcce.AcceTempCoef_Z_Flag = (int)(*(Dest_Addr_Factory+53)&0xff);
  
  ParaAcce.Acce_Temp1_X = Flash_get_F32(Dest_Addr_Factory,54);
  ParaAcce.Acce_Temp2_X = Flash_get_F32(Dest_Addr_Factory,58);
  ParaAcce.Acce_Temp3_X = Flash_get_F32(Dest_Addr_Factory,62);
  ParaAcce.Acce_Temp4_X = Flash_get_F32(Dest_Addr_Factory,66);
  ParaAcce.Acce_Temp5_X = Flash_get_F32(Dest_Addr_Factory,70);
  ParaAcce.Acce_Temp6_X = Flash_get_F32(Dest_Addr_Factory,74);
  ParaAcce.Acce_Temp7_X = Flash_get_F32(Dest_Addr_Factory,78);

  ParaAcce.AcceBias_D1_X1 = Flash_get_F32(Dest_Addr_Factory,82);
  ParaAcce.AcceBias_D1_X0 = Flash_get_F32(Dest_Addr_Factory,86);
  ParaAcce.AcceBias_D2_X1 = Flash_get_F32(Dest_Addr_Factory,90);
  ParaAcce.AcceBias_D2_X0 = Flash_get_F32(Dest_Addr_Factory,94);
  ParaAcce.AcceBias_D3_X1 = Flash_get_F32(Dest_Addr_Factory,98);
  ParaAcce.AcceBias_D3_X0 = Flash_get_F32(Dest_Addr_Factory,102);
  ParaAcce.AcceBias_D4_X1 = Flash_get_F32(Dest_Addr_Factory,106);
  ParaAcce.AcceBias_D4_X0 = Flash_get_F32(Dest_Addr_Factory,110);
  ParaAcce.AcceBias_D5_X1 = Flash_get_F32(Dest_Addr_Factory,114);
  ParaAcce.AcceBias_D5_X0 = Flash_get_F32(Dest_Addr_Factory,118);
  ParaAcce.AcceBias_D6_X1 = Flash_get_F32(Dest_Addr_Factory,122);
  ParaAcce.AcceBias_D6_X0 = Flash_get_F32(Dest_Addr_Factory,126);
  ParaAcce.AcceBias_D7_X1 = Flash_get_F32(Dest_Addr_Factory,130);
  ParaAcce.AcceBias_D7_X0 = Flash_get_F32(Dest_Addr_Factory,134);
  ParaAcce.AcceBias_D8_X1 = Flash_get_F32(Dest_Addr_Factory,138);
  ParaAcce.AcceBias_D8_X0 = Flash_get_F32(Dest_Addr_Factory,142);

  ParaAcce.Acce_Temp1_Y = Flash_get_F32(Dest_Addr_Factory,146);
  ParaAcce.Acce_Temp2_Y = Flash_get_F32(Dest_Addr_Factory,150);
  ParaAcce.Acce_Temp3_Y = Flash_get_F32(Dest_Addr_Factory,154);
  ParaAcce.Acce_Temp4_Y = Flash_get_F32(Dest_Addr_Factory,158);
  ParaAcce.Acce_Temp5_Y = Flash_get_F32(Dest_Addr_Factory,162);
  ParaAcce.Acce_Temp6_Y = Flash_get_F32(Dest_Addr_Factory,166);
  ParaAcce.Acce_Temp7_Y = Flash_get_F32(Dest_Addr_Factory,170);

  ParaAcce.AcceBias_D1_Y1 = Flash_get_F32(Dest_Addr_Factory,174);
  ParaAcce.AcceBias_D1_Y0 = Flash_get_F32(Dest_Addr_Factory,178);
  ParaAcce.AcceBias_D2_Y1 = Flash_get_F32(Dest_Addr_Factory,182);
  ParaAcce.AcceBias_D2_Y0 = Flash_get_F32(Dest_Addr_Factory,186);
  ParaAcce.AcceBias_D3_Y1 = Flash_get_F32(Dest_Addr_Factory,190);
  ParaAcce.AcceBias_D3_Y0 = Flash_get_F32(Dest_Addr_Factory,194);
  ParaAcce.AcceBias_D4_Y1 = Flash_get_F32(Dest_Addr_Factory,198);
  ParaAcce.AcceBias_D4_Y0 = Flash_get_F32(Dest_Addr_Factory,202);
  ParaAcce.AcceBias_D5_Y1 = Flash_get_F32(Dest_Addr_Factory,1087);
  ParaAcce.AcceBias_D5_Y0 = Flash_get_F32(Dest_Addr_Factory,1091);
  ParaAcce.AcceBias_D6_Y1 = Flash_get_F32(Dest_Addr_Factory,1095);
  ParaAcce.AcceBias_D6_Y0 = Flash_get_F32(Dest_Addr_Factory,1099);
  ParaAcce.AcceBias_D7_Y1 = Flash_get_F32(Dest_Addr_Factory,1103);
  ParaAcce.AcceBias_D7_Y0 = Flash_get_F32(Dest_Addr_Factory,1107);
  ParaAcce.AcceBias_D8_Y1 = Flash_get_F32(Dest_Addr_Factory,1111);
  ParaAcce.AcceBias_D8_Y0 = Flash_get_F32(Dest_Addr_Factory,1115);

  ParaAcce.Acce_Temp1_Z = Flash_get_F32(Dest_Addr_Factory,1119);
  ParaAcce.Acce_Temp2_Z = Flash_get_F32(Dest_Addr_Factory,1123);
  ParaAcce.Acce_Temp3_Z = Flash_get_F32(Dest_Addr_Factory,1127);
  ParaAcce.Acce_Temp4_Z = Flash_get_F32(Dest_Addr_Factory,1131);
  ParaAcce.Acce_Temp5_Z = Flash_get_F32(Dest_Addr_Factory,1135);
  ParaAcce.Acce_Temp6_Z = Flash_get_F32(Dest_Addr_Factory,1139);
  ParaAcce.Acce_Temp7_Z = Flash_get_F32(Dest_Addr_Factory,1143);

  ParaAcce.AcceBias_D1_Z1 = Flash_get_F32(Dest_Addr_Factory,1147);
  ParaAcce.AcceBias_D1_Z0 = Flash_get_F32(Dest_Addr_Factory,1151);
  ParaAcce.AcceBias_D2_Z1 = Flash_get_F32(Dest_Addr_Factory,1155);
  ParaAcce.AcceBias_D2_Z0 = Flash_get_F32(Dest_Addr_Factory,1159);
  ParaAcce.AcceBias_D3_Z1 = Flash_get_F32(Dest_Addr_Factory,1163);
  ParaAcce.AcceBias_D3_Z0 = Flash_get_F32(Dest_Addr_Factory,1167);
  ParaAcce.AcceBias_D4_Z1 = Flash_get_F32(Dest_Addr_Factory,1171);
  ParaAcce.AcceBias_D4_Z0 = Flash_get_F32(Dest_Addr_Factory,1175);
  ParaAcce.AcceBias_D5_Z1 = Flash_get_F32(Dest_Addr_Factory,1179);
  ParaAcce.AcceBias_D5_Z0 = Flash_get_F32(Dest_Addr_Factory,1183);
  ParaAcce.AcceBias_D6_Z1 = Flash_get_F32(Dest_Addr_Factory,1187);
  ParaAcce.AcceBias_D6_Z0 = Flash_get_F32(Dest_Addr_Factory,1191);
  ParaAcce.AcceBias_D7_Z1 = Flash_get_F32(Dest_Addr_Factory,1195);
  ParaAcce.AcceBias_D7_Z0 = Flash_get_F32(Dest_Addr_Factory,1199);
  ParaAcce.AcceBias_D8_Z1 = Flash_get_F32(Dest_Addr_Factory,1203);
  ParaAcce.AcceBias_D8_Z0 = Flash_get_F32(Dest_Addr_Factory,1207);
  
  /*�ӱ���������¶�ϵ��*/
  ParaAcce.AcceSF_X_Flag = (int)(*(Dest_Addr_Factory+210)&0xff);
  ParaAcce.AcceSF_Y_Flag = (int)(*(Dest_Addr_Factory+211)&0xff);  
  ParaAcce.AcceSF_Z_Flag = (int)(*(Dest_Addr_Factory+212)&0xff);
  
  ParaAcce.AcceSF_Temp_X = Flash_get_F32(Dest_Addr_Factory,213);
  ParaAcce.AcceSF_Temp_Y = Flash_get_F32(Dest_Addr_Factory,217);          
  ParaAcce.AcceSF_Temp_Z = Flash_get_F32(Dest_Addr_Factory,221);
  
  ParaAcce.AcceSFOT_X2 = Flash_get_F32(Dest_Addr_Factory,225);
  ParaAcce.AcceSFOT_X1 = Flash_get_F32(Dest_Addr_Factory,229);
  ParaAcce.AcceSFOT_X0 = Flash_get_F32(Dest_Addr_Factory,233);  
  
  ParaAcce.AcceSFDW_X2 = Flash_get_F32(Dest_Addr_Factory,237);
  ParaAcce.AcceSFDW_X1 = Flash_get_F32(Dest_Addr_Factory,241);
  ParaAcce.AcceSFDW_X0 = Flash_get_F32(Dest_Addr_Factory,245);  

  ParaAcce.AcceSFGW_X2 = Flash_get_F32(Dest_Addr_Factory,249);          
  ParaAcce.AcceSFGW_X1 = Flash_get_F32(Dest_Addr_Factory,253);
  ParaAcce.AcceSFGW_X0 = Flash_get_F32(Dest_Addr_Factory,257);
  
  ParaAcce.AcceSFOT_Y2 =   Flash_get_F32(Dest_Addr_Factory,261);
  ParaAcce.AcceSFOT_Y1 =   Flash_get_F32(Dest_Addr_Factory,265);
  ParaAcce.AcceSFOT_Y0 =   Flash_get_F32(Dest_Addr_Factory,269);
  
  ParaAcce.AcceSFDW_Y2 = Flash_get_F32(Dest_Addr_Factory,273);
  ParaAcce.AcceSFDW_Y1 = Flash_get_F32(Dest_Addr_Factory,277);
  ParaAcce.AcceSFDW_Y0 = Flash_get_F32(Dest_Addr_Factory,281);  

  ParaAcce.AcceSFGW_Y2 = Flash_get_F32(Dest_Addr_Factory,285);          
  ParaAcce.AcceSFGW_Y1 = Flash_get_F32(Dest_Addr_Factory,289);
  ParaAcce.AcceSFGW_Y0 = Flash_get_F32(Dest_Addr_Factory,293);
  
  ParaAcce.AcceSFOT_Z2 =   Flash_get_F32(Dest_Addr_Factory,297);
  ParaAcce.AcceSFOT_Z1 =   Flash_get_F32(Dest_Addr_Factory,301);
  ParaAcce.AcceSFOT_Z0 =   Flash_get_F32(Dest_Addr_Factory,305); 
  
  ParaAcce.AcceSFDW_Z2 = Flash_get_F32(Dest_Addr_Factory,309);
  ParaAcce.AcceSFDW_Z1 = Flash_get_F32(Dest_Addr_Factory,313);
  ParaAcce.AcceSFDW_Z0 = Flash_get_F32(Dest_Addr_Factory,317);  

  ParaAcce.AcceSFGW_Z2 = Flash_get_F32(Dest_Addr_Factory,321);          
  ParaAcce.AcceSFGW_Z1 = Flash_get_F32(Dest_Addr_Factory,325);
  ParaAcce.AcceSFGW_Z0 = Flash_get_F32(Dest_Addr_Factory,329);
  
/*�ӱ����±궨*/
  ParaAcce.AcceSF_X    =   Flash_get_F32(Dest_Addr_Factory,333);
  ParaAcce.AcceBias_X  =   Flash_get_F32(Dest_Addr_Factory,337);
  ParaAcce.AcceNT_X    =   Flash_get_F32(Dest_Addr_Factory,341);
  ParaAcce.AcceSF_Y    =   Flash_get_F32(Dest_Addr_Factory,345);
  ParaAcce.AcceBias_Y  =   Flash_get_F32(Dest_Addr_Factory,349);
  ParaAcce.AcceNT_Y    =   Flash_get_F32(Dest_Addr_Factory,353);
  ParaAcce.AcceSF_Z    =   Flash_get_F32(Dest_Addr_Factory,357);
  ParaAcce.AcceBias_Z  =   Flash_get_F32(Dest_Addr_Factory,361);  
  ParaAcce.AcceNT_Z    =   Flash_get_F32(Dest_Addr_Factory,365);
    
/*�ӱ���װ���*/
  ParaAcce.ACCE_THETA_YX = Flash_get_F32(Dest_Addr_Factory,369);
  ParaAcce.ACCE_THETA_ZX = Flash_get_F32(Dest_Addr_Factory,373);
  ParaAcce.ACCE_THETA_XY = Flash_get_F32(Dest_Addr_Factory,377);
  ParaAcce.ACCE_THETA_ZY = Flash_get_F32(Dest_Addr_Factory,381);
  ParaAcce.ACCE_THETA_XZ = Flash_get_F32(Dest_Addr_Factory,385);
  ParaAcce.ACCE_THETA_YZ = Flash_get_F32(Dest_Addr_Factory,389);
  
  ParaAcce.AcceX_sign_Flag = (int)(*(Dest_Addr_Factory+393)&0xff); 
  ParaAcce.AcceY_sign_Flag = (int)(*(Dest_Addr_Factory+394)&0xff); 
  ParaAcce.AcceZ_sign_Flag = (int)(*(Dest_Addr_Factory+395)&0xff); 
  
  /*�ӱ��ı�Ⱥ���λ��������ʱ����*/
  FloatParaNull[0] = Flash_get_F32(Dest_Addr_Factory,396);
  FloatParaNull[1] = Flash_get_F32(Dest_Addr_Factory,400);
  FloatParaNull[2] = Flash_get_F32(Dest_Addr_Factory,404);
  FloatParaNull[3] = Flash_get_F32(Dest_Addr_Factory,408);
  FloatParaNull[4] = Flash_get_F32(Dest_Addr_Factory,412);
  FloatParaNull[5] = Flash_get_F32(Dest_Addr_Factory,416);
  
 //������С���̼ӱ��Ĳ�����
  /*С�ӱ���λ�²�*/
  ParaQJ.AcceTempCoef_X2 = Flash_get_F32(Dest_Addr_Factory,420);
  ParaQJ.AcceTempCoef_X1 = Flash_get_F32(Dest_Addr_Factory,424);
  ParaQJ.AcceTempCoef_X0 = Flash_get_F32(Dest_Addr_Factory,428);
  
  ParaQJ.AcceTempCoef_Y2 = Flash_get_F32(Dest_Addr_Factory,432);
  ParaQJ.AcceTempCoef_Y1 = Flash_get_F32(Dest_Addr_Factory,436);
  ParaQJ.AcceTempCoef_Y0 = Flash_get_F32(Dest_Addr_Factory,440);
  
  ParaQJ.AcceTempCoef_Z2 = Flash_get_F32(Dest_Addr_Factory,444);
  ParaQJ.AcceTempCoef_Z1 = Flash_get_F32(Dest_Addr_Factory,448);
  ParaQJ.AcceTempCoef_Z0 = Flash_get_F32(Dest_Addr_Factory,452);
  
  /*�ӱ���������¶�ϵ��*/
  ParaQJ.AcceSFOT_X2 =   Flash_get_F32(Dest_Addr_Factory,456);
  ParaQJ.AcceSFOT_X1 =   Flash_get_F32(Dest_Addr_Factory,460);
  ParaQJ.AcceSFOT_X0 =   Flash_get_F32(Dest_Addr_Factory,464);
  
  ParaQJ.AcceSFOT_Y2 =   Flash_get_F32(Dest_Addr_Factory,468);
  ParaQJ.AcceSFOT_Y1 =   Flash_get_F32(Dest_Addr_Factory,472);
  ParaQJ.AcceSFOT_Y0 =   Flash_get_F32(Dest_Addr_Factory,476);
  
  ParaQJ.AcceSFOT_Z2 =   Flash_get_F32(Dest_Addr_Factory,480);
  ParaQJ.AcceSFOT_Z1 =   Flash_get_F32(Dest_Addr_Factory,484);
  ParaQJ.AcceSFOT_Z0 =   Flash_get_F32(Dest_Addr_Factory,488);
  
  /*�ӱ����±궨*/
  ParaQJ.AcceSF_X    =   Flash_get_F32(Dest_Addr_Factory,492);
  ParaQJ.AcceBias_X  =   Flash_get_F32(Dest_Addr_Factory,496);
  ParaQJ.AcceNT_X    =   Flash_get_F32(Dest_Addr_Factory,500);
  ParaQJ.AcceSF_Y    =   Flash_get_F32(Dest_Addr_Factory,504);
  ParaQJ.AcceBias_Y  =   Flash_get_F32(Dest_Addr_Factory,508);
  ParaQJ.AcceNT_Y    =   Flash_get_F32(Dest_Addr_Factory,512);
  ParaQJ.AcceSF_Z    =   Flash_get_F32(Dest_Addr_Factory,516);
  ParaQJ.AcceBias_Z  =   Flash_get_F32(Dest_Addr_Factory,520);
  ParaQJ.AcceNT_Z    =   Flash_get_F32(Dest_Addr_Factory,524);
  
  /*�ӱ���װ���*/
  ParaQJ.ACCE_THETA_YX = Flash_get_F32(Dest_Addr_Factory,528);
  ParaQJ.ACCE_THETA_ZX = Flash_get_F32(Dest_Addr_Factory,532);
  ParaQJ.ACCE_THETA_XY = Flash_get_F32(Dest_Addr_Factory,536);
  ParaQJ.ACCE_THETA_ZY = Flash_get_F32(Dest_Addr_Factory,540);
  ParaQJ.ACCE_THETA_XZ = Flash_get_F32(Dest_Addr_Factory,544);
  ParaQJ.ACCE_THETA_YZ = Flash_get_F32(Dest_Addr_Factory,548);  
    
  ParaQJ.AcceX_sign_Flag = (int)Flash_get_F32(Dest_Addr_Factory,552); 
  ParaQJ.AcceY_sign_Flag = (int)Flash_get_F32(Dest_Addr_Factory,556);
  ParaQJ.AcceZ_sign_Flag = (int)Flash_get_F32(Dest_Addr_Factory,560);
  
  ProductRange.AX_SCALE = Flash_get_F32(Dest_Addr_Factory,564);
  ProductRange.AY_SCALE = Flash_get_F32(Dest_Addr_Factory,568);
  ProductRange.AZ_SCALE = Flash_get_F32(Dest_Addr_Factory,572);  
  ProductRange.AX_FS_Z = Flash_get_F32(Dest_Addr_Factory,576);
  ProductRange.AX_FS_F = Flash_get_F32(Dest_Addr_Factory,580);
  ProductRange.AY_FS_Z = Flash_get_F32(Dest_Addr_Factory,584); 
  ProductRange.AY_FS_F = Flash_get_F32(Dest_Addr_Factory,588);     
  ProductRange.AZ_FS_Z = Flash_get_F32(Dest_Addr_Factory,592); 
  ProductRange.AZ_FS_F = Flash_get_F32(Dest_Addr_Factory,596);
        
/*����364�ֽڣ�ȫ0������*/

/*��ͨ�˲�������*/
  ParaFilter.LowPass_Gain  = Flash_get_F32(Dest_Addr_Factory,964);
  ParaFilter.LowPass_b     = Flash_get_F32(Dest_Addr_Factory,968);
  ParaFilter.LowPass_c     = Flash_get_F32(Dest_Addr_Factory,972);     
  
  /*�в��3�ζ���ʽ���*/
  ParaGyro.resPzX[0] =  Flash_get_F32(Dest_Addr_Factory,976); 
  ParaGyro.resPzX[1] =  Flash_get_F32(Dest_Addr_Factory,980);
  ParaGyro.resPzX[2] =  Flash_get_F32(Dest_Addr_Factory,984);
  ParaGyro.resPzX[3] =  Flash_get_F32(Dest_Addr_Factory,988);

  ParaGyro.resPfX[0] =  Flash_get_F32(Dest_Addr_Factory,992); 
  ParaGyro.resPfX[1] =  Flash_get_F32(Dest_Addr_Factory,996);
  ParaGyro.resPfX[2] =  Flash_get_F32(Dest_Addr_Factory,1000);
  ParaGyro.resPfX[3] =  Flash_get_F32(Dest_Addr_Factory,1004); 

  ParaGyro.resPzY[0] =  Flash_get_F32(Dest_Addr_Factory,1008); 
  ParaGyro.resPzY[1] =  Flash_get_F32(Dest_Addr_Factory,1012);
  ParaGyro.resPzY[2] =  Flash_get_F32(Dest_Addr_Factory,1016);
  ParaGyro.resPzY[3] =  Flash_get_F32(Dest_Addr_Factory,1020);

  ParaGyro.resPfY[0] =  Flash_get_F32(Dest_Addr_Factory,1024); 
  ParaGyro.resPfY[1] =  Flash_get_F32(Dest_Addr_Factory,1028);
  ParaGyro.resPfY[2] =  Flash_get_F32(Dest_Addr_Factory,1032);
  ParaGyro.resPfY[3] =  Flash_get_F32(Dest_Addr_Factory,1036); 
  
  FloatParaNull[6] = Flash_get_F32(Dest_Addr_Factory,1040);
  FloatParaNull[7] = Flash_get_F32(Dest_Addr_Factory,1044);
  ByteParaNull[0] = *(Dest_Addr_Factory+1048)&0xff;
  ByteParaNull[1] = *(Dest_Addr_Factory+1049)&0xff;
  ByteParaNull[2] = *(Dest_Addr_Factory+1050)&0xff;

  ParaGyro.resPzZ[0] =  Flash_get_F32(Dest_Addr_Factory,1051); 
  ParaGyro.resPzZ[1] =  Flash_get_F32(Dest_Addr_Factory,1055);
  ParaGyro.resPzZ[2] =  Flash_get_F32(Dest_Addr_Factory,1059);
  ParaGyro.resPzZ[3] =  Flash_get_F32(Dest_Addr_Factory,1063);

  ParaGyro.resPfZ[0] =  Flash_get_F32(Dest_Addr_Factory,1067); 
  ParaGyro.resPfZ[1] =  Flash_get_F32(Dest_Addr_Factory,1071);
  ParaGyro.resPfZ[2] =  Flash_get_F32(Dest_Addr_Factory,1075);
  ParaGyro.resPfZ[3] =  Flash_get_F32(Dest_Addr_Factory,1079); 
  
  //��ʼ��ַ���ģ�����������Ǵ�����ʹ��
  for(i=0;i<50;i++)
  {    
    FloatParaNull[i+8] = get_f32_LH(Dest_Addr_Factory,1083+i*4);
  }

  /*����336�ֽڣ�ȫ0������*/
  
/*���ݳ��±궨*/
  ParaGyro.GyroSF_X    = Flash_get_F32(Dest_Addr_Factory,1619); 
  ParaGyro.GyroBias_X  = Flash_get_F32(Dest_Addr_Factory,1623);  
  ParaGyro.GyroSF_Y    = Flash_get_F32(Dest_Addr_Factory,1627);     
  ParaGyro.GyroBias_Y  = Flash_get_F32(Dest_Addr_Factory,1631);
  ParaGyro.GyroSF_Z    = Flash_get_F32(Dest_Addr_Factory,1635); 
  ParaGyro.GyroBias_Z  = Flash_get_F32(Dest_Addr_Factory,1639);
/*������λ�²�*/  
  ParaGyro.GyroTempCoef_X_Flag = (int)(*(Dest_Addr_Factory+1643)&0xff);
  ParaGyro.GyroTempCoef_Y_Flag = (int)(*(Dest_Addr_Factory+1644)&0xff);  
  ParaGyro.GyroTempCoef_Z_Flag = (int)(*(Dest_Addr_Factory+1645)&0xff);     

  ParaGyro.Gyro_Temp1_X = Flash_get_F32(Dest_Addr_Factory,1646);
  ParaGyro.Gyro_Temp2_X = Flash_get_F32(Dest_Addr_Factory,1650);
  ParaGyro.Gyro_Temp3_X = Flash_get_F32(Dest_Addr_Factory,1654);
  ParaGyro.Gyro_Temp4_X = Flash_get_F32(Dest_Addr_Factory,1658);
  ParaGyro.Gyro_Temp5_X = Flash_get_F32(Dest_Addr_Factory,1662);
  ParaGyro.Gyro_Temp6_X = Flash_get_F32(Dest_Addr_Factory,1666);
  ParaGyro.Gyro_Temp7_X = Flash_get_F32(Dest_Addr_Factory,1670);
  ParaGyro.Gyro_Temp8_X = Flash_get_F32(Dest_Addr_Factory,1674);
  ParaGyro.Gyro_Temp9_X = Flash_get_F32(Dest_Addr_Factory,1678);
  
  ParaGyro.GyroBias_D1_X1 = Flash_get_F32(Dest_Addr_Factory,1682);
  ParaGyro.GyroBias_D1_X0 = Flash_get_F32(Dest_Addr_Factory,1686);
  ParaGyro.GyroBias_D2_X1 = Flash_get_F32(Dest_Addr_Factory,1690);
  ParaGyro.GyroBias_D2_X0 = Flash_get_F32(Dest_Addr_Factory,1694);
  ParaGyro.GyroBias_D3_X1 = Flash_get_F32(Dest_Addr_Factory,1698);
  ParaGyro.GyroBias_D3_X0 = Flash_get_F32(Dest_Addr_Factory,1702);
  ParaGyro.GyroBias_D4_X1 = Flash_get_F32(Dest_Addr_Factory,1706);
  ParaGyro.GyroBias_D4_X0 = Flash_get_F32(Dest_Addr_Factory,1710);
  ParaGyro.GyroBias_D5_X1 = Flash_get_F32(Dest_Addr_Factory,1714);
  ParaGyro.GyroBias_D5_X0 = Flash_get_F32(Dest_Addr_Factory,1718);
  ParaGyro.GyroBias_D6_X1 = Flash_get_F32(Dest_Addr_Factory,1722);
  ParaGyro.GyroBias_D6_X0 = Flash_get_F32(Dest_Addr_Factory,1726);
  ParaGyro.GyroBias_D7_X1 = Flash_get_F32(Dest_Addr_Factory,1730);
  ParaGyro.GyroBias_D7_X0 = Flash_get_F32(Dest_Addr_Factory,1734);
  ParaGyro.GyroBias_D8_X1 = Flash_get_F32(Dest_Addr_Factory,1738);
  ParaGyro.GyroBias_D8_X0 = Flash_get_F32(Dest_Addr_Factory,1742);
  ParaGyro.GyroBias_D9_X1 = Flash_get_F32(Dest_Addr_Factory,1746);
  ParaGyro.GyroBias_D9_X0 = Flash_get_F32(Dest_Addr_Factory,1750);
  ParaGyro.GyroBias_D10_X1 = Flash_get_F32(Dest_Addr_Factory,1754);
  ParaGyro.GyroBias_D10_X0 = Flash_get_F32(Dest_Addr_Factory,1758);
  
  ParaGyro.Gyro_Temp1_Y = Flash_get_F32(Dest_Addr_Factory,1762);
  ParaGyro.Gyro_Temp2_Y = Flash_get_F32(Dest_Addr_Factory,1766);
  ParaGyro.Gyro_Temp3_Y = Flash_get_F32(Dest_Addr_Factory,1770);
  ParaGyro.Gyro_Temp4_Y = Flash_get_F32(Dest_Addr_Factory,1774);
  ParaGyro.Gyro_Temp5_Y = Flash_get_F32(Dest_Addr_Factory,1778);
  ParaGyro.Gyro_Temp6_Y = Flash_get_F32(Dest_Addr_Factory,1782);
  ParaGyro.Gyro_Temp7_Y = Flash_get_F32(Dest_Addr_Factory,1786);
  ParaGyro.Gyro_Temp8_Y = Flash_get_F32(Dest_Addr_Factory,1790);
  ParaGyro.Gyro_Temp9_Y = Flash_get_F32(Dest_Addr_Factory,1794);
  
  ParaGyro.GyroBias_D1_Y1 = Flash_get_F32(Dest_Addr_Factory,1798);
  ParaGyro.GyroBias_D1_Y0 = Flash_get_F32(Dest_Addr_Factory,1802);
  ParaGyro.GyroBias_D2_Y1 = Flash_get_F32(Dest_Addr_Factory,1806);
  ParaGyro.GyroBias_D2_Y0 = Flash_get_F32(Dest_Addr_Factory,1810);
  ParaGyro.GyroBias_D3_Y1 = Flash_get_F32(Dest_Addr_Factory,1814);
  ParaGyro.GyroBias_D3_Y0 = Flash_get_F32(Dest_Addr_Factory,1818);
  ParaGyro.GyroBias_D4_Y1 = Flash_get_F32(Dest_Addr_Factory,1822);
  ParaGyro.GyroBias_D4_Y0 = Flash_get_F32(Dest_Addr_Factory,1826);
  ParaGyro.GyroBias_D5_Y1 = Flash_get_F32(Dest_Addr_Factory,1830);
  ParaGyro.GyroBias_D5_Y0 = Flash_get_F32(Dest_Addr_Factory,1834);
  ParaGyro.GyroBias_D6_Y1 = Flash_get_F32(Dest_Addr_Factory,1838);
  ParaGyro.GyroBias_D6_Y0 = Flash_get_F32(Dest_Addr_Factory,1842);
  ParaGyro.GyroBias_D7_Y1 = Flash_get_F32(Dest_Addr_Factory,1846);
  ParaGyro.GyroBias_D7_Y0 = Flash_get_F32(Dest_Addr_Factory,1850);
  ParaGyro.GyroBias_D8_Y1 = Flash_get_F32(Dest_Addr_Factory,1854);
  ParaGyro.GyroBias_D8_Y0 = Flash_get_F32(Dest_Addr_Factory,1858);
  ParaGyro.GyroBias_D9_Y1 = Flash_get_F32(Dest_Addr_Factory,1862);
  ParaGyro.GyroBias_D9_Y0 = Flash_get_F32(Dest_Addr_Factory,1866);
  ParaGyro.GyroBias_D10_Y1 = Flash_get_F32(Dest_Addr_Factory,1870);
  ParaGyro.GyroBias_D10_Y0 = Flash_get_F32(Dest_Addr_Factory,1874);
  
  ParaGyro.Gyro_Temp1_Z = Flash_get_F32(Dest_Addr_Factory,1878);
  ParaGyro.Gyro_Temp2_Z = Flash_get_F32(Dest_Addr_Factory,1882);
  ParaGyro.Gyro_Temp3_Z = Flash_get_F32(Dest_Addr_Factory,1886);
  ParaGyro.Gyro_Temp4_Z = Flash_get_F32(Dest_Addr_Factory,1890);
  ParaGyro.Gyro_Temp5_Z = Flash_get_F32(Dest_Addr_Factory,1894);
  ParaGyro.Gyro_Temp6_Z = Flash_get_F32(Dest_Addr_Factory,1898);
  ParaGyro.Gyro_Temp7_Z = Flash_get_F32(Dest_Addr_Factory,1902);
  ParaGyro.Gyro_Temp8_Z = Flash_get_F32(Dest_Addr_Factory,1906);
  ParaGyro.Gyro_Temp9_Z = Flash_get_F32(Dest_Addr_Factory,1910);
  
  ParaGyro.GyroBias_D1_Z1 = Flash_get_F32(Dest_Addr_Factory,1914);
  ParaGyro.GyroBias_D1_Z0 = Flash_get_F32(Dest_Addr_Factory,1918);
  ParaGyro.GyroBias_D2_Z1 = Flash_get_F32(Dest_Addr_Factory,1922);
  ParaGyro.GyroBias_D2_Z0 = Flash_get_F32(Dest_Addr_Factory,1926);
  ParaGyro.GyroBias_D3_Z1 = Flash_get_F32(Dest_Addr_Factory,1930);
  ParaGyro.GyroBias_D3_Z0 = Flash_get_F32(Dest_Addr_Factory,1934);
  ParaGyro.GyroBias_D4_Z1 = Flash_get_F32(Dest_Addr_Factory,1938);
  ParaGyro.GyroBias_D4_Z0 = Flash_get_F32(Dest_Addr_Factory,1942);
  ParaGyro.GyroBias_D5_Z1 = Flash_get_F32(Dest_Addr_Factory,1946);
  ParaGyro.GyroBias_D5_Z0 = Flash_get_F32(Dest_Addr_Factory,1950);
  ParaGyro.GyroBias_D6_Z1 = Flash_get_F32(Dest_Addr_Factory,1954);
  ParaGyro.GyroBias_D6_Z0 = Flash_get_F32(Dest_Addr_Factory,1958);
  ParaGyro.GyroBias_D7_Z1 = Flash_get_F32(Dest_Addr_Factory,1962);
  ParaGyro.GyroBias_D7_Z0 = Flash_get_F32(Dest_Addr_Factory,1966);
  ParaGyro.GyroBias_D8_Z1 = Flash_get_F32(Dest_Addr_Factory,1970);
  ParaGyro.GyroBias_D8_Z0 = Flash_get_F32(Dest_Addr_Factory,1974);
  ParaGyro.GyroBias_D9_Z1 = Flash_get_F32(Dest_Addr_Factory,1978);
  ParaGyro.GyroBias_D9_Z0 = Flash_get_F32(Dest_Addr_Factory,1982);
  ParaGyro.GyroBias_D10_Z1 = Flash_get_F32(Dest_Addr_Factory,1986);
  ParaGyro.GyroBias_D10_Z0 = Flash_get_F32(Dest_Addr_Factory,1990);
  
  for(i=0;i<9;i++)
  {    
    FloatParaNull[i+58] = Flash_get_F32(Dest_Addr_Factory,1994+i*4);
  }
  /*����200�ֽڣ�ȫ0������*/ 

/*���ݱ�������²�*/
  ParaGyro.GyroSFOT_X_Flag = (int)(*(Dest_Addr_Factory+2230)&0xff); 
  ParaGyro.GyroSFOT_Y_Flag = (int)(*(Dest_Addr_Factory+2231)&0xff); 
  ParaGyro.GyroSFOT_Z_Flag = (int)(*(Dest_Addr_Factory+2232)&0xff);  

  ParaGyro.GyroSF_Temp_X = Flash_get_F32(Dest_Addr_Factory,2233);
  ParaGyro.GyroSF_Temp_Y = Flash_get_F32(Dest_Addr_Factory,2237);
  ParaGyro.GyroSF_Temp_Z = Flash_get_F32(Dest_Addr_Factory,2241);

  ParaGyro.GyroSFOT_X3 = Flash_get_F32(Dest_Addr_Factory,2245); 
  ParaGyro.GyroSFOT_X2 = Flash_get_F32(Dest_Addr_Factory,2249); 
  ParaGyro.GyroSFOT_X1 = Flash_get_F32(Dest_Addr_Factory,2253);
  ParaGyro.GyroSFOT_X0 = Flash_get_F32(Dest_Addr_Factory,2257);
  
  ParaGyro.GyroSFDW_X3 = Flash_get_F32(Dest_Addr_Factory,2261); 
  ParaGyro.GyroSFDW_X2 = Flash_get_F32(Dest_Addr_Factory,2265); 
  ParaGyro.GyroSFDW_X1 = Flash_get_F32(Dest_Addr_Factory,2269); 
  ParaGyro.GyroSFDW_X0 = Flash_get_F32(Dest_Addr_Factory,2273); 
  ParaGyro.GyroSFGW_X3 = Flash_get_F32(Dest_Addr_Factory,2277);
  ParaGyro.GyroSFGW_X2 = Flash_get_F32(Dest_Addr_Factory,2281); 
  ParaGyro.GyroSFGW_X1 = Flash_get_F32(Dest_Addr_Factory,2285);
  ParaGyro.GyroSFGW_X0 = Flash_get_F32(Dest_Addr_Factory,2289);

  ParaGyro.GyroSFOT_Y3 = Flash_get_F32(Dest_Addr_Factory,2293); 
  ParaGyro.GyroSFOT_Y2 = Flash_get_F32(Dest_Addr_Factory,2297); 
  ParaGyro.GyroSFOT_Y1 = Flash_get_F32(Dest_Addr_Factory,2301); 
  ParaGyro.GyroSFOT_Y0 = Flash_get_F32(Dest_Addr_Factory,2305);
  
  ParaGyro.GyroSFDW_Y3 = Flash_get_F32(Dest_Addr_Factory,2309); 
  ParaGyro.GyroSFDW_Y2 = Flash_get_F32(Dest_Addr_Factory,2313); 
  ParaGyro.GyroSFDW_Y1 = Flash_get_F32(Dest_Addr_Factory,2317);
  ParaGyro.GyroSFDW_Y0 = Flash_get_F32(Dest_Addr_Factory,2321); 
  ParaGyro.GyroSFGW_Y3 = Flash_get_F32(Dest_Addr_Factory,2325); 
  ParaGyro.GyroSFGW_Y2 = Flash_get_F32(Dest_Addr_Factory,2329); 
  ParaGyro.GyroSFGW_Y1 = Flash_get_F32(Dest_Addr_Factory,2333); 
  ParaGyro.GyroSFGW_Y0 = Flash_get_F32(Dest_Addr_Factory,2337);

  ParaGyro.GyroSFOT_Z3 = Flash_get_F32(Dest_Addr_Factory,2341); 
  ParaGyro.GyroSFOT_Z2 = Flash_get_F32(Dest_Addr_Factory,2345);
  ParaGyro.GyroSFOT_Z1 = Flash_get_F32(Dest_Addr_Factory,2349); 
  ParaGyro.GyroSFOT_Z0 = Flash_get_F32(Dest_Addr_Factory,2353);
  
  ParaGyro.GyroSFDW_Z3 = Flash_get_F32(Dest_Addr_Factory,2357); 
  ParaGyro.GyroSFDW_Z2 = Flash_get_F32(Dest_Addr_Factory,2361); 
  ParaGyro.GyroSFDW_Z1 = Flash_get_F32(Dest_Addr_Factory,2365); 
  ParaGyro.GyroSFDW_Z0 = Flash_get_F32(Dest_Addr_Factory,2369); 
  ParaGyro.GyroSFGW_Z3 = Flash_get_F32(Dest_Addr_Factory,2373);
  ParaGyro.GyroSFGW_Z2 = Flash_get_F32(Dest_Addr_Factory,2377);
  ParaGyro.GyroSFGW_Z1 = Flash_get_F32(Dest_Addr_Factory,2381);
  ParaGyro.GyroSFGW_Z0 = Flash_get_F32(Dest_Addr_Factory,2385);      
  
  /*����200�ֽڣ�ȫ0������*/
  /*���ݰ�װ���*/
  ParaGyro.GYRO_THETA_XY = Flash_get_F32(Dest_Addr_Factory,2589);
  ParaGyro.GYRO_THETA_XZ = Flash_get_F32(Dest_Addr_Factory,2593);
  ParaGyro.GYRO_THETA_YX = Flash_get_F32(Dest_Addr_Factory,2597);
  ParaGyro.GYRO_THETA_YZ = Flash_get_F32(Dest_Addr_Factory,2601);
  ParaGyro.GYRO_THETA_ZX = Flash_get_F32(Dest_Addr_Factory,2605);
  ParaGyro.GYRO_THETA_ZY = Flash_get_F32(Dest_Addr_Factory,2609);
  
  ParaGyro.GyroX_sign_Flag = (int)(*(Dest_Addr_Factory+2613)&0xff); 
  ParaGyro.GyroY_sign_Flag = (int)(*(Dest_Addr_Factory+2614)&0xff); 
  ParaGyro.GyroZ_sign_Flag = (int)(*(Dest_Addr_Factory+2615)&0xff); 
  
  /*���ݵı�Ⱥ���λ��������ʱ����*/
  for(i=0;i<6;i++)
  {    
    FloatParaNull[i+67] = Flash_get_F32(Dest_Addr_Factory,2616+i*4);
  }  
  /*����400�ֽڣ�ȫ0������*/
  
  ParaGyro.GYRO_G_SENSITIVITY_XX = Flash_get_F32(Dest_Addr_Factory,3040);
  ParaGyro.GYRO_G_SENSITIVITY_YX = Flash_get_F32(Dest_Addr_Factory,3044);
  ParaGyro.GYRO_G_SENSITIVITY_ZX = Flash_get_F32(Dest_Addr_Factory,3048);
  ParaGyro.GYRO_G_SENSITIVITY_XY = Flash_get_F32(Dest_Addr_Factory,3052);
  ParaGyro.GYRO_G_SENSITIVITY_YY = Flash_get_F32(Dest_Addr_Factory,3056);
  ParaGyro.GYRO_G_SENSITIVITY_ZY = Flash_get_F32(Dest_Addr_Factory,3060);
  ParaGyro.GYRO_G_SENSITIVITY_XZ = Flash_get_F32(Dest_Addr_Factory,3064);
  ParaGyro.GYRO_G_SENSITIVITY_YZ = Flash_get_F32(Dest_Addr_Factory,3068);
  ParaGyro.GYRO_G_SENSITIVITY_ZZ = Flash_get_F32(Dest_Addr_Factory,3072);
  
  /*�����޷�*/
  ProductRange.WX_SCALE = Flash_get_F32(Dest_Addr_Factory,3076);
  ProductRange.WY_SCALE = Flash_get_F32(Dest_Addr_Factory,3080);
  ProductRange.WZ_SCALE = Flash_get_F32(Dest_Addr_Factory,3084);  
  ProductRange.WX_FS_Z = Flash_get_F32(Dest_Addr_Factory,3088);
  ProductRange.WX_FS_F = Flash_get_F32(Dest_Addr_Factory,3092);
  ProductRange.WY_FS_Z = Flash_get_F32(Dest_Addr_Factory,3096); 
  ProductRange.WY_FS_F = Flash_get_F32(Dest_Addr_Factory,3100);     
  ProductRange.WZ_FS_Z = Flash_get_F32(Dest_Addr_Factory,3104); 
  ProductRange.WZ_FS_F = Flash_get_F32(Dest_Addr_Factory,3108); 
  /*����364+555+12+48+3�ֽڣ�ȫ0������*/
  
  /*�û������������ӱ�*/ 
  ParaUser.AcceX_relativeSF = Flash_get_F32(Dest_Addr_USER,0);  
  ParaUser.AcceY_relativeSF = Flash_get_F32(Dest_Addr_USER,4);
  ParaUser.AcceZ_relativeSF = Flash_get_F32(Dest_Addr_USER,8);  
  
  ParaUser.AcceX_relativeBIAS = Flash_get_F32(Dest_Addr_USER,12); 
  ParaUser.AcceY_relativeBIAS = Flash_get_F32(Dest_Addr_USER,16); 
  ParaUser.AcceZ_relativeBIAS = Flash_get_F32(Dest_Addr_USER,20);
  
  ParaUser.AcceYX_CROSS = Flash_get_F32(Dest_Addr_USER,24);   
  ParaUser.AcceZX_CROSS = Flash_get_F32(Dest_Addr_USER,28);
  ParaUser.AcceXY_CROSS = Flash_get_F32(Dest_Addr_USER,32);   
  ParaUser.AcceZY_CROSS = Flash_get_F32(Dest_Addr_USER,36);   
  ParaUser.AcceXZ_CROSS = Flash_get_F32(Dest_Addr_USER,40); 
  ParaUser.AcceYZ_CROSS = Flash_get_F32(Dest_Addr_USER,44);              
  
  /*�û���������������*/                                                   
  ParaUser.GyroX_relativeSF = Flash_get_F32(Dest_Addr_USER,48);  
  ParaUser.GyroY_relativeSF = Flash_get_F32(Dest_Addr_USER,52); 
  ParaUser.GyroZ_relativeSF = Flash_get_F32(Dest_Addr_USER,56);    
  
  ParaUser.GyroYX_CROSS = Flash_get_F32(Dest_Addr_USER,60);   
  ParaUser.GyroZX_CROSS = Flash_get_F32(Dest_Addr_USER,64);
  ParaUser.GyroXY_CROSS = Flash_get_F32(Dest_Addr_USER,68);    
  ParaUser.GyroZY_CROSS = Flash_get_F32(Dest_Addr_USER,72);  
  ParaUser.GyroXZ_CROSS = Flash_get_F32(Dest_Addr_USER,76); 
  ParaUser.GyroYZ_CROSS = Flash_get_F32(Dest_Addr_USER,80);
  
  ParaUser.GyroRelativeBias_X = Flash_get_F32(Dest_Addr_USER,84);  
  ParaUser.GyroRelativeBias_Y = Flash_get_F32(Dest_Addr_USER,88); 
  ParaUser.GyroRelativeBias_Z = Flash_get_F32(Dest_Addr_USER,92);
  /*�����ֽڣ�ȫ0������; ��Ʒ��Ϣ�������ظ�������*/

  for(i=0;i<20;i++)
  {
      ParaUser.FactorySet[i]   = (uint8_t)(*(Dest_Addr_USER+154+i)&0xff);
  }
  ParaUser.ExperimentStatus = (uint8_t)(*(Dest_Addr_USER+174)&0xff);
  ParaUser.DataFormat = (uint8_t)(*(Dest_Addr_USER+175)&0xff);
  ParaUser.TERM = (uint8_t)(*(Dest_Addr_USER+176)&0xff);
  ParaUser.UNIT = (uint8_t)(*(Dest_Addr_USER+177)&0xff);
  ParaUser.SampleFreq = (uint8_t)(*(Dest_Addr_USER+178)&0xff);
  ParaUser.LPFilter = (uint8_t)(*(Dest_Addr_USER+179)&0xff);
  ParaUser.FilterAxis = (uint8_t)(*(Dest_Addr_USER+180)&0xff);
  ParaUser.BitRate = (uint8_t)(*(Dest_Addr_USER+181)&0xff);
  ParaUser.Parity = (uint8_t)(*(Dest_Addr_USER+182)&0xff);
  ParaUser.StopBit = (uint8_t)(*(Dest_Addr_USER+183)&0xff);

  for(i=0;i<10;i++)
  {
      ParaUser.productID[i]   = (uint8_t)(*(Dest_Addr_USER+184+i)&0xff);
      ParaUser.productNum[i]  = (uint8_t)(*(Dest_Addr_USER+194+i)&0xff);
      ParaUser.softwareVer[i] = (uint8_t)(*(Dest_Addr_USER+204+i)&0xff);
      ParaUser.hardwareVer[i] = (uint8_t)(*(Dest_Addr_USER+214+i)&0xff);
  }

  for(i=0;i<2;i++)
  {
      ParaUser.checkNUM[i] = (uint8_t)(*(Dest_Addr_USER+224+i)&0xff);
  }
/***���ݲ���***/
  /*
  for(i=0;i<96;i++)
  {
      ParaUser2.UserData[i] = (uint8_t)(*(Dest_Addr_USER+i)&0xff);
  }
  for(i=0;i<78;i++)
  {
      ParaUser2.Resv[i] = (uint8_t)(*(Dest_Addr_USER+ 96 + i)&0xff);
  }
 
  */
  
  //������������flash���û���������2K��ʼ��ȡ
  
  //1 ��flash�ж�ȡ��4���㷨������
//  kt_device.comp_algo_ctrl.Filter_Flag  = (int)(*(Dest_Addr_Factory+0x800+36)&0xff); 
//  kt_device.comp_algo_ctrl.Wenbu_Flag   = (int)(*(Dest_Addr_Factory+0x800+40)&0xff);
//  kt_device.comp_algo_ctrl.Release_Flag = (int)(*(Dest_Addr_Factory+0x800+44)&0xff);
//  kt_device.comp_algo_ctrl.Temp_Comp_Axis = (int)(*(Dest_Addr_Factory+0x800+48)&0xff);
  
  return;
}


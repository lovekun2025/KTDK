#ifndef SIGNAL_H_201902141645
#define SIGNAL_H_201902141645
/**
 * @file Signal.h
 * @author Qiaoyy@xlnav.com
 * @date 2018-02-14
 * @brief  
 * Copyright (c) 2018 XiLang Co. Ltd.
 * All rights reserved.
 */
 
/* Includes ------------------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/
#define SIGNAL_GPS_PPS_SYNCHRONIZATION ((uint32_t)(0x00000001U))
#define SIGNAL_10_MS_TIMER ((uint32_t)(0x00000002U))

/* Exported types ------------------------------------------------------------*/ 
typedef struct
{
	unsigned int flag_gps_pps;
	unsigned int flag_Config_loaded;
	unsigned int flag_config_mode;
	unsigned int flag_CalibrationMode;
}SignalStatusTypeDef;
/* Exported constants --------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
void GenerateSignal(unsigned int signals);
unsigned int CheckSignalKey(unsigned int *key);
SignalStatusTypeDef* GetGlobalSignalStatus(void);
void EnableSignalKey(unsigned int *key);
void DisableSignalKey(unsigned int *key);
unsigned int SignalKeyIsEnable(unsigned int key);

#endif
/************************ (C) COPYRIGHT XiLang CO. Ltd. *******END OF FILE*****/

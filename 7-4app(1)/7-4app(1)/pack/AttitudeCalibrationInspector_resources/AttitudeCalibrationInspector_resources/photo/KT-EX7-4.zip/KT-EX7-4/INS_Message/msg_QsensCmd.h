#ifndef CMDFRAME_H_20175132143
#define CMDFRAME_H_20175132143
/*--------------------------------------------------------------------------
* File Name: CmdFrame.h
* Module: 
* Abstact: 	
* Author: Qiao Yuyang
* DATA: 2017-5-13  21:43
--------------------------------------------------------------------------*/
#include "Global.h"
/*--------------------------- Debug Switch    ----------------------------*/
#define QSENS_715_MAPPING_DEFINE 			{FIXED_LENGTH_FRAME, {0xFF, 0xAA}, "", 2, 4, QSENS_AckInit, QSENS_AckFrameLength, QSENS_AckFrameCheck, QSENS_AckFrameParse},

#define QSENS_BIN_PROTOCOL_MAPPING_DEFINE 	{SETTING_LENGTH_FRAME, {0xEA,0x51}, "", 2, 6, QSENS_BinInit, QSENS_BinFrameLength, QSENS_BinFrameCheck, QSENS_BinFrameParse},

#define QSENS_CMD_MAPPING_DEFINE 			{UNFIXED_LENGTH_FRAME, "#q", "\r\n", 2, 2, QSENS_CmdInit, QSENS_CmdFrameLength, QSENS_CmdFrameCheck, QSENS_CmdFrameParse},\
								 			{UNFIXED_LENGTH_FRAME, "#Q", "\r\n", 2, 2, QSENS_CmdInit, QSENS_CmdFrameLength, QSENS_CmdFrameCheck, QSENS_CmdFrameParse},

#define QSENS_MAG_MAPPING_DEFINE 			{FIXED_LENGTH_FRAME, {0x00,0x0D,0x01}, "",3, 13, ShenHaiLan_MagInit, ShenHaiLan_MagFrameLength, ShenHaiLan_MagFrameCheck, ShenHaiLan_MagFrameParse},
/*--------------------------- Include File    ----------------------------*/

/*--------------------------- Macro Define    ----------------------------*/
/*--------------------------- Struct Define   ----------------------------*/
int32_t QSENS_CmdInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_CmdFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_CmdFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_CmdFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);

int32_t QSENS_AckInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_AckFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_AckFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
int32_t QSENS_AckFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);

//int32_t QSENS_MagInit(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
//int32_t QSENS_MagFrameLength(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
//int32_t QSENS_MagFrameCheck(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);
//int32_t QSENS_MagFrameParse(uint8_t* pBuffer, int32_t nLength, uint32_t nSource);

int QSENS_BinFrameLength(unsigned char* pBuffer, int nLength, uint32_t nSource);
int QSENS_BinFrameCheck(unsigned char* pBuffer, int nLength, uint32_t nSource);
int QSENS_BinFrameParse(unsigned char* pBuffer, int nLength, uint32_t nSource);
int QSENS_BinInit(unsigned char* pBuffer, int nLength, uint32_t nSource);
void PrintUartMessage(unsigned int portId, char* string, int limit);
#endif

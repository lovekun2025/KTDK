#ifndef __MS5607_H
#define __MS5607_H

#include "stm32f4xx.h"

#define MS5607_SPI                   SPI1
#define MS5607_CS_PORT              GPIOA 
#define MS5607_CS_PIN               GPIO_Pin_2

uint16_t MS5607_Read(uint8_t addr);
void MS5607_config();
void Get_MS5607_data();
#endif
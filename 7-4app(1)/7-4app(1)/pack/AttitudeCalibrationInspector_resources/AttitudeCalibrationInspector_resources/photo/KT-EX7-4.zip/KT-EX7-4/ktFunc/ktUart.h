#ifndef __KT_UART_H
#define __KT_UART_H


//#include  "Includes.h"
#include "Global.h"



typedef struct
{
  uint32_t bitRate;
  uint32_t wordLength; 
  uint32_t stopBits; 
  uint32_t parity;   
}uartConfig_s;
                   


#if defined(GD32E103V_MD) || defined(GD32F10X_MD)
//��żУ��
#define     KT_UART_PM_NONE   USART_PM_NONE
#define     KT_UART_PM_EVEN   USART_PM_EVEN
#define     KT_UART_PM_ODD    USART_PM_ODD

//����λ
#define     KT_UART_WL_8BIT   USART_WL_8BIT
#define     KT_UART_WL_9BIT   USART_WL_9BIT

//ֹͣλ
#define     KT_UART_STB_1BIT     USART_STB_1BIT 
#define     KT_UART_STB_0_5BIT   USART_STB_0_5BIT 
#define     KT_UART_STB_2BIT     USART_STB_2BIT 
#define     KT_UART_STB_1_5BIT   USART_STB_1_5BIT 


#define KT_UART0_IRQn              USART0_IRQn                     
#define KT_UART0_IRQHandler        USART0_IRQHandler                   

////////////////////////////////////////////////////////////

#endif


#if defined(STM32F40XX)

//��żУ��
#define     KT_UART_PM_NONE   USART_Parity_No
#define     KT_UART_PM_EVEN   USART_Parity_Even
#define     KT_UART_PM_ODD    USART_Parity_Odd

//����λ
#define     KT_UART_WL_8BIT   USART_WordLength_8b
#define     KT_UART_WL_9BIT   USART_WordLength_9b

//ֹͣλ
#define     KT_UART_STB_1BIT     USART_StopBits_1 
#define     KT_UART_STB_0_5BIT   USART_StopBits_0_5 
#define     KT_UART_STB_2BIT     USART_StopBits_2 
#define     KT_UART_STB_1_5BIT   USART_StopBits_1_5 

#define KT_UART0_IRQn              USART1_IRQn                     
#define KT_UART0_IRQHandler        USART1_IRQHandler                   


//RS485 ʹ��USART2
#define USART_485                   USART2
#define USART_485_GPIO              GPIOA 
#define USART_485_CLK               RCC_APB1Periph_USART2
#define USART_485_GPIO_CLK          RCC_AHB1Periph_GPIOA     //RCC_AHB1Periph_GPIOA 
#define USART_485_RxPin             GPIO_Pin_3
#define USART_485_TxPin             GPIO_Pin_2
#define USART_485_DR_Base           0x40004404

#define USART_RE_GPIO               GPIOA
#define USART_RE                    GPIO_Pin_11 
#define USART_DE_GPIO               GPIOC
#define USART_DE                    GPIO_Pin_5 
#define USART_485_Mode_Tx()         {GPIO_SetBits(USART_RE_GPIO, USART_RE);GPIO_SetBits(USART_DE_GPIO, USART_DE);}
#define USART_485_Mode_Rx()         {GPIO_ResetBits(USART_RE_GPIO, USART_RE);GPIO_ResetBits(USART_DE_GPIO, USART_DE);}

//RS422 ʹ��USART3�����ںʹ�ͬ��ͨѶ
#define USART3_422                   USART3
#define USART3_422_GPIO              GPIOB
#define USART3_422_CLK               RCC_APB1Periph_USART3
#define USART3_422_GPIO_CLK          RCC_AHB1Periph_GPIOB
#define USART3_422_RxPin             GPIO_Pin_11
#define USART3_422_TxPin             GPIO_Pin_10
#define USART3_422_IRQn              USART3_IRQn
#define USART3_422_IRQHandler        USART3_IRQHandler
#define USART3_422_DR_Base           0x40004804



#endif

void ktUart0ClearInt();
void ktUart0RxIntEnable();
void ktUart0IdleIntEnable();
void ktUart0RxIntDisable();
void ktUart0IdleIntDisable();
void ktUart0GpioInit();
void ktUart0Init(char state);
void ktUart0TxDMAConfig(char state);
void ktUart0DMAWaitIdleWithTimeout(uint32_t timeOut);
void ktUart0DMASend(uint16_t sendLength);
void copyDataFromRxBuff(uint8_t  *dest,uint8_t *src,uint16_t pos,uint16_t length,uint16_t buffLenth);
void USART_422_DMA_Send(uint16_t send_length);


void UART_485_GPIO_Init() ;
void UART_485_Init();
void USART_485_DMA_Config();
void USART_485_DMA_Send(uint16_t send_length);


void UART3_Init() ;
void USART3_ShenHaiLan_DMA_Config(DMA_CircularBuffer* buffer) ;



#endif
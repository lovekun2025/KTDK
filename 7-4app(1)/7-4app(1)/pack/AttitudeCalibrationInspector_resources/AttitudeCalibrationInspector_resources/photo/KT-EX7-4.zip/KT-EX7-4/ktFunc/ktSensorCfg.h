#ifndef __KTSENSORCFG_H
#define __KTSENSORCFG_H

void QMI8658_Config(void);

void QMI8658_SYNC_Config(void);

void SMAXXD_SYNC_Config(void);

void ASM330_Config(void);

void ADXL357_Config();

#endif


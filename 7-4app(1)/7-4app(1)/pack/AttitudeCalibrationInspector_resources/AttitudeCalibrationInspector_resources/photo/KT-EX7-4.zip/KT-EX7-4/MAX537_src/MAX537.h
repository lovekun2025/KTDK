#ifndef __MAX5xx_H
#define __MAX5xx_H
#include "MAX537_Port.h"
#define SPI_1                   SPI1
//ACCE X
#define SPI_ACCEX_CS_PIN          GPIO_Pin_4 
#define SPI_ACCEX_CS_PORT         GPIOC
#define SPI_ACCEX_CS_CLK          RCC_AHB1Periph_GPIOC 
//ACCE Y
#define SPI_ACCEY_CS_PIN          GPIO_Pin_0 
#define  SPI_ACCEY_CS_PORT         GPIOB
#define SPI_ACCEY_CS_CLK          RCC_AHB1Periph_GPIOB 
//ACCE Z
#define SPI_ACCEZ_CS_PIN          GPIO_Pin_1 
#define SPI_ACCEZ_CS_PORT         GPIOB
#define SPI_ACCEZ_CS_CLK          RCC_AHB1Periph_GPIOB 


#define MAX537_READY_STATUS_ADDR     0xB8

void MAX537_Write(uint8_t addr, uint8_t data);
void MGZ2067_Read(uint8_t addr,uint16_t *rdData);
uint8_t MAX537_Get_ready_Stauts(uint8_t DeviceNum);
void MAX537_Get_Data(uint8_t DeviceNum,float *accedata,float *temperatrueData);
void Acce_init();


#endif
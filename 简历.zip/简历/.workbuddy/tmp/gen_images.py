# -*- coding: utf-8 -*-
"""复刻源 PDF 的蓝色斜标题条素材（用于 Word 模板）"""
import os
from PIL import Image, ImageDraw, ImageFont
import numpy as np

OUT = r"D:/Desktop/简历/.workbuddy/tmp/img"
os.makedirs(OUT, exist_ok=True)

FONT_BD = r"C:/Windows/Fonts/msyhbd.ttc"
FONT_RG = r"C:/Windows/Fonts/msyh.ttc"
DPI = 300  # 生成精度


def cm(x):
    return int(round(x / 2.54 * DPI))


BLUE = (85, 104, 175)      # 标题条主色 #5568AF
RULE = (68, 88, 160)       # 细横线
TAIL = (30, 58, 96)        # 折角深色


def make_section(title, fname):
    """整幅内容宽度的标题条：矩形 + 左下折角 + 右侧细横线"""
    W = cm(17.0)           # 内容宽 17cm
    rw = cm(3.30)          # 条宽
    rh = cm(0.72)          # 条高
    tw, th = cm(0.37), cm(0.21)   # 折角尺寸
    line_h = max(2, cm(0.025))    # 细线粗 ≈0.7pt

    canvas = Image.new("RGBA", (W, rh + th), (255, 255, 255, 0))
    d = ImageDraw.Draw(canvas)

    # 折角（在矩形下方，先画）
    d.polygon([(0, rh), (tw, rh), (tw, rh + th)], fill=TAIL + (255,))
    # 矩形
    d.rectangle([0, 0, rw - 1, rh - 1], fill=BLUE + (255,))
    # 细横线
    d.rectangle([rw, rh - line_h, W - 1, rh - 1], fill=RULE + (255,))

    # 白字
    fs = cm(0.56)          # ≈16pt
    f = ImageFont.truetype(FONT_BD, fs)
    bb = d.textbbox((0, 0), title, font=f)
    tx = (rw - (bb[2] - bb[0])) // 2 - bb[0]
    ty = (rh - (bb[3] - bb[1])) // 2 - bb[1]
    d.text((tx, ty), title, font=f, fill=(255, 255, 255, 255))

    p = os.path.join(OUT, fname)
    canvas.save(p)
    return p, canvas.size


def make_pennant(title, fname):
    """左上角"个人简历"大旗形（底部中央下垂尖角）"""
    W, H = cm(3.26), cm(1.17)
    DEPTH = cm(0.90)
    canvas = Image.new("RGBA", (W, H + DEPTH), (255, 255, 255, 0))
    d = ImageDraw.Draw(canvas)
    apex_x = int(W * 0.52)
    d.polygon([(0, 0), (W - 1, 0), (W - 1, H - 1), (apex_x, H + DEPTH - 1), (0, H - 1)],
              fill=BLUE + (255,))
    fs = cm(0.64)
    f = ImageFont.truetype(FONT_BD, fs)
    bb = d.textbbox((0, 0), title, font=f)
    tx = (W - (bb[2] - bb[0])) // 2 - bb[0]
    ty = (H - (bb[3] - bb[1])) // 2 - bb[1]
    d.text((tx, ty), title, font=f, fill=(255, 255, 255, 255))
    p = os.path.join(OUT, fname)
    canvas.save(p)
    return p, canvas.size


def make_photo(src_pdf_png):
    """从 PDF 首页渲染图裁出证件照"""
    im = Image.open(src_pdf_png).convert("RGB")
    # 110dpi 下约 x700..815, y58..215 → 加 2px 内缩去掉边框
    box = (703, 61, 812, 205)
    ph = im.crop(box)
    ph = ph.resize((ph.width * 3, ph.height * 3), Image.LANCZOS)
    p = os.path.join(OUT, "photo.png")
    ph.save(p)
    return p, ph.size


if __name__ == "__main__":
    titles = [("个人简历", "big.png"), ("求职意向", "s_job.png"), ("专业技能", "s_skill.png"),
              ("教育经历", "s_edu.png"), ("校园经历", "s_campus.png"), ("工作经验", "s_work.png"),
              ("项目经验", "s_proj.png"), ("自我评价", "s_self.png")]
    for t, fn in titles:
        if fn == "big.png":
            p, s = make_pennant(t, fn)
        else:
            p, s = make_section(t, fn)
        print(fn, t, s)
    p, s = make_photo(r"D:/Desktop/简历/.workbuddy/tmp/pdfimg/page1.png")
    print("photo", s)

    # 拼一张预览图，方便核对
    prev = Image.new("RGB", (cm(17.0), cm(0.72) * 8 + cm(0.21) * 7 + 40), "white")
    y = 0
    for t, fn in titles:
        im = Image.open(os.path.join(OUT, fn)).convert("RGBA")
        bg = Image.new("RGB", im.size, "white")
        bg.paste(im, (0, 0), im)
        prev.paste(bg, (0, y))
        y += bg.height + 5
    prev.save(r"D:/Desktop/简历/.workbuddy/tmp/preview_ribbons.png")
    print("preview saved")

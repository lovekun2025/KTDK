# -*- coding: utf-8 -*-
"""用 editor_sdk(edsdk.py) 装配蓝色斜条版简历"""
import json
import os
import subprocess
import sys
import tempfile

SKILL = r"C:/Users/kaitu/AppData/Local/Programs/WorkBuddy/resources/app.asar.unpacked/resources/plugins/workbuddy-builtin/skills/tencent-local-office-edit"
PY = r"C:/Users/kaitu/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
TMP = r"D:/Desktop/简历/.workbuddy/tmp"
IMG = TMP + "/img"
OUTPATH = r"D:/Desktop/简历/李孟宇-个人简历（蓝色模板版）.docx"

sys.path.insert(0, TMP)
import content as C  # noqa


def call(tool, payload, quiet=False):
    payload = dict(payload)
    path = os.path.join(TMP, "_args.json")   # 固定复用，避免触发批量删除保护
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    r = subprocess.run([PY, "edsdk.py", "call", tool, "--json-file", path],
                       cwd=SKILL, capture_output=True, text=True, encoding="utf-8")
    out = (r.stdout or "").strip()
    obj = None
    for line in reversed(out.splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                obj = json.loads(line)
                break
            except Exception:
                continue
    if obj is None:
        if r.returncode != 0 or not out:
            raise RuntimeError(f"{tool} failed: {out} | {r.stderr}")
        obj = {"_raw": out}
    if not quiet:
        print(f"  [{tool}] -> {json.dumps(obj, ensure_ascii=False)[:220]}")
    return obj


def end_pos(fid):
    r = call("doc_get_last_operable_pos", {"file_id": fid}, quiet=True)
    for k in ("position", "last_edit_index", "idx"):
        if k in r:
            return r[k]
    raise RuntimeError("no position: " + json.dumps(r, ensure_ascii=False))


def md_file(name, text):
    p = os.path.join(TMP, name)
    with open(p, "w", encoding="utf-8") as f:
        f.write(text)
    return "file://" + p


# ---------- 1. 新建 ----------
r = call("create_doc", {})
import re
fid = r.get("file_id") or re.search(r"file_id=(\S+?),", r["_raw"]).group(1)
print("file_id =", fid)

# ---------- 2. 页边距：左右 2cm ----------
call("doc_set_document_style", {
    "file_id": fid,
    "default_text_style": {"font_family": "微软雅黑", "font_size": 10.5},
    "default_paragraph_style": {"line_spacing": 1.25, "line_spacing_rule": 1},
    "page_style": {"page_width": 595.3, "page_height": 841.9,
                   "top_margin": 42, "bottom_margin": 42,
                   "left_margin": 55, "right_margin": 55},
})

# ---------- 3. 表头：旗形 + 信息 + 证件照 ----------
r = call("doc_insert_table", {"file_id": fid, "idx": 0, "row_count": 4, "col_count": 3})
tbl = r.get("table_info", {}).get("id") or r.get("table_id")
print("table_id =", tbl)

call("doc_merge_table_cells", {"file_id": fid, "table_id": tbl, "row": 1, "col": 1, "row_span": 4, "col_span": 1})
call("doc_merge_table_cells", {"file_id": fid, "table_id": tbl, "row": 1, "col": 3, "row_span": 4, "col_span": 1})

lines = ["姓名：李孟宇", "年龄：22", "电话：15633467139", "邮箱：15633467139@163.com"]
cells = [
    {"row": 1, "col": 1, "mc": True, "image": {"content": IMG + "/big.png", "width": 123, "height": 78}},
    {"row": 1, "col": 3, "mc": True, "image": {"content": IMG + "/photo.png", "width": 98, "height": 129}},
]
for i, t in enumerate(lines):
    cells.append({
        "row": i + 1, "col": 2, "inherit": False, "text": t,
        "text_format": {"font_family": "微软雅黑", "font_size": 10.5, "color": "1F3864", "bold": True},
        "horizontal_align": "left",
    })
call("doc_set_table_cells", {"file_id": fid, "table_id": tbl, "cells": cells})

call("doc_set_table_properties", {
    "file_id": fid, "table_id": tbl, "cell_v_align": "center",
    "borders": {d: {"val": "none"} for d in
                ("top", "left", "bottom", "right", "insideH", "insideV")},
    "cell_margin": {"left": 28, "right": 28},
    "mode": "manual", "col_widths_dxa": [2000, 6040, 1600],
})

# ---------- 4. 各章节：标题条 + 正文 ----------
for i, (img, body) in enumerate(C.SECTIONS):
    pos = end_pos(fid)
    call("doc_insert_image", {"file_id": fid, "idx": pos,
                              "image_path": IMG + "/" + img, "w": 643, "h": 35})
    p2 = end_pos(fid)
    call("doc_insert_paragraph", {"file_id": fid, "idx": p2})
    p3 = end_pos(fid)
    call("doc_insert_markdown", {"file_id": fid, "idx": p3,
                                 "markdown": md_file("sec%d.md" % i, body)})
    print(f"  section {i} done")

# ---------- 5. 保存 ----------
call("save_file", {"file_id": fid, "file_path": OUTPATH})
print("SAVED ->", OUTPATH)
